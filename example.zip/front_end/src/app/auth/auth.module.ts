import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthRoutingModule } from './auth.routing';

//prime
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { ResetComponent } from './reset/reset.component';
import {PanelModule} from 'primeng/panel';
import { NewPasswordComponent } from './new-password/new-password.component';
import { EmailValidatedComponent } from './email-validated/email-validated.component';
import { LoginBackofficeComponent } from './login-backoffice/login-backoffice.component';
import {KeyFilterModule} from 'primeng/keyfilter';
import {PasswordModule} from 'primeng/password';
import { NgModule } from '@angular/core';
import { DividerModule } from 'primeng/divider';

import {
  RECAPTCHA_SETTINGS,
  RecaptchaFormsModule,
  RecaptchaModule,
  RecaptchaSettings,
} from 'ng-recaptcha';
import { environment } from '../../environments/environment';

@NgModule({
  declarations: [
    LoginComponent,
    RegisterComponent,
    ResetComponent,
    NewPasswordComponent,
    EmailValidatedComponent,
    LoginBackofficeComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AuthRoutingModule,
    InputTextModule,
    ButtonModule,
    DropdownModule,
    PanelModule,
    KeyFilterModule,
    PasswordModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    DividerModule
  ],
  providers: [
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: {
        siteKey: environment.googleRecaptchaSiteKey,
      } as RecaptchaSettings,
    },
  ],
})
export class AuthModule {}
