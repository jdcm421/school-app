import { ActivatedRoute, ActivationEnd, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '@services/auth.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { MessageService } from '@services/message.service';

@Component({
  selector: 'app-email-validated',
  templateUrl: './email-validated.component.html',
  styleUrls: ['./email-validated.component.scss']
})
export class EmailValidatedComponent implements OnInit {
  token: string;
  sub: any;
  url: string;
  text: boolean;
  constructor(private router: ActivatedRoute,
    private routers: Router,
    private authService: AuthService,
    public messageService: MessageService) { }

  ngOnInit() {
    this.sub = this.router.params.subscribe(params => {
      this.token = params['token'];
    })
    this.confirmar(this.token)
    this.text = false;
  }

  confirmar(token: string) {
    this.authService.validAccount(token).subscribe(response => {
      if (response.codigo == 200) {
        this.messageService.showSucces(response.mensaje);
        this.url = response.user == 'Administrador' ? 'login' : 'usuario/login';
      }
    }, (error: ResponseError) => {
      console.error(error);
      this.text = true;
    })
  }

  login() {
    this.routers.navigate([this.url]);
  }

  public cancel() {
    this.routers.navigate(["/login"])
  }

}
