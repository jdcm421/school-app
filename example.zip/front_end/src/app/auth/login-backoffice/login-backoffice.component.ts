import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Credential, LoginForm } from '@interfaces/auth.interface';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { AuthService } from '@services/auth.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-login-backoffice',
  templateUrl: './login-backoffice.component.html',
  styleUrls: ['./login-backoffice.component.scss'],
})
export class LoginBackofficeComponent implements OnInit {
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  appForm: FormGroup;
  request: Credential;
  validar: LoginForm;
  longitud: number;
  tipo: string;
  documento: string;
  pass: string;
  captcha: string;
  result: boolean = true;
  keyFilter: string;
  version:string;

  constructor(
    private router: Router,
    private documentTypeService: DocumentTypeService,
    private authService: AuthService,
    private fb: FormBuilder,
    public messageService: MessageService
  ) {}

  ngOnInit(): void {

    this.version = 'version '+environment.version;
    this.listTuypeDocuments();
    this.request = {};
    this.appForm = this.fb.group({
      tipoDocumento: ['', [Validators.required]],
      numeroDocumento: ['', [Validators.required]],
      password: ['', [Validators.required]],
      token: ['', [Validators.required]],
    });
  }

  private listTuypeDocuments() {
    this.documentTypeService.getListTypeDocument().subscribe(
      (response) => {
        this.documents = response;
      },
      (error: ResponseError) => {
        console.error(error);
      }
    );
  }

  public logIn() {
    this.request.tipoDocumento =
      this.selectedTypeDocument != null ? this.selectedTypeDocument.id : 0;
    if (this.validacionForm(this.request)) {
      this.request.tipoDocumento = this.selectedTypeDocument.id;
      this.request.dispositivo = 'WEB';
      this.authService.loginUser(this.request).subscribe(
        (response) => {
          console.log(response);
          if (response.codigo == 200) {
            if (response.cuenta.usuario.perfil !==null) {
              this.router.navigate(['/usuario/movimientos']);
            } else if (response.cuenta.admin.role.rol == 'Empresa Transporte') {
              this.router.navigate(['/usuario/control-tarifa']);
            } else if (response.cuenta.admin.role.rol == 'Operador Apps') {
              this.router.navigate(['/usuario/reporte-detallado-operador']);
            } else if (response.cuenta.admin.role.rol == 'Centro Recarga') {
              this.router.navigate(['/usuario/centro-recargas/sucursales/list']);
            } else {
              this.messageService.showWarn('Credenciales invalidas');
            }
          }
        },
        (error: ResponseError) => {
          console.error(error);
        }
      );
    }
  }

  public register() {
    this.router.navigate(['/register']);
  }

  public resetPassword() {
    this.router.navigate(['/reset']);
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    this.longitud = tipo.longitud;
    this.request.numeroDocumento = '';
    this.request.password = '';

    if (tipo.tipoDocumento == 'DNI' || tipo.tipoDocumento == 'RUC') {
      this.keyFilter = 'num';
    } else {
      this.keyFilter = 'alphanum';
    }

    this.tipo = '';
    if (this.documento != null) {
      this.documento = '';
      this.pass = '';
    }

    if (this.pass != null) {
      this.documento = '';
    }
  }

  validacionForm = (valid: Credential): boolean => {
    this.result = true;
    if (valid.tipoDocumento == 0) {
      this.tipo = 'Seleccion un tipo de documento';
      this.result = false;
    }

    if (valid.numeroDocumento == null) {
      this.documento = 'El numero de documento es requerido';
      this.result = false;
    }

    if (valid.password == null) {
      this.pass = 'Ingrese su contraseña';
      this.result = false;
    }

    if (valid.token == undefined) {
      this.captcha = 'Presione el recaptcha es requerido';
      this.result = false;
    }
    return this.result;
  };
}


