import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Credential } from '@interfaces/auth.interface';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { AuthService } from '@services/auth.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { environment } from '../../../environments/environment';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  request: Credential;
  appForm: FormGroup;
  longitud: number;
  tipo: string;
  documento: string;
  pass: string;
  captcha: string;
  result: boolean = true;
  keyFilter: string;
  version:string;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private documentTypeService: DocumentTypeService,
    private authService: AuthService,
    public messageService: MessageService
  ) {
  }

  ngOnInit(): void {
    this.version = 'version '+environment.version;
    this.appForm = this.fb.group({
      tipoDocumento: ['', [Validators.required]],
      numeroDocumento: ['', [Validators.required]],
      password: ['', [Validators.required]],
      token: ['', [Validators.required]],
    });
    this.request = {};
    this.listTuypeDocuments();
  }

  private listTuypeDocuments() {
    this.documentTypeService
      .getListTypeDocument()
      .subscribe((response) => (this.documents = response));
  }

  public logIn() {
    this.request.tipoDocumento =this.selectedTypeDocument != null ? this.selectedTypeDocument.id : 0;
    if (this.validacionForm(this.request)) {
      this.request.tipoDocumento = this.selectedTypeDocument.id;
      this.request.dispositivo = 'WEB';
      this.authService.loginAdmin(this.request).subscribe(
        (response) => {
          if (response.codigo == 200) {
              this.router.navigate(['/Web-ATU']);
            } else {
              this.messageService.showWarn('Credenciales invalidas');
            }
          },
        (error: ResponseError) => {
          console.error(error);
        }
      );
    }
  }

  public register() {
    this.router.navigate(['/register']);
  }

  public resetPassword() {
    this.router.navigate(['/reset']);
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    this.longitud = tipo.longitud;
    this.request.numeroDocumento = '';
    this.request.password = '';
    if (tipo.tipoDocumento == 'DNI' || tipo.tipoDocumento == 'RUC') {
      this.keyFilter = 'int';
    } else {
      this.keyFilter = 'alphanum';
    }
    this.tipo = '';
    if (this.documento != null) {
      this.documento = '';
      this.pass = '';
    }

    if (this.pass != null) {
      this.documento = '';
    }
  }

  validacionForm = (valid: Credential): boolean => {
    this.result = true;
    if (valid.tipoDocumento == 0) {
      this.tipo = 'Seleccion un tipo de documento';
      this.result = false;
    }

    if (valid.numeroDocumento == '') {
      this.documento = 'El numero de documento es requerido';
      this.result = false;
    }

    if (valid.password == '') {
      this.pass = 'Ingrese su contraseña';
      this.result = false;
    }

    if (valid.token == undefined) {
      this.captcha = 'Presione el recaptcha es requerido';
      this.result = false;
    }
    return this.result;
  };
}
