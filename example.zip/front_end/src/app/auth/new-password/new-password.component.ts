import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { PasswordRestRequest } from '@interfaces/request.interface';
import { MessageService } from '@services/message.service';
import { ResetPasswordService } from '@services/reset-password.service';


@Component({
  selector: 'app-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.scss']
})
export class NewPasswordComponent implements OnInit {
  token: string;
  sub: any;
  request: PasswordRestRequest;
  validPassword: boolean;
  validConfirPassword: boolean;
  buttonconfig: boolean;
  constructor(
    private router: ActivatedRoute,
    private _router: Router,
    private resetService: ResetPasswordService,
    public messageService: MessageService
  ) {

  }
  ngOnInit(): void {
    this.sub = this.router.params.subscribe(params => {
      this.token = params['token'];
      this.request = {}
    });
    this.validPassword = true;
    this.validConfirPassword = true;
    this.consultaValidacion(this.token);
  }

  private consultaValidacion(token: string) {
    this.resetService.validarToken(token).subscribe(response => {
      if (response.codigo == 200) {
        this.buttonconfig = true;
        this.validPassword = false;
        this.validConfirPassword = false;
      }
    }, (error: ResponseError) => {
      console.error(error);
      this.messageService.showWarn(error.mensaje);
      this.buttonconfig = false;
    });
  }

  public changePassword() {
    this.request.token = this.token;
    this.resetService.passwordRest(this.request).subscribe(response => {

      if (response.codigo == 200) {
        this.messageService.showSucces(response.mensaje);
        this._router.navigate([response.user == 'Administrador' ? 'login' : 'usuario/login']);
      }
    }, (error: ResponseError) => {
      console.error(error);
    })
  }

  public cancel() {
    this._router.navigate(["/login"]);
  }
}
