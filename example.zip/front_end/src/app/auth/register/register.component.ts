import { ResponseError } from './../../core/interfaces/error-response.interface';
import { PerfilesService } from './../../core/services/perfiles.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { DocumentTypeService } from '@services/document-type.service';
import { RegistroForm } from '@interfaces/auth.interface';
import { AuthService } from '@services/auth.service';
import { MessageService } from '@services/message.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  perfiles: Perfil[];
  tipoUsuarios: TipoUsuario[];
  selectedPerfil: Perfil;
  selectedTipoUsuario: TipoUsuario;
  request: RegistroForm;
  longitud: number;
  countexception: number;
  countNumdocumento: number;
  requestValid: boolean;
  valid: string;
  alpha: string;

  constructor(
    private router: Router,
    public messageService: MessageService,
    private documentTypeService: DocumentTypeService,
    private perfilService: PerfilesService,
    private authServices: AuthService
  ) {

  }

  ngOnInit(): void {
    this.alpha = 'alpha';
    this.request = {};
    this.request.apellidoValid = false;
    this.request.celularValid = false;
    this.request.confirmaValid = false;
    this.request.correoValid = false;
    this.request.direccionValid = false;
    this.request.nombreValid = false;
    this.request.numDocumentoValid = false;
    this.request.passwordValid = false;
    this.request.tipoDocIdValid = false;
    this.listTuypeDocuments();
    this.listaPerfiles();
    this.tipoUsuariosList();
  }

  private listTuypeDocuments() {
    this.documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  private listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result => {
      this.perfiles = result.reverse();
    })
  }

  public perfilByTipoUsuario(tipo: TipoUsuario) {
    this.listaPerfiles();
    this.perfiles = this.perfiles.filter(p => p.tipoUsuario.id == tipo.id);
  }

  private tipoUsuariosList() {
    this.perfilService.getTipoUsuario().subscribe(result => {
      this.tipoUsuarios = result.reverse();
    })
  }

  public registro() {
    if (this.validator(this.request)) {
      this.messageService.showWarn("Ingrese todos los datos Obligatorios");
    } else {
      this.request.tipoDocId = this.selectedTypeDocument.id;
      this.request.distritoId = 0;
      this.request.medioDispositivo = 1;
      this.request.medioRegistro = 'WEB';
      this.authServices.registro(this.request).subscribe(response => {
        if (response.codigo == 201) {
          this.messageService.showSucces(response.mensaje);
          this.router.navigate(["usuario/login"])
        }
      }, (error) => {
        console.error(error);
      });
    }
  }

  public validator(request: RegistroForm): Boolean {
    this.countexception = 0;
    if (request.apellido == null || request.apellido.length < 1) {
      this.request.apellidoValid = true;
      this.request.apellidoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.apellidoValid = false
      this.request.apellidoInputValid = '';
    }
    if (request.nombre == null || request.nombre.length < 1) {
      this.request.nombreValid = true;
      this.request.nombreInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.nombreValid = false;
      this.request.nombreInputValid = '';
    }
    if (request.direccion == null || request.direccion.length < 1) {
      this.request.direccionValid = true;
      this.request.direccionInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.direccionValid = false;
      this.request.direccionInputValid = '';
    }
    if (request.password == null || request.password.length < 1) {
      this.request.passwordValid = true;
      this.request.passwordInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.passwordValid = false;
      this.request.passwordInputValid = '';
    }
    if (request.confirmaPassword == null || request.confirmaPassword.length < 1) {
      this.request.confirmaValid = true;
      this.request.confirmaInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.confirmaValid = false;
      this.request.confirmaInputValid = '';
    }
    if (request.correo == null || request.correo.length < 1) {
      this.request.correoValid = true;
      this.request.correoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.correoValid = false;
      this.request.correoInputValid = '';
    }
    if (this.selectedTypeDocument == null) {
      this.request.tipoDocIdValid = true;
      this.request.tipoDocIdInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.tipoDocIdValid = false;
      this.request.tipoDocIdInputValid = '';
    }
    if (request.numDocumento == null || request.numDocumento.length <= 1) {
      this.request.numDocumentoValid = true;
      this.request.numDocumentoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.numDocumentoValid = false;
      this.request.numDocumentoInputValid = '';
    }
    if (this.countexception != 0) {
      this.requestValid = true;
    } else {
      this.requestValid = false;
    }
    return this.requestValid;
  }

  public numDocumento(doc: string) {
    this.countNumdocumento = doc.length;
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    this.longitud = tipo.longitud;
    this.request.numDocumento = '';
    this.countNumdocumento = 0;
    if (tipo.id == 3 || tipo.id == 2) {
      this.valid = 'alphanum'
    } else {
      this.valid = 'int'
    }
  }

  public cancel() {
    this.router.navigate(["usuario/login"])
  }
}
