import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { EmailRequest } from '@interfaces/request.interface';
import { ResetPasswordService } from '@services/reset-password.service';
import { Location } from '@angular/common';
import { MessageService } from '@services/message.service';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.scss']
})
export class ResetComponent implements OnInit {
  request: EmailRequest;
  text: string;
  result: boolean = false;
  constructor(
    private _router: Router,
    private _location: Location,
    private resetService: ResetPasswordService,
    public messageService: MessageService
  ) {
    this.text = 'Ingresa tu correo y te enviaremos un enlace para cambiar tu contraseña.';
  }
  ngOnInit(): void {
    this.request = {};
  }

  public sendEmail() {

    this.resetService.sendEmail(this.request).subscribe(response => {
      console.log(response);
      if (response.codigo == 200) {
        this.text = '';
        this.text = 'Revisa tu bandeja (' + this.request.email + ') Te enviamos un correo de "restablecer contraseña" con un link para que puedas realizar el cambio.'
        this.result = true;
        this.messageService.showSucces(response.mensaje);
        if (response.user == 'Administrador') {
          this._router.navigate(["login"])
        } else {
          this._router.navigate(["usuario/login"])
        }
      }
    });
  }

  public back() {
    this._location.back();
  }
}
