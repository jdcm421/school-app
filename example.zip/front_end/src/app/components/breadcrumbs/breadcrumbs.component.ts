import { Component } from '@angular/core';
import { ActivationEnd, Router } from '@angular/router';
import { filter, map, Subscription } from 'rxjs';

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent {
  centro:string;
  titulo: string;
  public tituloSubs$: Subscription;

  constructor(
    private _router: Router
  ) {
  }

  ngOnInit(): void {
    this.tituloSubs$ = this.geDataRuta().subscribe(({ title }) => {
      this.titulo = '';
      this.centro = localStorage.getItem('center') != null? localStorage.getItem('center') : '';
      if(this.centro != null && title === 'Sucursales' && title === 'Sucursales por Centro'){
        this.titulo = title +' '+ this.centro;
      }else{
        localStorage.removeItem('center');
        this.titulo = title;
      }
      document.title = `ATU - ${title}`
    });
  }

  geDataRuta() {
    return this._router.events.pipe(
      filter(evet => evet instanceof ActivationEnd),
      filter((evet: ActivationEnd) => evet.snapshot.firstChild === null),
      map((evet: ActivationEnd) => evet.snapshot.data)
    );
  }

  ngOnDestroy(): void {
    this.tituloSubs$.unsubscribe();
  }
}
