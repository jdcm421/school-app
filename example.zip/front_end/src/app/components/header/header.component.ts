import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponsePassenger } from '@interfaces/response.interface';
import { ProfileUsersComponent } from '@modals/passenger/profile-users/profile-users.component';
import { AuthService } from '@services/auth.service';
import { MessageService } from '@services/message.service';
import { SidebarService } from '@services/sidebar.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ResponseErrorEx } from './../../core/interfaces/error-response.interface';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [DialogService]
})
export class HeaderComponent implements OnInit {
  private ref: DynamicDialogRef;
  items: MenuItem[];
  rol:string= localStorage.getItem('rol');
  isShowSidebar: boolean;
  nombres:string = localStorage.getItem('nombre');

  constructor(
    private router: Router,
    public dialogService: DialogService,
    private _sidebarService: SidebarService,
    private _authService : AuthService,
    public messageService: MessageService
  ) { }

  ngOnInit(): void {
    this._sidebarService.sidebar$
      .subscribe( (response) => this.isShowSidebar = response);
      if(this.rol == 'Pasajero'){
        this.items = [
          {
            label: 'Editar Perfil',
            icon: 'pi pi-fw pi-user-edit',
            command: () => {
              this.showUseRegister();
            }
          },
          {
            label: 'Cerrar sesión',
            icon: 'pi pi-fw pi-sign-out',
            command: () => {
              this.logoutUser();
            }
          },
        ];
      }else if(this.rol != 'Pasajero' && this.rol != 'Administrador'){
        this.items = [
          {
            label: 'Cerrar sesión',
            icon: 'pi pi-fw pi-sign-out',
            command: () => {
              this.logoutUser()
            }
          },
        ];
      }else{
        this.items = [
          {
            label: 'Cerrar sesión',
            icon: 'pi pi-fw pi-sign-out',
            command: () => {
              this.logout();
            }
          },
        ];
      }
  }
  public openClose() {
    if(this.isShowSidebar) {
      return this._sidebarService.close();
    }
    this._sidebarService.open();
  }

  public logout(){
    this._authService.logout().subscribe(response => {
      if(response.codigo == 200){
        if(this.rol == 'Administrador'){
          this.router.navigateByUrl("login").then(res => {
            window.location.reload();
          });
        }
      }
    }, (error:ResponseErrorEx) => {
      console.error(error);
    });
  }

  public logoutUser(){
    this._authService.logoutUser().subscribe(response => {
      if(response.codigo == 200){
        this.router.navigateByUrl("usuario/login").then(res => {
          window.location.reload();
        });
      }
    }, (error:ResponseErrorEx) => {
      console.error(error);
    });
  }

  public showUseRegister() {
    this.ref = this.dialogService.open(ProfileUsersComponent, {
      header: 'Editar Usuario',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponsePassenger) => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
      }
  });
  }
}
