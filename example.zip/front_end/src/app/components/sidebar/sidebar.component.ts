import { Component, OnInit } from '@angular/core';
import { appRout } from "@helpers/constants/index";
import { Administrador } from '@interfaces/admin/response/adminResponse';
import { ResponseError } from '@interfaces/error-response.interface';
import { Modulo } from '@interfaces/passenger.interface';
import { AdministradorService } from '@services/admin/administrador.service';
import { MessageService } from '@services/message.service';
import { SidebarService } from '@services/sidebar.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  menu: any[] = [];
  modulos:Modulo[]=[];
  display: boolean = false;
  rol:string=localStorage.getItem('rol');
  admin:Administrador={};
  value: Date;
  modal: any;
  size$: Observable<string>;
  item:any;
  constructor(
    private _sidebarService: SidebarService,
    private authService : AdministradorService,
    public messageService: MessageService
  ) {
   }


  ngOnInit(): void {
    this.modal = this._sidebarService.sidebarMode$;
    this._sidebarService.sidebar$.subscribe((response) => this.display = response);
    this.admin = {};

    if(this.rol == 'Pasajero'){
        this.menu.push(
          {
            items: [
              { label: "Movimientos", icon: 'bi bi-arrow-repeat', rout: appRout.movimientosPassenger.route },
              { label: "Empresa de transporte", icon: 'bi bi-bus-front-fill', rout: appRout.empresaTransporte.route },
              { label: "Centros de recargas", icon: 'bi bi-geo-alt', rout: appRout.centroRecargaPassenger.route },
              { label: "Gestion Derechos Arcos", icon: 'bi bi-file-earmark-bar-graph', rout: appRout.gestion.path },
              { label: "Dudas y consultas", icon: 'bi bi-question-circle', rout: appRout.duda.route }
            ]
          }
        );
    }else if(this.rol == 'Administrador'){
      this.profile();
      }else if(this.rol == 'Empresa Transporte'){
        this.menu.push(
          {
            items: [
              { label: "Control Tarifario", icon: 'bi bi-file-break-fill', rout: appRout.control.route },
              { label: "Historial Tarifario", icon: 'bi bi-card-list', rout: appRout.historial.route },
              { label: "Generador Qr's", icon: 'bi bi-qr-code-scan', rout: appRout.qr.route },
              { label: "Reporte Fideicomiso", icon: 'bi bi-arrow-repeat', rout: appRout.reporteFideicomisoTransporte.route },
              { label: "Movimientos", icon: 'bi bi-arrow-repeat', rout: appRout.movimientosEmpresaTransporte.route },
              { label: "Contactanos", icon: 'bi bi-chat-left', rout: appRout.reclamos.route},
            ]
          }
        );
      }else if(this.rol == 'Operador Apps'){
        this.menu.push(
          {
            items: [
              { label: "Reporte Detallado", icon: 'bi bi-file-earmark-bar-graph', rout: appRout.reporteDetalladoOperador.path },
              { label: "Reporte Fideicomiso", icon: 'bi bi-file-earmark-bar-graph', rout: appRout.reporteFideicomisoOperador.route },
            ]
          }
        );
      }else{
        this.menu.push(
          {
            items: [
              { label: "Sucursales", icon: 'pi pi-home', rout: appRout.sucursalesUserCentro.route },
              { label: "Reporte Detallado", icon: 'bi bi-file-earmark-bar-graph', rout: appRout.reporteDetalladoCentroRecarga.route },
              { label: "Reporte Fideicomiso", icon: 'bi bi-arrow-repeat', rout: appRout.reporteFideicomisoCentroRecarga.route },
            ]
          }
        );
      }
  }

  profile(){
    if(this.menu.length <= 0){
      this.authService.profile().subscribe(response => {
        this.admin = response.admin;
        this.modulos = this.admin.modulos;
        this.modulos.forEach((m,i)=> {
          this.item = {
            label:m.modulos,
            icon:m.icon,
            rout:m.path
          }
          this.menu.push({items:[this.item]});
        });
      }, (error:ResponseError) =>{
        console.error(error);
      });
    }
  }

  public onHideSideBar() {
    this._sidebarService.close();
  }
}
