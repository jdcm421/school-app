import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestRefreshToken } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { MessageService } from '@services/message.service';
import {
  BehaviorSubject,
  Observable,
  catchError,
  filter,
  switchMap,
  take,
  throwError
} from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private token:string;
  private isRefreshing = false;
  private requestRefresToken: RequestRefreshToken;
  private atuToken:string;

  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(
    null
  );
  constructor(
    private router: Router,
    private authService: AuthService,
    private messageService: MessageService
  ) {
    this.requestRefresToken = {};
  }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<Object>> {
    return next.handle(request).pipe(
      catchError((error) => {
        console.log(error);
        if (
          (error instanceof HttpErrorResponse &&
            request.url.includes('auth/refresh-token') &&
            error.status === 403) ||
          error.status === 401
        ) {
          this.handle401Error(request, next);
        }
        return throwError(() => error);
      })
    );
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
    console.log('AQUI handle401Error')
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
      if(request.url.includes('admin')){
        this.token = this.authService.getRefreshToken();
      }else{
        this.token = this.authService.getRefreshTokenUser();
      }
      console.log(this.token);
      if (this.token)
      this.requestRefresToken.refreshToken = this.token;
        return this.authService.refreshToken(this.requestRefresToken).subscribe(response =>{
          if(response.token !== undefined && response.token !== null){
            this.authService.saveAdminToken(response);
            this.atuToken = response.token;
          }else{
            this.authService.saveToken(response);
            this.atuToken = response.atuToken;
          }
          return next.handle(
            this.addTokenHeader(request,this.atuToken)
          );
        }, (error:ResponseError) => {
          console.log(error);
          this.isRefreshing = false;
          this.logout();
          return throwError(error);
        });
    }
    return this.refreshTokenSubject.pipe(
      filter((token) => token !== null),
      take(1),
      switchMap((token) => next.handle(this.addTokenHeader(request, token)))
    );
  }

  private addTokenHeader(request: HttpRequest<any>, token: string) {
    return request.clone({
      headers: request.headers.set('Authorization', 'Bearer ' + token),
    });
  }

  private logout() {
    var rol: string = localStorage.getItem('rol');
    if (rol.toUpperCase() == 'ADMINISTRADOR') {
      this.authService.deleteTokenLocal();
      this.router.navigateByUrl('login').then((res) => {
        this.messageService.showWarn('Su sesión ha caducado. Por favor vuelva a iniciar sesión');
      });
    } else {
      this.authService.deleteTokenLocalUser();
      this.router.navigateByUrl('usuario/login').then((res) => {
        this.messageService.showWarn('Su sesión ha caducado. Por favor vuelva a iniciar sesión');
      });
    }
  }
}
