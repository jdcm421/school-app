import { Location } from '@angular/common';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { MessageService } from '@services/message.service';
import { Observable, catchError, throwError } from 'rxjs';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  error: ResponseError;
  contador: number;
  constructor(private messageService: MessageService,
    private _location: Location) {
    this.error = {};
    this.contador = 0;
  }
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(
      catchError((reponse: HttpErrorResponse) => {
        this.contador += 1;
        console.log(reponse);
        this.error.codigo = reponse.status;
        this.error.status = reponse.statusText;
        this.error.mensaje = reponse.error.message !== undefined ? reponse.error.message : reponse.error.mensaje;
        if (this.error.codigo  == 0 && this.contador == 1) {
          this.error.mensaje = 'Servicios no disponibles';
          this.messageService.showError(this.error.mensaje);
        } else if (this.error.codigo == 403 && this.contador == 1) {
          this._location.back();
          this.error.mensaje = 'Acceso no Prohibido';
          this.messageService.showError(this.error.mensaje);
        } else if (this.error.codigo == 500 && this.contador == 1) {
          this.error.mensaje = reponse.error.message;
          this.messageService.showError(this.error.mensaje);
        } else {
          console.log(this.error);
          if(this.contador == 1 ){
            this.messageService.showWarn(this.error.mensaje)
          }
        }
        return throwError(() => this.error);
      }))
  }
}
