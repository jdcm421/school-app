import { Modulo } from '@interfaces/passenger.interface';

export interface AdminRequestAdministrador {
  apellido?:     string;
  celular?:      number;
  correo?:       string;
  distritoId?:   number;
  modulos?:      Modulo[];
  nombre?:       string;
  numDocumento?: number;
  rolId?:        number;
  tipoDocId?:    number;
  tipoUsuario?:  string;
}
