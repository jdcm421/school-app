import { Modulo } from "@interfaces/passenger.interface";

export interface AdminRequestUpdateAdmin {
  apellido?:    string;
  celular?:     number;
  distritoId?:  number;
  modulos?:     Modulo[];
  nombre?:      string;
  tipoUsuario?: string;
}
