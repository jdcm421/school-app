import { ResponseATU, TipoDispositivo, TipoOperaciones } from "@interfaces/response.interface";

export interface AdminBitacorasResponse extends ResponseATU {
  bitacoras?:          AdminBitacora[];
  puntos?:             AdminPunto[];
  fechaActualizacion?: string;
}

export interface AdminBitacora {
  id?:              number;
  puntoVenta?:      string;
  fecha?:           string;
  tiempoOperacion?: string;
  intentos?:        number;
  dispositivo?:     TipoDispositivo;
  tipoOperacion?:   TipoOperaciones;
  resultado?:       string;
  detalle?:         string;
}

export interface AdminPunto {
  puntoVenta?: string;
}
