import { ResponseATU } from "@interfaces/response.interface";

export interface AdminEmpresaTransporteResponse extends ResponseATU {
  transportista?:      AdminEmpresaTransportista[];
  fechaActualizacion?: string;
}

export interface AdminEmpresaTransportista {
  asientos?:          number;
  empresaTransporte?: string;
  estado?:            boolean;
  id?:                number;
  numDocumento?:      string;
  placa?:             string;
  ruta?:              string;
  unidad?:            string;
}
