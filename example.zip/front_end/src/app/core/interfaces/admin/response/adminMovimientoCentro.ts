import { ResponseATU } from "@interfaces/response.interface";

export interface AdminMovimientoCentro extends ResponseATU {
  movimientos?: AdminMovimientoCentro[];
  fechaActualizacion?: string;
}

export interface AdminMovimientoCentro {
  centro?:       string;
  documento?:    string;
  fecha?:        Date;
  hora?:         Date;
  id?:           number;
  monto?:        number;
  montoComsion?: number;
  pasajero?:     string;
}
