import { ResponseATU } from "@interfaces/response.interface";

export interface AdminMovimientoOperador extends ResponseATU {
  movimientos?: AdminMovimientoOperadores[];
  fechaActualizacion?: string;
}

export interface AdminMovimientoOperadores {
  Origen?:          string;
  empresa?:         string;
  fecha?:           Date;
  hora?:            Date;
  id?:              number;
  monto?:           number;
  numDocumento?:    string;
  pasajero?:        string;
  placa?:           string;
  tipoOperaciones?: string;
}
