import { ResponseATU } from "@interfaces/response.interface";
import { Distrito } from "@interfaces/ubigeo.interface";

export interface AdminMovimientoResponse extends ResponseATU {
  movimientos?:        AdminMovimiento[];
  detalle?:            AdminMovimientoDetalle;
  fechaActualizacion?: string;
}

export interface AdminMovimientoDetalle {
  centro?:      string;
  direccion?:   string;
  distrito?:    Distrito;
  empresa?:     string;
  id?:          number;
  placa?:       string;
  abrev?:       string;
  puntoOrigen?: string;
  ruta?:        string;
}

export interface AdminMovimiento {
  abrev?:         string;
  apellidos?:     string;
  documento?:     string;
  fecha?:         Date;
  hora?:          Date;
  id?:            number;
  monto?:         number;
  nombre?:        string;
  placa?:         string;
  ruta?:          string;
  tipoDoc?:       string;
  tipoOperacion?: string;
}

