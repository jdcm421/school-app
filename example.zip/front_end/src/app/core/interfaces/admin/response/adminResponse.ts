import { TipoDocumento } from "@interfaces/documenType.interface";
import { Modulo } from "@interfaces/passenger.interface";
import { ResponseATU } from "@interfaces/response.interface";

export interface AdminResponse extends ResponseATU {
  admin?:   Administrador;
  admins?:  Administradores[];
}

export interface Administradores {
  apellidos?:     string;
  celular?:       string;
  correo?:        string;
  estado?:        boolean;
  id?:            number;
  nombre?:        string;
  numDocumento?:  string;
  tipoDocumento?: string;
}

export interface Administrador {
  apellidos?:     string;
  celular?:       string;
  correo?:        string;
  id?:            number;
  modulos?:       Modulo[];
  nombre?:        string;
  numDocumento?:  string;
  tipo?:          string;
  tipoDocumento?: TipoDocumento;
}
