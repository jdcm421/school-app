import { ResponseATU } from "@interfaces/response.interface";

export interface AdminSurcusalesResponse extends ResponseATU {
  sucursales?: AdminSucursale[];
}

export interface AdminSucursale {
  direccion?:     string;
  id?:            number;
  nombreCentro?:  string;
  numDocumento?:  string;
  tipoDocumento?: string;
  ubigeo?:        string;
}
