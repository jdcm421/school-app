import { ResponseToken } from './response.interface';
import { TipoDocumento } from "./documenType.interface";
import { Distrito } from "./ubigeo.interface";
import { Perfil } from "./roles.interface";

export interface RegistroForm {
  apellido?: string;
  apellidoValid?: boolean;
  apellidoInputValid?: string;
  celular?: number;
  celularValid?: boolean;
  celularInputValid?: string;
  confirmaPassword?: string;
  confirmaValid?: boolean;
  confirmaInputValid?: string;
  correo?: string;
  correoValid?: boolean;
  correoInputValid?: string;
  direccion?: string;
  direccionValid?: boolean;
  direccionInputValid?: string;
  distritoId?: number;
  medioDispositivo?: number;
  medioRegistro?: string;
  nombre?: string;
  nombreValid?: boolean;
  nombreInputValid?: string;
  numDocumento?: string;
  numDocumentoValid?: boolean;
  numDocumentoInputValid?: string;
  password?: string;
  passwordValid?: boolean;
  passwordInputValid?: string;
  perfil?: number;
  tipoDocId?: number;
  tipoDocIdValid?: boolean;
  tipoDocIdInputValid?: string;
  tipoUsuario?: string;
}

export interface UpdatedPassenger {
  apellido?: string;
  celular?: string;
  correo?: string;
  direccion?: string;
  distritoId?: number;
  medioRegistro?: string;
  nombre?: string;
  numDocumento?: string;
  perfil?: number;
  tipoDocId?: number;
  tipoUsuario?: string;
}

export interface LoginForm {
  numeroDocumento?: boolean;
  password?: boolean;
  tipoDocumento?: boolean;
}
export interface Credential {
  dispositivo?: string;
  numeroDocumento?: string;
  password?: string;
  tipoDocumento?: number;
  token?: string;
}

export interface Usuario {
  id?: number;
  nombre?: string;
  apellidos?: string;
  nombreCompleto?: string;
  nombreEmpresa?: string;
  correo?: string;
  distrito?: Distrito;
  celular?: string;
  direccion?: string;
  medioRegistro?: string;
  tipoUsuario?: string;
  perfil?: Perfil;
}
