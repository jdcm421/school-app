export interface TipoDocumento {
    id?: number;
    tipoDocumento?: string;
    longitud?: number;
    validacion?:string;
}
