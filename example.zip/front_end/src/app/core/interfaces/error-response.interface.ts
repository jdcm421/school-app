export interface ResponseError extends ResponseErrorEx {
  codigo?: number;
  mensaje?: string;
  status?: string;
}

export interface ResponseErrorEx {
  detalles?: string;
  timestamp?: Date;
}
