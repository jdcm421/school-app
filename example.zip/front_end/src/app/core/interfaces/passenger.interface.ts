import { Usuario } from "./auth.interface";
import { TipoDocumento } from "./documenType.interface";

export interface PassengerPage {
  id?: number;
  tipoDocumento?: TipoDocumento;
  numDocumento?: string;
  usuario?: Usuario;
  admin?: Admin;
  estado?: boolean;
  fechaValidez?: string;
}

export interface Modulo {
  id?: number;
  modulos?: string;
  icon?: string;
  position?:number;
  path?: string;
}

export interface Role {
  id?: number;
  rol?: string;
}

export interface Admin {
  id?: number;
  role?: Role;
  modulos?: Modulo[];
}
