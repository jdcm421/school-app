export interface UploadEvent {
  originalEvent: Event;
  files: File[];
}
