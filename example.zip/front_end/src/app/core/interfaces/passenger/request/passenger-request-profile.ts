export interface PassengerRequestProfile {
  apellido?:   string;
  celular?:    string;
  correo?:     string;
  direccion?:  string;
  distritoId?: number;
  nombre?:     string;
}
