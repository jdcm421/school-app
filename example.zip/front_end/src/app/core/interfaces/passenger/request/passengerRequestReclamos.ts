export interface PassengerRequestReclamos {
  asunto?:        string;
  celular?:       string;
  correo?:        string;
  empresaId?:     number;
  nombreEmpresa?: string;
  adjuntar?:      string;
}


