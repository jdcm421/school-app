import { ResponseATU } from "@interfaces/response.interface";


export interface ResponsePassengerCentro extends ResponseATU{
  centro?:  Centro;
}

export interface ResponsePassengerCentros extends ResponseATU{
  centros?: Centro[];
}

export interface Centro {
  direccion?:           string;
  id?:                  number;
  nombreCentroRecarga?: string;
}
