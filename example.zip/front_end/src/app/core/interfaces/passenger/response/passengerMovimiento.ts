import { ResponseATU } from "@interfaces/response.interface";


export interface ResponsePassengerMovimientos extends ResponseATU {
  movimientos?: Movimiento[];
  saldo?:       number;
}

export interface ResponsePassengerMovimiento extends ResponseATU {
  movimiento?:  DetailMovimientoPassenger;
}

export interface Movimiento {
  abrev?:           string;
  fecha?:           Date;
  hora?:            Date;
  id?:              number;
  monto?:           number;
  tipoOperaciones?: string;
}

export interface DetailMovimientoPassenger{
  abrev?:           string;
  centro?:          string;
  direccion?:       string;
  empresa?:         string;
  fecha?:           Date;
  hora?:            Date;
  id?:              number;
  monto?:           number;
  operador?:        string;
  placa?:           string;
  ruta?:            string;
  tipoOperaciones?: string;
  ubigeo?:          string;
}
