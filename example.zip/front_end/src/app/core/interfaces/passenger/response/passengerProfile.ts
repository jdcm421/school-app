import { TipoDocumento } from "@interfaces/documenType.interface";
import { ResponseATU } from "@interfaces/response.interface";
import { Perfil } from "@interfaces/roles.interface";
import { Distrito } from "@interfaces/ubigeo.interface";

export interface PassengerProfile extends ResponseATU {
  profile?: Profile;
}

export interface Profile {
  id?: number;
  tipoDocumento?: TipoDocumento;
  numDocumento?:string;
  nombre?: string;
  apellido?: string;
  correo?: string;
  celular?: string;
  direccion?: string;
  perfil?: Perfil;
  distrito?: Distrito;
}
