import { ResponseATU } from "@interfaces/response.interface";

export interface PassengerReclamos extends ResponseATU {
  admin?:   Admin;
  admins?:  Admin[];
}

export interface Admin {
  id?:            number;
  nombreEmpresa?: string;
}
