import { ResponseATU } from "@interfaces/response.interface";
import { Distrito } from "@interfaces/ubigeo.interface";

export interface ResponsePassengerSucursales extends ResponseATU {
  sucursales?: Sucursal[];
}

export interface ResponsePassengerSucursal extends ResponseATU {
  sucursal?:   Sucursal;
}

export interface Sucursal {
  direccion?:     string;
  distritos?:     Distrito;
  id?:            number;
  nombreCentro?:  string;
  ruc?:           string;
  tipoDocumento?: string;
}
