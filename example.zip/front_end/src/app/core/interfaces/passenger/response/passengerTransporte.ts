import { ResponseATU } from "@interfaces/response.interface";

export interface ResponsePassengerTransportes extends ResponseATU {
  transportes?: PassengerTransporte[];
}

export interface PassengerTransporte {
  codigoRuta?:    string;
  id?:            number;
  nombreEmpresa?: string;
  ruc?:           string;
}
