import { Modulo } from "./passenger.interface";
import { TipoUsuario } from "./roles.interface";
export interface RequestPage {
  centroCarga?: string;
  codigoRuta?: string;
  direccion?: string;
  distritoId?: number;
  fecha?: string;
  id?: number;
  medioRegistro?: string;
  nombreCentroCarga?: string;
  nombreCompleto?: string;
  nombreEmpresa?: string;
  numDocumento?: string;
  numeroAsiento?: number;
  perfil?: number;
  placaRegistro?: string;
  puntoVenta?: string;
  rucEmpresa?: number;
  tipoDispositivo?: number;
  tipoDocumento?: number;
  tipoOperacion?: number;
  tipoUnidad?: string;
  tipoUsuario?: string;
}

export interface RequestAdmin {
  apellido?: string;
  apellidoValid?: boolean;
  apellidoInputValid?: string;
  celular?: string;
  celularValid?: boolean;
  celularInputValid?: string;
  correo?: string;
  correoValid?: boolean;
  correoInputValid?: string;
  distritoId?: number;
  distritoIdValid?: boolean;
  distritoIdInputValid?: string;
  modulos?: Modulo[];
  modulosValid?: boolean;
  nombre?: string;
  nombreValid?: boolean;
  nombreInputValid?: string;
  nombreEmpresa?: string;
  nombreEmpresaValid?: boolean;
  nombreEmpresaInputValid?: string;
  numDocumento?: string;
  numDocumentoValid?: boolean;
  numDocumentoInputValid?: string;
  rolId?: number;
  direccion?: string;
  direccionValid?: boolean;
  direccionInputValid?: string;
  tipoDocId?: number;
  tipoDocIdValid?: boolean;
  tipoDocIdInputValid?: string;
  perfil?: number;
  tipoUsuario?: TipoUsuario;
  tipoUsuarioValid?: boolean;
  tipoUsuarioInputValid?: string;
}

export interface RequestProfileUpdated {
  apellido?: string;
  celular?: string;
  correo?: string;
  direccion?: string;
  distritoId?: number;
  nombre?: string;
  perfil?: number;
  tipoUsuario?: string;
}

export interface RequestAdminUpdated {
  apellido?: string;
  celular?: string;
  distritoId?: number;
  modulos?: Modulo[];
  nombre?: string;
  tipoUsuario?: TipoUsuario;
}

export interface RequestPassengerUpdated {
  celular?: string;
  direccion?: string;
  distritoId?: number;
  perfil?: number;
  tipoUsuario?: string;
}

export interface RequestUserUpdated {
  celular?: string;
  direccion?: string;
  distritoId?: number;
}

export interface EmailRequest {
  email?: string;
}


export interface PasswordRestRequest {
  confirmPassword?: string;
  password?: string;
  token?: string;
}

export interface requestDetail {
  fechaFin?: string;
  fechaInicio?: string;
  fechaFinDate?: Date;
  fechaInicioDate?: Date;
  numDocumento?: string;
  tipo?: string;
}

export interface requestFidei {
  fidei?: number;
}

export interface requestPago {
  fechaFin?: string;
  fechaInicio?: string;
  nombreEmpresa?: string;
  numDocumento?: string;
}

export interface RequestRefreshToken {
  refreshToken?: string;
}

export interface RequestSucursal {
  centroRecarga?: number;
  direccion?: string;
  distritoId?: number;
}
