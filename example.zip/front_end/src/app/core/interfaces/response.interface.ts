import { TipoDocumento } from "./documenType.interface";
import { Modulo, PassengerPage, Role } from './passenger.interface';
import { Perfil } from './roles.interface';
import { Distrito } from './ubigeo.interface';

export interface ResponseATU {
  codigo?: number;
  mensaje?: string;
  status?: string;
  user?: string;
}

export interface ResponseToken extends ResponseATU {
  atuRefreshToken?: string;
  atuToken?: string;
  cuenta?: PassengerPage;
  refreshToken?: string;
  token?: string;
}

export interface ResponsePassengerPage extends ResponseATU {
  usuarios?: PassengerPage[];
}

export interface ResponseAdminPage extends ResponseATU {
  admins?: PassengerPage[];
}

export interface ResponseTranportistaPage extends ResponseATU {
  transportista?: PassengerPage[];
}

export interface ResponseCentroRecargaPage extends ResponseATU {
  usuarios?: PassengerPage[];
}

export interface ResponseAdmin extends ResponseATU {
  admin?: PassengerPage;
}

export interface ResponseTransportista extends ResponseATU {
  transportista?: PassengerPage;
}

export interface ResponseCentroRecargaUser extends ResponseATU {
  usuario?: PassengerPage;
}

export interface ResponseRegisterUser extends ResponseATU {
  cuenta?: PassengerPage;
}

export interface ResponsePassenger extends ResponseATU {
  usuario?: PassengerPage;
}

export interface ResponseBitacoras extends ResponseATU {
  bitacoras?: Bitacora[];
  puntos?: puntosVenta[];
  fechaActualizacion?: string;
}


export interface ResponseCentroRecarga extends ResponseATU {
  centros?: CentroResponse[];
  fechaActualizacion?: string;
}

export interface ResponseCentroRecargaAlone extends ResponseATU {
  centro?: CentroResponse;
}

export interface MovimientoPassenger extends ResponseATU {
  movimientos?: Movimiento[];
  saldo?: number;
  fechaActualizacion?: string;
}

export interface MovimientoAdmin extends ResponseATU {
  movimientos?: Movimiento[];
  fechaActualizacion?: string;
}

export interface MovimientoAlone extends ResponseATU {
  movimiento?: Movimiento;
}

export interface EmpresaAdmin extends ResponseATU {
  empresaTransporte?: Transporte[];
  fechaActualizacion?: string;
}

export interface EmpresasPasajero extends ResponseATU {
  empresasTransporte?: EmpresaTransporte[];
  fechaActualizacion?: string;
}

export interface EmpresaAlone extends ResponseATU {
  empresa?: Transporte;
}

export interface TarifaList extends ResponseATU {
  tarifarios?: Tarifas[];
}

export interface TarifaOnly extends ResponseATU {
  tarifario?: Tarifas;
}

export interface HistorialList extends ResponseATU {
  historial?: Historial[];
}

export interface ReporteDetIndicadoresList extends ResponseATU {
  detalleIndicadores: DetalleIndicadore[];
}

export interface ReporteIndicadoresList extends ResponseATU {
  reporteIndicadores: ReporteIndicadore[];
}

export interface ResponseTipoDispositivo extends ResponseATU {
  tipoDispositivos?: TipoDispositivo[];
}

export interface ResponseTipoOperaciones extends ResponseATU {
  tipoOperaciones: TipoOperaciones[];
}

export interface ResponseSucursales extends ResponseATU {
  sucursales: Sucursal[];
}

export interface ResponseSucursal extends ResponseATU {
  sucursal: Sucursal;
}
export interface ResponseDistrito extends ResponseATU {
  distritos: Distrito[];
}

export interface ResponseRoles extends ResponseATU {
  rol?: Role;
  roles?: Role[];
}

export interface EmpresaTransporte {
  nombreEmpresa?: string;
  ruc?: string;
  codigoRuta?: string;
}

export interface Sucursal {
  centroRecarga?: CentroResponse;
  direccion?: string;
  distrito?: Distrito;
  estado?: boolean;
  horarioFin?: string;
  horarioInicio?: string;
  id?: number;
}

export interface TipoDispositivo {
  id?: number;
  nombre?: string;
}

export interface ReporteIndicadore {
  id?: number;
  idTransaccion?: string;
  fechaTransaccion?: Date;
  horaTransaccion?: string;
  detalleIndicadores?: DetalleIndicadore[];
}

export interface DetalleIndicadore {
  empresa?: string;
  fechaTransaccion?: Date;
  horaTransaccion?: string;
  id?: number;
  idTransaccion?: string;
  montoPago?: number;
  montoTotal?: number;
  numDocumento?: string;
  tipoOperacion?: string;
}

export interface Empresa {
  empresaTransporte?: string;
  id?: number;
  ruc?: string;
}

export interface Transporte {
  codigoRuta?: string;
  empresa?: Empresa;
  estado?: boolean;
  id?: number;
  numeroAsientos?: number;
  placa?: string;
  tipoUnidad?: string;
  comision?: Comision;
}

export interface Movimiento {
  centroRecarga?: Sucursal;
  fecha?: Date;
  fechaMovimiento?: Date;
  hora?: Date;
  id?: number;
  latitud?: string;
  longitud?: string;
  monto?: number;
  comisionTransporte?: number;
  comisionPasajero?: number;
  comisionCentro?: number;
  operador?: PassengerPage;
  pasajero?: PassengerPage;
  fideicomiso?: number;
  tipoOperaciones?: TipoOperaciones;
  transporte?: Transporte;
}

export interface CentroResponse {
  comision?: Comision;
  direccion?: string;
  distrito?: Distrito;
  estado?: boolean;
  id?: number;
  nombreCentroRecarga?: string;
  ruc?: string;
  tipoDocumento?: TipoDocumento;
}

export interface Empresa {
  empresaTransporte?: string;
  id?: number;
  ruc?: string;
}


export interface Recarga {
  expiracion?: Date;
  fechaRecarga?: Date;
  id?: number;
  latitud?: string;
  longitud?: string;
  monto?: number;
}

export interface Reclamo {
  correo?: string;
  detalleQueja?: string;
  id?: number;
  motivoQueja?: string;
  transportista?: Transporte;
}

export interface Transportista {
  codigoRuta?: string;
  empresa?: Empresa;
  estado?: boolean;
  id?: number;
  númeroAsientos?: number;
  placa?: string;
  qrUrl?: string;
  tipoUnidad?: string;
}

export interface Tarifas {
  equivalencia?: string;
  estado?: boolean;
  id?: number;
  perfil?: Perfil;
  precio?: number;
  tipoTarifa?: string;
  codigoRuta?: string;
  transportista?: Empresa;
}

export interface Historial {
  equivalencia?: string;
  id?: number;
  perfil?: Perfil;
  precio?: number;
  tipoTarifa?: string;
  transportista?: Transportista;
  detalle?: string;
  fecha?: string;
  hora?: string;
}


export interface Bitacora {
  detalleActividad?: string;
  fechaTransaccion?: string;
  id?: number;
  inicioActividad?: Date;
  intentosOperacion?: number;
  puntoVenta?: string;
  resultadosActividad?: string;
  terminoActividad?: Date;
  tiempoOperacion?: number;
  tipoOperacion?: string;
  tipoDispositivo?: string;
}

export interface Ducas {
  asunto?: string;
  celular?: string;
  correo?: string;
  empresatransporte?: Empresa;
  id?: number;
}

export interface Comision {
  id?: number;
  usuario?: string;
  comision?: number;
}

export interface puntosVenta {
  puntoVenta?: string;
}

export interface Reporte {
  tipoOperacion?: string;
  id?: number;
  numDocumento?: string;
  fecha?: Date;
  hora?: string;
  agente?: string;
  empresa?: string;
  recargas?: number;
  transporte?: number;
  comisionRecarga?: number;
  comisionPasajero?: number;
  comisionTransporte?: number;
  fideicomiso?: number;
}


export interface TipoOperaciones {
  id?: number;
  tipoOperaciones?: string;
  abrev?: string;
}

export interface modules extends ResponseATU {
  modulos?: Modulo[];
}
