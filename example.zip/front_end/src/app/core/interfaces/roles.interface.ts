import { Comision } from "./response.interface";

export interface Roles extends Response {
  id?: number;
  rol?: string;
}

export interface TipoUsuario {
  id?: number;
  nombre?: string;
}
export interface Perfil extends Response {
  id?: number;
  perfiles?: string;
  idSRU?: number;
  tipoUsuario?: TipoUsuario;
  comision?: Comision;
}
