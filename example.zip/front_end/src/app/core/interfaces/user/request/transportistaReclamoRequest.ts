export interface TransportistaReclamoRequest {
  correo?: string;
  motivo?: string;
  placa?: string;
  quejas?: string;
  adjuntar?: string;
}
