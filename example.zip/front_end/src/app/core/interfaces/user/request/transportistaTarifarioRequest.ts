export interface TransportistaTarifarioRequest {
  equivalencia?: string;
  perfilId?: number;
  precio?: number;
  codigoRuta?: string;
  ruc?: string;
  tipoTarifa?: string;
}
