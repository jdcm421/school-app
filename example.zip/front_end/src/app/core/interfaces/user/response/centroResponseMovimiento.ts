import { ResponseATU } from "@interfaces/response.interface";

export interface CentroResponseMovimiento extends ResponseATU {
  movimientos?: CentroMovimiento[];
  reportes?:    CentroReporte[];
}

export interface CentroMovimiento {
  comision?:     number;
  direccion?:    string;
  fecha?:        string;
  hora?:         string;
  id?:           number;
  idCentro?:     number;
  idSucursal?:   number;
  monto?:        number;
  nombreCentro?: string;
}

export interface CentroReporte {
  comision?: number;
  fecha?:    string;
  hora?:     string;
  id?:       number;
  monto?:    number;
}
