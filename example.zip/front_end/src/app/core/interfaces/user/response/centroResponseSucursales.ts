import { ResponseATU } from "@interfaces/response.interface";

export interface CentroResponseSucursales extends ResponseATU {
  sucursales?: CentroSucursale[];
}

export interface CentroSucursale {
  direccion?:     string;
  id?:            number;
  nombreCentro?:  string;
  numDocumento?:  string;
  tipoDocumento?: string;
  ubigeo?:        string;
}
