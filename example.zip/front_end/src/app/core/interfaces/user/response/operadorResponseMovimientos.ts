import { ResponseATU } from '../../response.interface';
export interface OperadorResponseMovimientos extends ResponseATU {
  movimientos?: Movimiento[];
  reportes?:    Reporte[];
}

export interface Movimiento {
  empresa?: string;
  fecha?:   string;
  hora?:    string;
  id?:      number;
  monto?:   number;
  origen?:  string;
  placa?:   string;
  tipo?:    string;
}

export interface Reporte {
  comision?: number;
  fecha?:    string;
  hora?:     string;
  id?:       number;
  monto?:    number;
}
