import { ResponseATU } from "@interfaces/response.interface";

export interface TransportistaHistorialTarifarioResponse extends ResponseATU {
  historiales?: TransportistaHistorialTarifario[];
}

export interface TransportistaHistorialTarifario {
  detalle?:     string;
  fecha?:       string;
  hora?:        string;
  id?:          number;
  monto?:       number;
  perfil?:      string;
  ruta?:        string;
  tipoUsuario?: string;
}
