import { ResponseATU } from "@interfaces/response.interface";

export interface TransportistaMovimientosResponse extends ResponseATU {
  movimientos?: TransportistaMovimientos[];
  reportes?:    TransportistaReporte[];
}

export interface TransportistaMovimientos {
  fecha?:         Date;
  hora?:          Date;
  id?:            number;
  monto?:         number;
  placa?:         string;
  ruta?:          string;
  tipoOperacion?: string;
}

export interface TransportistaReporte {
  comision?: number;
  fecha?:    string;
  hora?:     string;
  id?:       number;
  monto?:    number;
}
