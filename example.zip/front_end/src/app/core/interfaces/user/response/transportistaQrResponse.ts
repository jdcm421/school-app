import { ResponseATU } from "@interfaces/response.interface";

export interface TransportistaQrResponse extends ResponseATU {
  transportista?: TransportistaQr[];
  transporteQr?:  TransportistaQr;
}

export interface TransportistaQr {
  empresaTransporte?: string;
  ruc?: string;
  id?:                number;
  numeroAsientos?:    number;
  placa?:             string;
  qr?:                string;
  ruta?:              string;
  unidad?:            string;
}
