import { ResponseATU } from "@interfaces/response.interface";

export interface TransportistaTarifarioResponse extends ResponseATU {
  rutas?: TransportistaTarifarioRuta[];
  tarifa?: TransportistaTarifarioTarifa;
  tarifas?: TransportistaTarifarioTarifa[];
}

export interface TransportistaTarifarioRuta {
  empresa?: string;
  id?: number;
  ruc?: string;
  ruta?: string;
}

export interface TransportistaTarifarioTarifa {
  estado?: boolean;
  id?: number;
  monto?: number;
  perfil?: string;
  ruc?: string;
  ruta?: string;
  tipoUsuario?: string;
}
