export class Divisa {
  constructor(
    public id: string,
    public name: string
  ) { }
}
