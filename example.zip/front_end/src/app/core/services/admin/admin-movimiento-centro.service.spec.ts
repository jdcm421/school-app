import { TestBed } from '@angular/core/testing';

import { AdminMovimientoCentroService } from './admin-movimiento-centro.service';

describe('AdminMovimientoCentroService', () => {
  let service: AdminMovimientoCentroService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminMovimientoCentroService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
