import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminMovimientoCentro } from '@interfaces/admin/response/adminMovimientoCentro';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminMovimientoCentroService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

    movimientosAdmin(filter: RequestPage): Observable<AdminMovimientoCentro> {
      return this._http
        .post<AdminMovimientoCentro>(`${this.baseUrl}/admin/movimientos/centro`, filter, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }
}
