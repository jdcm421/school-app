import { TestBed } from '@angular/core/testing';

import { AdminMovimientoOperadorService } from './admin-movimiento-operador.service';

describe('AdminMovimientoOperadorService', () => {
  let service: AdminMovimientoOperadorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminMovimientoOperadorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
