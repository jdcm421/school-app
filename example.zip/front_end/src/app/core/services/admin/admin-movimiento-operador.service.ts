import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminMovimientoOperador } from '@interfaces/admin/response/adminMovimientoOperador';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminMovimientoOperadorService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

    movimientosAdmin(filter: RequestPage): Observable<AdminMovimientoOperador> {
      return this._http
        .post<AdminMovimientoOperador>(`${this.baseUrl}/admin/movimientos/operador`, filter, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }
}
