import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminBitacorasResponse } from '@interfaces/admin/response/adminBitacorasResponse';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class BitacorasService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

  bitacoras(filter: RequestPage): Observable<AdminBitacorasResponse> {
    return this._http
      .post<AdminBitacorasResponse>(`${this.baseUrl}/admin/bitacoras`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  puntos(): Observable<AdminBitacorasResponse> {
    return this._http
      .get<AdminBitacorasResponse>(`${this.baseUrl}/admin/bitacoras`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

}
