import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage, RequestSucursal } from '@interfaces/request.interface';
import { ResponseCentroRecarga, ResponseCentroRecargaAlone, ResponseSucursales } from '@interfaces/response.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class CentroService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

  centros(filter: RequestPage): Observable<ResponseCentroRecarga> {
    return this._http
      .post<ResponseCentroRecarga>(
        `${this.baseUrl}/admin/centro-recargas/list`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  centrosBySucursales(filter: RequestSucursal): Observable<ResponseSucursales> {
    return this._http
      .post<ResponseSucursales>(
        `${this.baseUrl}/admin/centro-recargas/sucursales`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  centro(filter: RequestPage): Observable<ResponseCentroRecarga> {
    return this._http
      .post<ResponseCentroRecarga>(`${this.baseUrl}/admin/centro-recargas`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  centrosRegister(filter: RequestPage): Observable<ResponseCentroRecarga> {
    return this._http
      .post<ResponseCentroRecarga>(`${this.baseUrl}/admin/centro-recargas`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  centroUpdated(filter: RequestPage): Observable<ResponseCentroRecarga> {
    return this._http
      .post<ResponseCentroRecarga>(`${this.baseUrl}/admin/centro-recargas`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  centroChange(filter: RequestPage): Observable<ResponseCentroRecarga> {
    return this._http
      .post<ResponseCentroRecarga>(`${this.baseUrl}/admin/centro-recargas`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  centroOne(id: number): Observable<ResponseCentroRecargaAlone> {
    return this._http
      .get<ResponseCentroRecargaAlone>(`${this.baseUrl}/admin/centro-recargas/cuenta/` + id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  sucursalesOne(id: number): Observable<ResponseSucursales> {
    return this._http
      .get<ResponseSucursales>(`${this.baseUrl}/admin/centro-recargas/pasajero/` + id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

}
