/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminEmpresaTransporteService } from './adminEmpresaTransporte.service';

describe('Service: AdminEmpresaTransporte', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminEmpresaTransporteService]
    });
  });

  it('should ...', inject([AdminEmpresaTransporteService], (service: AdminEmpresaTransporteService) => {
    expect(service).toBeTruthy();
  }));
});
