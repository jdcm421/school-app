import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminEmpresaTransporteResponse } from '@interfaces/admin/response/adminEmpresaTransporteResponse';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminEmpresaTransporteService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

    getTransportista(filter: RequestPage): Observable<AdminEmpresaTransporteResponse> {
      return this._http
        .post<AdminEmpresaTransporteResponse>(`${this.baseUrl}/admin/empresa-transportes`, filter, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    changeStatus(id: number): Observable<AdminEmpresaTransporteResponse> {
      return this._http
        .put<AdminEmpresaTransporteResponse>(`${this.baseUrl}/admin/empresa-transportes/cambio-estado/` + id, null, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

}
