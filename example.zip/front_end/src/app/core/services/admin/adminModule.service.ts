import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { modules } from '@interfaces/response.interface';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AuthService } from '../auth.service';

@Injectable({
  providedIn: 'root'
})
export class ModuleService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

  modulos(): Observable<modules>{
    return this._http.get(`${this.baseUrl}/admin/modulos`,{headers:{
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.auth.getToken(),
    },}).pipe();
  }
}
