import { TestBed } from '@angular/core/testing';

import { AdminMovimientoService } from './adminMovimiento.service';

describe('AdminMovimientoService', () => {
  let service: AdminMovimientoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminMovimientoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
