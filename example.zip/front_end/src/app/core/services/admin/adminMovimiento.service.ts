import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminMovimientoResponse } from '@interfaces/admin/response/adminMovimientoResponse';
import { requestDetail, requestFidei, RequestPage, requestPago } from '@interfaces/request.interface';
import { MovimientoAdmin, MovimientoAlone, MovimientoPassenger, ReporteDetIndicadoresList, ReporteIndicadoresList } from '@interfaces/response.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AdminMovimientoService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

  movimientosAdmin(filter: RequestPage): Observable<AdminMovimientoResponse> {
    return this._http
      .post<AdminMovimientoResponse>(`${this.baseUrl}/admin/movimientos`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  movimientosReporte(filter: requestDetail): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/reporte-detallado`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosReportePago(filter: requestPago): Observable<ReporteIndicadoresList> {
    return this._http
      .post<ReporteIndicadoresList>(
        `${this.baseUrl}/movimientos/reporte-pago`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosReportePagoDetAdmins(filter: requestPago): Observable<ReporteDetIndicadoresList> {
    return this._http
      .post<ReporteDetIndicadoresList>(
        `${this.baseUrl}/movimientos/reporte-detallado-users`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosReportePagoDetail(id: number): Observable<ReporteIndicadoresList> {
    return this._http
      .get<ReporteIndicadoresList>(
        `${this.baseUrl}/movimientos/reporte-pago/` + id,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosPasssenger(): Observable<MovimientoPassenger> {
    return this._http
      .get<MovimientoPassenger>(`${this.baseUrl}/movimientos/passenger`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  movimientosTransporte(filter: RequestPage): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/transportista`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosOperadorApps(filter: RequestPage): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/operador-apps`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosCentros(filter: RequestPage): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/centro-recarga`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosCentroAdmin(filter: RequestPage): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/admin/centro`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  movimientosOperadorAppsAdmin(
    filter: RequestPage
  ): Observable<MovimientoAdmin> {
    return this._http
      .post<MovimientoAdmin>(
        `${this.baseUrl}/movimientos/admin/operador-apps`,
        filter,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  fideicomiso(id: number, fidei: requestFidei): Observable<MovimientoAlone> {
    return this._http
      .post<MovimientoAlone>(`${this.baseUrl}/movimientos/reporte-detallado/fideicomiso/` + id, fidei, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  movimiento(id: number): Observable<AdminMovimientoResponse> {
    return this._http
      .get<AdminMovimientoResponse>(`${this.baseUrl}/admin/movimientos/` + id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

}
