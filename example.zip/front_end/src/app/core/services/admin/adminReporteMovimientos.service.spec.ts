/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminReporteMovimientosService } from './adminReporteMovimientos.service';

describe('Service: AdminReporteMovimientos', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminReporteMovimientosService]
    });
  });

  it('should ...', inject([AdminReporteMovimientosService], (service: AdminReporteMovimientosService) => {
    expect(service).toBeTruthy();
  }));
});
