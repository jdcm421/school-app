/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminSucursalesService } from './adminSucursales.service';

describe('Service: AdminSucursales', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminSucursalesService]
    });
  });

  it('should ...', inject([AdminSucursalesService], (service: AdminSucursalesService) => {
    expect(service).toBeTruthy();
  }));
});
