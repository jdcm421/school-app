import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminSurcusalesResponse } from '@interfaces/admin/response/adminSurcusalesResponse';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminSucursalesService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

    getSucursales(filter: RequestPage): Observable<AdminSurcusalesResponse> {
      return this._http
        .post<AdminSurcusalesResponse>(`${this.baseUrl}/admin/sucursales`, filter, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    changeStatus(id: number): Observable<AdminSurcusalesResponse> {
      return this._http
        .put<AdminSurcusalesResponse>(`${this.baseUrl}/admin/sucursales/cambio-estado/`+id, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }
}
