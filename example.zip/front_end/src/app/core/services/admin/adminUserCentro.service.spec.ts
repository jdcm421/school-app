/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminUserCentroService } from './adminUserCentro.service';

describe('Service: AdminUserCentro', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminUserCentroService]
    });
  });

  it('should ...', inject([AdminUserCentroService], (service: AdminUserCentroService) => {
    expect(service).toBeTruthy();
  }));
});
