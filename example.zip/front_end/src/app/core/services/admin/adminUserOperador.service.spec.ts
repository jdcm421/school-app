/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminUserOperadorService } from './adminUserOperador.service';

describe('Service: AdminUserOperador', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminUserOperadorService]
    });
  });

  it('should ...', inject([AdminUserOperadorService], (service: AdminUserOperadorService) => {
    expect(service).toBeTruthy();
  }));
});
