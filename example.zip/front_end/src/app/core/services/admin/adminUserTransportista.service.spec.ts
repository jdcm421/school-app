/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { AdminUserTransportistaService } from './adminUserTransportista.service';

describe('Service: AdminUserTransportista', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdminUserTransportistaService]
    });
  });

  it('should ...', inject([AdminUserTransportistaService], (service: AdminUserTransportistaService) => {
    expect(service).toBeTruthy();
  }));
});
