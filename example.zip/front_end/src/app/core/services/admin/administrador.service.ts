import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminRequestAdministrador } from '@interfaces/admin/request/adminRequestAdministrador';
import { AdminRequestUpdateAdmin } from '@interfaces/admin/request/adminRequestUpdateAdmin';
import { AdminResponse } from '@interfaces/admin/response/adminResponse';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdministradorService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

    getAdministrador(filter: RequestPage): Observable<AdminResponse> {
      return this._http
        .post<AdminResponse>(`${this.baseUrl}/admin`, filter, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    profile = (): Observable<AdminResponse> => {
      return this._http.get<AdminResponse>(`${this.baseUrl}/admin/perfil`, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + this.auth.getToken()
        }
      }).pipe();
    }

    consultAdmin(id: number): Observable<AdminResponse> {
      return this._http
        .get<AdminResponse>(`${this.baseUrl}/admin/` + id, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    regAdmin(request: AdminRequestAdministrador): Observable<AdminResponse> {
      return this._http
        .post<AdminResponse>(`${this.baseUrl}/admin/registro`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    editAdmin(id: number, request: AdminRequestUpdateAdmin): Observable<AdminResponse> {
      return this._http
        .put<AdminResponse>(`${this.baseUrl}/admin/actualizar/` + id, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

    changeStatusAdmin(id: number): Observable<AdminResponse> {
      return this._http
        .put<AdminResponse>(`${this.baseUrl}/admin/admin/estado/` + id, null, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        })
        .pipe();
    }

}
