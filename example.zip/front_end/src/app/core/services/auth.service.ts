import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Credential } from '@interfaces/auth.interface';
import { RequestRefreshToken } from '@interfaces/request.interface';
import {
  ResponseATU,
  ResponseRegisterUser,
  ResponseToken,
} from '@interfaces/response.interface';
import { Observable, tap } from 'rxjs';
import { environment } from 'src/environments/environment';
import { RegistroForm } from './../interfaces/auth.interface';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient) { }

  loginAdmin = (credenciales: Credential): Observable<ResponseToken> => {
    return this._http
      .post<ResponseToken>(`${this.baseUrl}/auth/admin/login`, credenciales)
      .pipe(tap(this.saveAdminToken.bind(this)));
  };

  loginUser = (credenciales: Credential): Observable<ResponseToken> => {
    return this._http
      .post<ResponseToken>(`${this.baseUrl}/auth/login`, credenciales)
      .pipe(tap(this.saveToken.bind(this)));
  };

  refreshToken(request: RequestRefreshToken) : Observable<ResponseToken> {
    return this._http.post<ResponseToken>(
      `${this.baseUrl}/auth/refresh-token`,request
    ).pipe();
  }

  registro = (request: RegistroForm): Observable<ResponseRegisterUser> => {
    return this._http
      .post<ResponseRegisterUser>(`${this.baseUrl}/auth/registro`, request)
      .pipe();
  };

  profile = (auth: string): Observable<ResponseToken> => {
    return this._http
      .get<ResponseToken>(`${this.baseUrl}/auth/perfil`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + auth,
        },
      })
      .pipe();
  };

  validAccount(token: string): Observable<ResponseATU> {
    return this._http
      .get<ResponseATU>(`${this.baseUrl}/auth/cuenta/` + token)
      .pipe();
  }

  logout = (): Observable<ResponseATU> => {
    return this._http
      .get<ResponseATU>(`${this.baseUrl}/auth/cerrar-sesion`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.getToken(),
        },
      })
      .pipe(tap(this.deleteToken.bind(this)));
  };

  logoutUser = (): Observable<ResponseATU> => {
    return this._http
      .get<ResponseATU>(`${this.baseUrl}/auth/cerrar-sesion`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.getTokenUser(),
        },
      })
      .pipe(tap(this.deleteTokenUser.bind(this)));
  };

  saveToken = (value: ResponseToken): void => {
    if (value.codigo == 200) {
      localStorage.removeItem('_grecaptcha');
      localStorage.setItem('atu_token', value.atuToken);
      localStorage.setItem('atu_RefreshToken', value.atuRefreshToken);
      localStorage.setItem('nombre', value.cuenta.usuario.nombreCompleto);
      const rol = value.cuenta.admin != null ? value.cuenta.admin.role.rol : 'Pasajero';
      localStorage.setItem('rol', rol);
    }
  };

  saveAdminToken(value: ResponseToken): void {
    if (value.codigo == 200) {
      localStorage.removeItem('_grecaptcha');
      localStorage.setItem('token', value.token);
      localStorage.setItem('refreshToken', value.refreshToken);
      localStorage.setItem('nombre', value.cuenta.usuario.nombreCompleto);
      localStorage.setItem('rol', value.cuenta.admin.role.rol);
    }
  }

  saveRefreshToken = (value: ResponseToken): void => {
    if (value.codigo == 200) {
      localStorage.removeItem('_grecaptcha');
      localStorage.setItem('token', value.token);
      localStorage.setItem('refreshToken', value.refreshToken);
      localStorage.setItem('atu_token', value.atuToken);
      localStorage.setItem('atu_RefreshToken', value.atuRefreshToken);
    }
  };

  deleteToken = (value: ResponseToken): void => {
    if (value.codigo == 200) {
      localStorage.removeItem('_grecaptcha');
      localStorage.removeItem('refreshToken');
      localStorage.removeItem('token');
      localStorage.removeItem('id');
      localStorage.removeItem('numDocumento');
    }
  };

  deleteTokenUser = (value: ResponseToken): void => {
    if (value.codigo == 200) {
      localStorage.removeItem('_grecaptcha');
      localStorage.removeItem('atu_RefreshToken');
      localStorage.removeItem('atu_token');
      localStorage.removeItem('id');
    }
  };

  deleteTokenLocal = (): void => {
    localStorage.removeItem('_grecaptcha');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('token');
    localStorage.removeItem('nombre');
    localStorage.removeItem('rol');
    localStorage.removeItem('id');
  };

  deleteTokenLocalUser = (): void => {
    localStorage.removeItem('_grecaptcha');
    localStorage.removeItem('atu_RefreshToken');
    localStorage.removeItem('atu_token');
    localStorage.removeItem('nombre');
    localStorage.removeItem('rol');
    localStorage.removeItem('id');
  };

  isAutenticated = (): boolean => {
    if (localStorage.getItem('token') !== null) {
      return true;
    } else if (localStorage.getItem('atu_token') !== null) {
      return true;
    } else {
      return false;
    }
  };

  getRefreshToken = (): string => {
    if (localStorage.getItem('refreshToken') !== null) {
      return localStorage.getItem('refreshToken');
    } else {
      return null;
    }
  };

  getRefreshTokenUser = (): string => {
    if (localStorage.getItem('atu_RefreshToken') !== null) {
      return localStorage.getItem('atu_RefreshToken');
    } else {
      return null;
    }
  };

  getToken() {
    if (localStorage.getItem('token') !== null) {
      return localStorage.getItem('token');
    } else {
      return null;
    }
  }

  getTokenUser() {
    if (localStorage.getItem('atu_token') !== null) {
      return localStorage.getItem('atu_token');
    } else {
      return null;
    }
  }
}
