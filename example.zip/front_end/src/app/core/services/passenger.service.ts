import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage, RequestPassengerUpdated, RequestProfileUpdated } from '@interfaces/request.interface';
import { ResponsePassenger, ResponsePassengerPage } from '@interfaces/response.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class PassengerService {
  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) {}

  getPassenger(filter: RequestPage): Observable<ResponsePassengerPage> {
    return this._http
      .post<ResponsePassengerPage>(`${this.baseUrl}/pasajero`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  passenger(id: number): Observable<ResponsePassenger> {
    return this._http
      .get<ResponsePassenger>(`${this.baseUrl}/pasajero/` + id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }

  editProfile(request: RequestProfileUpdated): Observable<ResponsePassenger> {
    return this._http
      .put<ResponsePassenger>(
        `${this.baseUrl}/auth/actualizar/perfil`,
        request,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  editPassenger(
    id: number,
    request: RequestPassengerUpdated
  ): Observable<ResponsePassenger> {
    return this._http
      .put<ResponsePassenger>(
        `${this.baseUrl}/pasajero/actualizar/` + id,
        request,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getToken(),
          },
        }
      )
      .pipe();
  }

  changeStatus(id: number): Observable<ResponsePassenger> {
    return this._http
      .put<ResponsePassenger>(`${this.baseUrl}/pasajero/estado/` + id, null, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getToken(),
        },
      })
      .pipe();
  }
}
