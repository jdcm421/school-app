import { TestBed } from '@angular/core/testing';

import { PassengerCentroService } from './passenger-centro.service';

describe('PassengerCentroService', () => {
  let service: PassengerCentroService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PassengerCentroService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
