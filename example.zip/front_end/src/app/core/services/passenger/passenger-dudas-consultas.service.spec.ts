/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { PassengerDudasConsultasService } from './passenger-dudas-consultas.service';

describe('Service: PassengerDudasConsultas', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassengerDudasConsultasService]
    });
  });

  it('should ...', inject([PassengerDudasConsultasService], (service: PassengerDudasConsultasService) => {
    expect(service).toBeTruthy();
  }));
});
