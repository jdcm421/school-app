import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PassengerRequestReclamos } from '@interfaces/passenger/request/passengerRequestReclamos';
import { PassengerReclamos } from '@interfaces/passenger/response/passengerReclamos';
import { ResponseATU, ResponseRoles } from '@interfaces/response.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PassengerDudasConsultasService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth: AuthService) { }

  getEmpresas(): Observable<ResponseRoles> {
    return this._http
      .get<ResponseRoles>(`${this.baseUrl}/passenger/reclamos/tipo-empresas`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
  }

  obtenerEmpresas(id: number): Observable<PassengerReclamos> {
    return this._http
      .get<PassengerReclamos>(`${this.baseUrl}/passenger/reclamos/empresa/` + id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
  }

  registro(request: PassengerRequestReclamos): Observable<ResponseATU>{
    return this._http
      .post<ResponseATU>(
        `${this.baseUrl}/passenger/reclamos/registro`,
        request,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        }
      )
      .pipe();
  }
}
