/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { PassengerMovimientoService } from './passenger-movimiento.service';

describe('Service: PassengerMovimiento', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassengerMovimientoService]
    });
  });

  it('should ...', inject([PassengerMovimientoService], (service: PassengerMovimientoService) => {
    expect(service).toBeTruthy();
  }));
});
