import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponsePassengerMovimiento, ResponsePassengerMovimientos } from '@interfaces/passenger/response/passengerMovimiento';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PassengerMovimientoService {
  private baseUrl = environment.url;
constructor(private _http: HttpClient,
  private auth : AuthService) { }

getMovimientos(): Observable<ResponsePassengerMovimientos> {
  return this._http
    .get<ResponsePassengerMovimientos>(`${this.baseUrl}/passenger/movimientos/listado`, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + this.auth.getTokenUser(),
      },
    })
    .pipe();
}

obtener(id: number): Observable<ResponsePassengerMovimiento> {
  return this._http
    .get<ResponsePassengerMovimiento>(`${this.baseUrl}/passenger/movimientos/` + id, {
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + this.auth.getTokenUser(),
      },
    })
    .pipe();
}
}
