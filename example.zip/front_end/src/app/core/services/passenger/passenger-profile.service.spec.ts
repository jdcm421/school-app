/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { PassengerProfileService } from './passenger-profile.service';

describe('Service: PassengerProfile', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassengerProfileService]
    });
  });

  it('should ...', inject([PassengerProfileService], (service: PassengerProfileService) => {
    expect(service).toBeTruthy();
  }));
});
