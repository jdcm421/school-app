import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PassengerRequestProfile } from '@interfaces/passenger/request/passenger-request-profile';
import { PassengerProfile } from '@interfaces/passenger/response/passengerProfile';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PassengerProfileService {
  private baseUrl = environment.url;
constructor(private _http: HttpClient,
  private auth : AuthService) { }

  getProfile(): Observable<PassengerProfile> {
    return this._http
        .get<PassengerProfile>(`${this.baseUrl}/passenger/profile`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
  }

  updatedProfile(request: PassengerRequestProfile): Observable<PassengerProfile>{
    return this._http
      .put<PassengerProfile>(
        `${this.baseUrl}/passenger/profile/actualizar`,
        request,
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        }
      )
      .pipe();
  }
}
