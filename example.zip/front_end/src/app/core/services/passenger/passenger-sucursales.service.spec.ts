/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { PassengerSucursalesService } from './passenger-sucursales.service';

describe('Service: PassengerSucursales', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PassengerSucursalesService]
    });
  });

  it('should ...', inject([PassengerSucursalesService], (service: PassengerSucursalesService) => {
    expect(service).toBeTruthy();
  }));
});
