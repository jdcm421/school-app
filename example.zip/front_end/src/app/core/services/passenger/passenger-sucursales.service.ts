import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponsePassengerSucursal, ResponsePassengerSucursales } from '@interfaces/passenger/response/passengerSucursales';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class PassengerSucursalesService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getSucursales(filter : RequestPage, id:number) : Observable<ResponsePassengerSucursales> {
      return  this._http
      .post<ResponsePassengerSucursales>(`${this.baseUrl}/passenger/sucursales/listado/`+id, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }

    obtener(id: number): Observable<ResponsePassengerSucursal> {
      return this._http
        .get<ResponsePassengerSucursal>(`${this.baseUrl}/passenger/sucursales/` + id, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

}
