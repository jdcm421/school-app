import { TestBed } from '@angular/core/testing';

import { PassengerTransporteService } from './passenger-transporte.service';

describe('PassengerTransporteService', () => {
  let service: PassengerTransporteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PassengerTransporteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
