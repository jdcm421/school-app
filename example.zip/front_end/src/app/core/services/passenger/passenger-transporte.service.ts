import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ResponsePassengerTransportes } from '@interfaces/passenger/response/passengerTransporte';
import { RequestPage } from '@interfaces/request.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class PassengerTransporteService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getlistado(filter : RequestPage) : Observable<ResponsePassengerTransportes> {
      return  this._http
      .post<ResponsePassengerTransportes>(`${this.baseUrl}/passenger/transportes/listado`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }
}
