import { Observable, map } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { environment } from 'src/environments/environment';
import { TipoDispositivo, TipoOperaciones } from '@interfaces/response.interface';

@Injectable({
  providedIn: 'root'
})
export class PerfilesService {
  private baseUrl = environment.url;

  constructor(private _http: HttpClient) { }

  getPerfiles(): Observable<Perfil[]> {
    return this._http.get(`${this.baseUrl}/perfiles`).pipe(
      map((response: { perfiles: Perfil[] }) => response.perfiles)
    );
  }

  getTipoUsuario(): Observable<TipoUsuario[]> {
    return this._http.get(`${this.baseUrl}/perfiles/tipo-usuarios`).pipe(
      map((response: { tipoUsuarios: TipoUsuario[] }) => response.tipoUsuarios)
    );
  }

  getTipoOperacion(): Observable<TipoOperaciones[]> {
    return this._http.get(`${this.baseUrl}/perfiles/tipo-operacion`).pipe(
      map((response: { tipoOperaciones: TipoOperaciones[] }) => response.tipoOperaciones)
    );
  }

  getTipoDispositivo(): Observable<TipoDispositivo[]> {
    return this._http.get(`${this.baseUrl}/perfiles/tipo-dispositivo`).pipe(
      map((response: { tipoDispositivos: TipoDispositivo[] }) => response.tipoDispositivos)
    );
  }
}
