import { ResponseATU } from '@interfaces/response.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { EmailRequest, PasswordRestRequest } from '@interfaces/request.interface';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ResetPasswordService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient) {
  }


  validarToken(token: string): Observable<ResponseATU> {
    return this._http.get<ResponseATU>(`${this.baseUrl}/password-reset/valid?token=` + token).pipe();
  }

  sendEmail(request: EmailRequest): Observable<ResponseATU> {
    return this._http.post<ResponseATU>(`${this.baseUrl}/password-reset/`, request).pipe();
  }

  passwordRest(request: PasswordRestRequest): Observable<ResponseATU> {
    return this._http.post<ResponseATU>(`${this.baseUrl}/password-reset/change`, request).pipe();
  }
}
