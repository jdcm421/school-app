import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Roles } from '@interfaces/roles.interface';

@Injectable({
  providedIn: 'root'
})
export class RolesService {
  private baseUrl = environment.url;

  constructor(private _http: HttpClient) { }

  getRoles(): Observable<Roles> {
    return this._http.get<Roles>(`${this.baseUrl}/roles`);
  }
}
