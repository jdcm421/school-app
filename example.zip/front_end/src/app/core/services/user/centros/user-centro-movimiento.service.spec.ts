import { TestBed } from '@angular/core/testing';

import { UserCentroMovimientoService } from './user-centro-movimiento.service';

describe('UserCentroMovimientoService', () => {
  let service: UserCentroMovimientoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserCentroMovimientoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
