import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { CentroResponseMovimiento } from '@interfaces/user/response/centroResponseMovimiento';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserCentroMovimientoService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getMovimientos(request : RequestPage): Observable<CentroResponseMovimiento> {
      return this._http
        .post<CentroResponseMovimiento>(`${this.baseUrl}/centro/movimiento`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    getReporte(request : RequestPage): Observable<CentroResponseMovimiento> {
      return this._http
        .post<CentroResponseMovimiento>(`${this.baseUrl}/centro/movimiento/reporte`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }
}
