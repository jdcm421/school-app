import { TestBed } from '@angular/core/testing';

import { UserCentrosSucursalesService } from './user-centros-sucursales.service';

describe('UserCentrosSucursalesService', () => {
  let service: UserCentrosSucursalesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserCentrosSucursalesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
