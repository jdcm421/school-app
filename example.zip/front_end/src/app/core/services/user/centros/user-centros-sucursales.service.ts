import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { CentroResponseSucursales } from '@interfaces/user/response/centroResponseSucursales';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserCentrosSucursalesService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getSucursales(filter : RequestPage) : Observable<CentroResponseSucursales> {
      return  this._http
      .post<CentroResponseSucursales>(`${this.baseUrl}/centro/sucursales`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }
}
