/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UserOperadorMovimientoService } from './user-operador-movimiento.service';

describe('Service: UserOperadorMovimiento', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserOperadorMovimientoService]
    });
  });

  it('should ...', inject([UserOperadorMovimientoService], (service: UserOperadorMovimientoService) => {
    expect(service).toBeTruthy();
  }));
});
