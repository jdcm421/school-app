import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { OperadorResponseMovimientos } from '@interfaces/user/response/operadorResponseMovimientos';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserOperadorMovimientoService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getMovimientos(request : RequestPage): Observable<OperadorResponseMovimientos> {
      return this._http
        .post<OperadorResponseMovimientos>(`${this.baseUrl}/operador/movimiento`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    getReporte(request : RequestPage): Observable<OperadorResponseMovimientos> {
      return this._http
        .post<OperadorResponseMovimientos>(`${this.baseUrl}/operador/movimiento/reporte`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }
}
