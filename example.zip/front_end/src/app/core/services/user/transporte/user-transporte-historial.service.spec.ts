import { TestBed } from '@angular/core/testing';

import { UserTransporteHistorialService } from './user-transporte-historial.service';

describe('UserTransporteHistorialService', () => {
  let service: UserTransporteHistorialService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserTransporteHistorialService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
