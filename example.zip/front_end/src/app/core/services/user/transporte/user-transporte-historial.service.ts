import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaHistorialTarifarioResponse } from '@interfaces/user/response/transportistaHistorialTarifarioResponse';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserTransporteHistorialService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getHistorial(filter : RequestPage) : Observable<TransportistaHistorialTarifarioResponse> {
      return  this._http
      .post<TransportistaHistorialTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/historial`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }
}
