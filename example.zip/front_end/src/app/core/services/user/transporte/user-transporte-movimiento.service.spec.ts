/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UserTransporteMovimientoService } from './user-transporte-movimiento.service';

describe('Service: UserTransporteMovimiento', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserTransporteMovimientoService]
    });
  });

  it('should ...', inject([UserTransporteMovimientoService], (service: UserTransporteMovimientoService) => {
    expect(service).toBeTruthy();
  }));
});
