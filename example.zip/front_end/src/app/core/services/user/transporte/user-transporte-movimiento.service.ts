import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaMovimientosResponse } from '@interfaces/user/response/transportistaMovimientosResponse';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserTransporteMovimientoService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getMovimientos(request : RequestPage): Observable<TransportistaMovimientosResponse> {
      return this._http
        .post<TransportistaMovimientosResponse>(`${this.baseUrl}/transporte/movimiento`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    getReporte(request : RequestPage): Observable<TransportistaMovimientosResponse> {
      return this._http
        .post<TransportistaMovimientosResponse>(`${this.baseUrl}/transporte/movimiento/reporte`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

}
