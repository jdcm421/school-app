import { TestBed } from '@angular/core/testing';

import { UserTransporteQrService } from './user-transporte-qr.service';

describe('UserTransporteQrService', () => {
  let service: UserTransporteQrService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserTransporteQrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
