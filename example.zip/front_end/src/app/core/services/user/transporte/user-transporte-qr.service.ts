import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaQrResponse } from '@interfaces/user/response/transportistaQrResponse';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserTransporteQrService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    getQrs(filter : RequestPage) : Observable<TransportistaQrResponse> {
      return  this._http
      .post<TransportistaQrResponse>(`${this.baseUrl}/transporte/qr`, filter, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }

    getQrsOnly(id : number) : Observable<TransportistaQrResponse> {
      return  this._http
      .get<TransportistaQrResponse>(`${this.baseUrl}/transporte/qr/obtener/`+id, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + this.auth.getTokenUser(),
        },
      })
      .pipe();
    }
}
