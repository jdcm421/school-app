import { TestBed } from '@angular/core/testing';

import { UserTransporteReclamoService } from './user-transporte-reclamo.service';

describe('UserTransporteReclamoService', () => {
  let service: UserTransporteReclamoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserTransporteReclamoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
