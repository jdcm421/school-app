import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { reclamoRequest } from '@interfaces/request.interface';
import { ResponseATU } from '@interfaces/response.interface';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserTransporteReclamoService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }


    dudas(request: reclamoRequest): Observable<ResponseATU> {
      return this._http
        .post<ResponseATU>(`${this.baseUrl}/tranportista/reclamos/registro`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }
}
