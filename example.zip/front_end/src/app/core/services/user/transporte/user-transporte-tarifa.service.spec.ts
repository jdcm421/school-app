/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UserTransporteTarifaService } from './user-transporte-tarifa.service';

describe('Service: UserTransporteTarifa', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserTransporteTarifaService]
    });
  });

  it('should ...', inject([UserTransporteTarifaService], (service: UserTransporteTarifaService) => {
    expect(service).toBeTruthy();
  }));
});
