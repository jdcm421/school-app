import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestPage, TarifaRequest } from '@interfaces/request.interface';
import { TransportistaTarifarioResponse } from '@interfaces/user/response/transportistaTarifarioResponse';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs/internal/Observable';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserTransporteTarifaService {

  private baseUrl = environment.url;
  constructor(private _http: HttpClient,
    private auth : AuthService) { }

    registrar(request: TarifaRequest): Observable<TransportistaTarifarioResponse> {
      return this._http
        .post<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/registro`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    actualizar(id: number, request: TarifaRequest): Observable<TransportistaTarifarioResponse> {
      return this._http
        .put<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/actualiza/` + id, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    tarifas(request: RequestPage): Observable<TransportistaTarifarioResponse> {
      return this._http
        .post<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario`, request, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    getTarifa(id: number): Observable<TransportistaTarifarioResponse> {
      return this._http
        .get<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/obtener/` + id, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    tarifasChangeStatus(id: number): Observable<TransportistaTarifarioResponse> {
      return this._http
        .put<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/estado/` + id, null, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

    getRutas(): Observable<TransportistaTarifarioResponse> {
      return this._http
        .get<TransportistaTarifarioResponse>(`${this.baseUrl}/transporte/tarifario/rutas`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + this.auth.getTokenUser(),
          },
        })
        .pipe();
    }

}
