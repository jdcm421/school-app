import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Event,
  NavigationEnd,
  Router,
  RouterStateSnapshot,
  UrlTree
} from '@angular/router';
import { loginRout, loginUserRout } from '@helpers/constants';
import { AuthService } from '@services/auth.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  currentUrl:string;
  constructor(
    private _authService: AuthService,
    private _router: Router
  ) {
    this.currentUrl = "ATU";
    this._router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
            this.currentUrl = event.url;
      }
  });
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this.currentUrl.includes('usuario') && !this._authService.isAutenticated()) {
      this._router.navigate([loginUserRout.route]);
      return false;
    }else if(!this._authService.isAutenticated()){
      this._router.navigate([loginRout.route]);
      return false;
    }

    return this._authService.isAutenticated();
  }

}
