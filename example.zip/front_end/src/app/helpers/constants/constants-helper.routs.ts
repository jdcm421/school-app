export const loginRout = {
  path: 'login',
  route: '/login',
}

export const loginUserRout = {
  path: 'usuario/login',
  route: 'usuario/login',
}
export const appRout = {
  home: {
    "path": "Web-ATU",
    "route": "/Web-ATU"
  },
  admin: {
    "path": "usuario-administrador",
    "route": "/usuario-administrador"
  },
  transportista: {
    "path": "usuario-transporte",
    "route": "/usuario-transporte"
  },
  recargador: {
    "path": "usuario-centro-recarga",
    "route": "/usuario-centro-recarga"
  },
  operadorapp: {
    "path": "usuario-operador",
    "route": "/usuario-operador"
  },
  user: {
    "path": "usuario-pasajero",
    "route": "/usuario-pasajero"
  },
  pasajero: {
    "path": "pasajero",
    "route": "/pasajero"
  },
  movimientos: {
    "path": "movimientos",
    "route": "/movimientos"
  },
  movimientosEmpresaTransporte: {
    "path": "usuario/movimientos-empresa-transporte",
    "route": "usuario/movimientos-empresa-transporte"
  },
  movimientosPassenger: {
    "path": "usuario/movimientos",
    "route": "/usuario/movimientos"
  },
  sucursalePassenger: {
    "path": "usuario/centro-recargas/sucursales",
    "route": "/usuario/centro-recargas/sucursales"
  },
  reportes: {
    "path": "reportes",
    "route": "/reportes"
  },
  transporte: {
    "path": "transporte",
    "route": "/transporte"
  },
  empresaTransporte: {
    "path": "usuario/empresa-transporte",
    "route": "/usuario/empresa-transporte"
  },
  centroRecargaPassenger: {
    "path": "usuario/centro-recargas",
    "route": "/usuario/centro-recargas"
  },
  sucursalesByCentro: {
    "path": "centro-recargas-sucursales",
    "route": "/centro-recargas-sucursales"
  },
  sucursales: {
    "path": "sucursales",
    "route": "/sucursales"
  },
  sucursalesUserCentro: {
    "path": "usuario/centro-recargas/sucursales/list",
    "route": "/usuario/centro-recargas/sucursales/list"
  },
  bitacora: {
    "path": "bitacora",
    "route": "/bitacora"
  },
  recargas: {
    "path": "recargas",
    "route": "/recargas"
  },
  operador: {
    "path": "operador-app",
    "route": "/operador-app"
  },
  monedero: {
    "path": "monedero",
    "route": "/monedero"
  },
  gestion: {
    "path": "usuario/gestion-arco",
    "route": "/usuario/gestion-arco"
  },
  control: {
    "path": "usuario/control-tarifa",
    "route": "/usuario/control-tarifa"
  },
  historial: {
    "path": "usuario/historial-tarifa",
    "route": "/usuario/historial-tarifa"
  },
  qr: {
    "path": "usuario/qr",
    "route": "/usuario/qr"
  },
  reclamos: {
    "path": "usuario/contactanos",
    "route": "/usuario/contactanos"
  },
  reporteGeneral: {
    "path": "reporte-general",
    "route": "/reporte-general"
  },
  gestionArcos: {
    "path": "usuario/gestion-Derechos-arcos",
    "route": "/usuario/gestion-derechos-arcos"
  },
  reporteFideicomiso: {
    "path": "reporte-fideicomiso",
    "route": "/reporte-fideicomiso"
  },
  reporteDetallado: {
    "path": "reporte-detallado",
    "route": "/reporte-detallado"
  },
  reporteFideicomisoTransporte: {
    "path": "usuario/reporte-fideicomiso-empresa",
    "route": "/usuario/reporte-fideicomiso-empresa"
  },
  reporteDetalladoTransporte: {
    "path": "reporte-detallado-empresa",
    "route": "/reporte-detallado-empresa"
  },
  reporteFideicomisoCentroRecarga: {
    "path": "usuario/reporte-fideicomiso-centro",
    "route": "/usuario/reporte-fideicomiso-centro"
  },
  reporteDetalladoCentroRecarga: {
    "path": "usuario/reporte-detallado-centro",
    "route": "/usuario/reporte-detallado-centro"
  },
  reporteFideicomisoOperador: {
    "path": "usuario/reporte-fideicomiso-operador",
    "route": "/usuario/reporte-fideicomiso-operador"
  },
  reporteDetalladoOperador: {
    "path": "usuario/reporte-detallado-operador",
    "route": "/usuario/reporte-detallado-operador"
  },
  reportePagos: {
    "path": "reporte-pagos",
    "route": "/reporte-pagos"
  },
  queja: {
    "path": "queja-reclamos",
    "route": "/queja-reclamos"
  },
  duda: {
    "path": "usuario/duda-consulta",
    "route": "/usuario/duda-consulta"
  }
};
