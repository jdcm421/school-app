export enum Breakpoints {
  'XS' = 'xs',
  'SM' = 'sm',
  'MD' = 'md',
  'LG' = 'lg',
  'XL' = 'xl'
};

export const ROLES = {
  Administrador: 'Administrador',
  OperadorApps: 'Operador Apps',
  EmpresaTransporte: 'Empresa Transporte',
  CentroRecargas: 'Centro Recargas'
}
