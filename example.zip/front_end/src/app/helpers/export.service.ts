import { Injectable } from '@angular/core';
import jsPDF from 'jspdf'
import * as XLSX from 'xlsx';
import autoTable from 'jspdf-autotable'
import { DomSanitizer } from '@angular/platform-browser';
import * as FileSaver from 'file-saver';


@Injectable({
  providedIn: 'root'
})
export class ExportService {

  constructor(private sanitizer: DomSanitizer) { }

  public exportPdf(columns: any[], data: any[], table: string) {
    const doc = table == 'Reporte_Detallado_' ? new jsPDF('l', 'pt') : table == 'Reporte_Instruccion_Pago_' ? new jsPDF('l', 'pt') : table == 'Usuarios_Pasajeros_' ? new jsPDF('l', 'pt') : new jsPDF();
    autoTable(doc, { columns: columns, body: data, theme: 'striped', tableWidth: 'auto' });
    doc.save(table + new Date().toLocaleDateString() + new Date().getTime() + '.pdf');
  }

  public exportExcel(columns: any[], data: any[], name: string, ext: string) {
    const xlsx = XLSX;
    const worksheet = xlsx.utils.json_to_sheet(data);
    const prueba = xlsx.utils.sheet_to_json(data);
    const extension = ext == '.xlsx' ? 'xlsx' : 'csv';
    const workbook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = xlsx.write(workbook, { bookType: extension, type: 'array' });
    this.saveAsExcelFile(excelBuffer, name, ext);
  }

  saveAsExcelFile(buffer: any, fileName: string, ext: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = ext;
    const data: Blob = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().toLocaleDateString() + new Date().getTime() + EXCEL_EXTENSION);
  }

  public exportText(nameText: string, data: any[]) {
    const bd = JSON.stringify(data);
    data = Array.of(bd);
    const blob = new Blob([data.join('\n')], { type: 'text/plain', endings: 'native' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', nameText + new Date().toLocaleDateString() + new Date().getTime() + '.txt');
    document.body.appendChild(link);
    link.click();
  }
}
