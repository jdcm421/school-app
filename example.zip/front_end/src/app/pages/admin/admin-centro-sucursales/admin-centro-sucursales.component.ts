import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU, Sucursal } from '@interfaces/response.interface';
import { AdminCentroSucursalesRegComponent } from '@modals/admin/admin-centro-sucursales-reg/admin-centro-sucursales-reg.component';
import { MessageService } from '@services/message.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-admin-centro-sucursales',
  templateUrl: './admin-centro-sucursales.component.html',
  styleUrls: ['./admin-centro-sucursales.component.scss'],
  providers: [DialogService]
})
export class AdminCentroSucursalesComponent implements OnInit {

  private ref: DynamicDialogRef;
  data:Sucursal[];
  suc:number=+localStorage.getItem('suc');
  id:number=+localStorage.getItem('id');
  register:boolean;
  request:RequestPage;

  constructor(public dialogService: DialogService,
    public messageService: MessageService,
/*     public sucursalService: SucursalesService, */
    private router: Router) { }

  ngOnInit() {
    this.request = {};
    this.sucursal();
  }

  sucursal(){
/*     this.sucursalService.sucursalByCentro(this.suc,this.request).subscribe(response =>{
      this.data = response.sucursales;
      this.register = response.codigo == 400 ? false : true;
      console.log(this.register);
    },(error:ResponseError) =>{
      console.error(error);
    }); */
  }

  public showUseRegister(id:number) {
    if(id==0){
      localStorage.removeItem('id');
    }
    this.ref = this.dialogService.open(AdminCentroSucursalesRegComponent, {
      header: id != 0 ? 'Editar Sucursal' :'Nueva Sucursal',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponseATU) => {
      if(response.codigo == 200 || response.codigo == 201){
        this.messageService.showSucces(response.mensaje);
        this.sucursal();
      }
  });
  }

  edit(id:number){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister(id);
  }

  status(id:number){
    this.sucursalService.sucursalCambia(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.sucursal();
      }
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  backCentro(){
    localStorage.removeItem('suc');
    localStorage.removeItem('center');
    this.router.navigateByUrl("/usuario-centro-recarga");
  }

}
