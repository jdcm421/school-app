import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponsePassenger, TipoDispositivo } from '@interfaces/response.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { UserRegisterComponent } from '@modals/admin/user-register/user-register.component';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { PassengerService } from '@services/passenger.service';
import { PerfilesService } from '@services/perfiles.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { PassengerPage } from '../../../core/interfaces/passenger.interface';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  providers: [DialogService]
})
export class UsersComponent implements OnInit {
  value: Date;
  private ref: DynamicDialogRef;
  passengerList: PassengerPage[];
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  perfiles:Perfil[];
  dispositivo:TipoDispositivo[];
  tipoUsuarios:TipoUsuario[];
  first:number= 0;
  rows:number = 10;
  request:RequestPage;
  dataExportExcel:any[];
  itemsDownload: MenuItem[];
  cols: any[] = [
    { header: 'Tipo Documento', field: 'tipoDocumento' },
    { header: 'Numero Documento', field: 'numDocumento' },
    { header: 'Nombre', field: 'nombre' },
    { header: 'Apellido', field: 'apellido' },
    { header: 'Correo', field: 'correo' },
    { header: 'celular', field: 'celular' },
    { header: 'Dirección', field: 'direccion' },
    { header: 'Ubigeo', field: 'ubigeo' },
    { header: 'Medio Registro', field: 'medioRegistro' },
    { header: 'Pedido Validez', field: 'pedidoValidez' },
    { header: 'Tipo Usuario', field: 'tipoUsuario' },
    { header: 'Perfil', field: 'perfil' }
  ];
  exportColumns: any[];

  constructor(
    public dialogService: DialogService,
    public messageService: MessageService,
    private _documentTypeService: DocumentTypeService,
    private passengerService:PassengerService,
    private perfilService: PerfilesService,
    private _exportService: ExportService
  ) {

  }

  ngOnInit(): void {
    this.request={};
    this.getPassenger();
    this.listTuypeDocuments();
    this.listaPerfiles();
    this.dataExportExcel = [];
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
    this.medioDispositivo();
  }


  public showUseRegister() {
    this.ref = this.dialogService.open(UserRegisterComponent, {
      header: 'Editar Usuario',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponsePassenger) => {
      if(response.codigo == 200){
        this.messageService.showSucces('Usuario Pasajero Actualizado');
        this.getPassenger();
        localStorage.removeItem('id');
      }

      if(localStorage.getItem('id') != null){
        localStorage.removeItem('id');
      }
  });
  }

  getPassenger(){
    this.dataExportExcel = [];
    this.passengerService.getPassenger(this.request).subscribe(response => {
      console.log(response);
      this.passengerList = response.usuarios;
      this.passengerList.forEach((passenger,i)=>{
        const item ={
          'tipoDocumento':passenger.tipoDocumento.tipoDocumento,
          'numDocumento':passenger.numDocumento,
          'nombre': passenger.usuario.nombre != null ? passenger.usuario.nombre : 'Sin Registro',
          'apellido': passenger.usuario.apellidos != null ? passenger.usuario.apellidos : 'Sin Registro',
          'correo':passenger.usuario.correo,
          'celular': passenger.usuario.celular !== null ? passenger.usuario.celular : 'Sin registro',
          'direccion': passenger.usuario.direccion,
          'ubigeo' :passenger.usuario.distrito !== null ? passenger.usuario.distrito.distrito : 'Sin registro',
          'medioRegistro' : passenger.usuario.medioRegistro,
          'pedidoValidez' : passenger.fechaValidez !== null ?passenger.fechaValidez : 'Sin Registro',
          'tipoUsuario' : passenger.usuario.perfil.tipoUsuario.nombre,
          'perfil' : passenger.usuario.perfil !== null ? passenger.usuario.perfil.perfiles : 'Sin Perfil'
        }
        this.dataExportExcel.push(item);
      });
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  search(){
    this.dataExportExcel = [];
    this.passengerService.getPassenger(this.request).subscribe(response => {
      this.passengerList = response.usuarios;
      this.passengerList.forEach((passenger,i)=>{
        const item ={
          'tipoDocumento':passenger.tipoDocumento.tipoDocumento,
          'numDocumento':passenger.numDocumento,
          'nombre': passenger.usuario.nombre != null ? passenger.usuario.nombre : 'Sin Registro',
          'apellido': passenger.usuario.apellidos != null ? passenger.usuario.apellidos : 'Sin Registro',
          'correo':passenger.usuario.correo,
          'celular': passenger.usuario.celular !== null ? passenger.usuario.celular : 'Sin registro',
          'direccion': passenger.usuario.direccion,
          'ubigeo' :passenger.usuario.distrito !== null ? passenger.usuario.distrito.distrito : 'Sin registro',
          'medioRegistro' : passenger.usuario.medioRegistro,
          'pedidoValidez' : passenger.fechaValidez !== null ?passenger.fechaValidez : 'Sin Registro',
          'tipoUsuario' : passenger.usuario.perfil.tipoUsuario.nombre,
          'perfil' : passenger.usuario.perfil !== null ? passenger.usuario.perfil.perfiles : 'Sin Perfil'
        }
        this.dataExportExcel.push(item);
      });
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  limpiar() {
    this.request={};
    this.getPassenger();
  }

  medioDispositivo(){
    this.perfilService.getTipoDispositivo().subscribe(response => {
      this.dispositivo = response;
    });
  }

  edit(id:number){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister();
  }

  status(id:number){
    this.passengerService.changeStatus(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje)
        this.getPassenger();
      }
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  ngOnDestroy() {
    if (this.ref) {
      localStorage.removeItem('id');
      this.ref.close();
    }
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  public listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result =>{
      this.perfiles = result;
      this.tipoUsuarios = result.map(t => t.tipoUsuario).slice(6,8);
    });
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.dataExportExcel,'Usuarios_Pasajeros_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Usuarios_Pasajeros_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Usuarios_Pasajeros_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Usuarios_Pasajeros_', this.dataExportExcel);
        }
      },
    ];
  }
}
