import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerPage } from '@interfaces/passenger.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU } from '@interfaces/response.interface';
import { AdminTransportRegComponent } from '@modals/admin/admin-transport-reg/admin-transport-reg.component';
import { AdminService } from '@services/admin/admin.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-admin-transporte',
  templateUrl: './admin-transporte.component.html',
  styleUrls: ['./admin-transporte.component.scss'],
  providers: [DialogService]
})
export class AdminTransporteComponent implements OnInit {

  private ref: DynamicDialogRef;
  request:RequestPage;
  admins:PassengerPage[];
  rows = 10;
  dataExportExcel:any[];
  itemsDownload: MenuItem[];
  cols: any[] = [
    { header: 'Tipo Documento', field: 'tipoDocumento' },
    { header: 'Numero Documento', field: 'numDocumento' },
    { header: 'Nombre Empresa', field: 'nombreEmpresa' },
    { header: 'Correo', field: 'correo' },
    { header: 'Celular', field: 'celular' },
    { header: 'Direccion', field: 'direccion' },
    { header: 'Ubigeo', field: 'ubigeo' },
  ];
  exportColumns: any[];
  valid:string;
  longitud:number;

  constructor(
    public dialogService: DialogService,
    public messageService: MessageService,
    public adminService: AdminService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.valid = 'alpha';
    this.longitud = 11;
    this.request = {};
    this.dataExportExcel = [];
    this.getAdmininstrador();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  public showUseRegister(id:number) {
    if(id==0){
      localStorage.removeItem('id');
    }
    this.ref = this.dialogService.open(AdminTransportRegComponent, {
      header: id != 0 ? 'Editar Usuario Transportista' :'Nuevo Usuario Transportista',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponseATU) => {
      if(response.codigo == 200 || response.codigo == 201){
        this.messageService.showSucces(response.mensaje);
        this.getAdmininstrador();
        localStorage.removeItem('id');
      }
  });
  }


  getAdmininstrador(){
    this.dataExportExcel = [];
    this.adminService.getTransporte(this.request).subscribe(response => {
      this.admins = response.transportista;
      this.admins.forEach((m,i)=>{
        const item ={
          'tipoDocumento':m.tipoDocumento.tipoDocumento,
          'numDocumento':m.numDocumento,
          'nombreEmpresa':m.usuario.nombreEmpresa,
          'correo':m.usuario.correo,
          'celular':m.usuario.celular,
          'direccion':m.usuario.direccion,
          'ubigeo':m.usuario.distrito.distrito+'/'+m.usuario.distrito.provincia.provincia +'/'+m.usuario.distrito.provincia.departamento.departamento
        }
        this.dataExportExcel.push(item);
      });
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  search(){
    this.dataExportExcel = [];
    this.adminService.getTransporte(this.request).subscribe(response => {
      this.admins = response.transportista;
      this.admins.forEach((m,i)=>{
        const item ={
          'tipoDocumento':m.tipoDocumento.tipoDocumento,
          'numDocumento':m.numDocumento,
          'nombreEmpresa':m.usuario.nombreEmpresa,
          'correo':m.usuario.correo,
          'celular':m.usuario.celular,
          'direccion':m.usuario.direccion,
          'ubigeo':m.usuario.distrito.distrito+'/'+m.usuario.distrito.provincia.provincia +'/'+m.usuario.distrito.provincia.departamento.departamento
        }
        this.dataExportExcel.push(item);
      });
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  limpiar(){
    this.request = {};
    this.getAdmininstrador();
  }

  edit(id:number){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister(id);
  }

  status(id:number){
    this.adminService.changeStatusAdmin(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.getAdmininstrador();
      }
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  filterKey(text:string){
    this.dataExportExcel = [];
    this.request.nombreEmpresa = text;
    this.adminService.getTransporte(this.request).subscribe(response => {
      this.admins = response.transportista;
      this.dataExportExcel = [];
      this.admins.forEach((m,i)=>{
        const item ={
        'tipoDocumento':m.tipoDocumento.tipoDocumento,
        'numDocumento':m.numDocumento,
        'nombreEmpresa':m.usuario.nombreEmpresa,
        'correo':m.usuario.correo,
        'celular':m.usuario.celular,
        'direccion':m.usuario.direccion,
        'ubigeo':m.usuario.distrito.distrito+'/'+m.usuario.distrito.provincia.provincia +'/'+m.usuario.distrito.provincia.departamento.departamento
        }
        this.dataExportExcel.push(item);
      });
    });

  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.dataExportExcel,'Usuario_Transportista_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Usuario_Transportista_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Usuario_Transportista_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Usuario_Transportista_', this.dataExportExcel);
        }
      },
    ];
  }

}
