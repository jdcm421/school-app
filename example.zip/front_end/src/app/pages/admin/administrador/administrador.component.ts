import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { Administradores } from '@interfaces/admin/response/adminResponse';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU } from '@interfaces/response.interface';
import { AdminRegisterComponent } from '@modals/admin/admin-register/admin-register.component';
import { DetailModulesComponent } from '@modals/admin/detail-modules/detail-modules.component';
import { AdministradorService } from '@services/admin/administrador.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-administrador',
  templateUrl: './administrador.component.html',
  styleUrls: ['./administrador.component.scss'],
  providers: [DialogService]
})
export class AdministradorComponent {
  private ref: DynamicDialogRef;
  admins: Administradores[];
  first: number = 0;
  rows: number = 10;
  request: RequestPage;
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  longitud: number;
  valid: string;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { header: 'Tipo Documento', field: 'tipoDocumento' },
    { header: 'Numero Documento', field: 'numDocumento' },
    { header: 'Nombre', field: 'nombre' },
    { header: 'Apellido', field: 'apellido' },
    { header: 'Correo', field: 'correo' },
    { header: 'celular', field: 'celular' },
  ];
  exportColumns: any[];

  constructor(private _documentTypeService: DocumentTypeService,
    public dialogService: DialogService,
    public messageService: MessageService,
    public adminService: AdministradorService,
    private _exportService: ExportService,
    private _location: Location) { }

  ngOnInit() {
    this.request = {};
    this.admins = [];
    this.longitud = 13;
    this.valid = 'int';
    this.listTuypeDocuments();
    this.getAdmininstrador();
    this.exportColumns = this.cols.map((col) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  public showUseRegister(id: number) {
    if (id == 0) {
      localStorage.removeItem('id');
    }

    this.ref = this.dialogService.open(AdminRegisterComponent, {
      header: id == 0 ? 'Nuevo Usuario administrador' : 'Editar Usuario administrador',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe((response: ResponseATU) => {
      if (response) {
        if (response.codigo == 200 || response.codigo == 201) {
          this.messageService.showSucces(response.mensaje);
          this.getAdmininstrador();
          localStorage.removeItem('id');
        }
      }
    });
  }

  public detailAdmi() {
    this.ref = this.dialogService.open(DetailModulesComponent, {
      header: 'Detalle Modulos Usuario administrador',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe((response: any) => {
      localStorage.removeItem('id');
    });
  }

  getAdmininstrador() {
    this.adminService.getAdministrador(this.request).subscribe(response => {
      this.admins = response.admins;
    }, (error: ResponseError) => {
      console.error(error); if (error.codigo == 403) {
        this._location.back();
      }

    });
  }

  search() {
    this.adminService.getAdministrador(this.request).subscribe(response => {
      this.admins = response.admins;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  limpiar() {
    this.longitud = 13;
    this.request = {};
    this.valid = 'int';
    this.selectedTypeDocument = null;
    this.getAdmininstrador();
  }

  edit(id: number) {
    if (localStorage.getItem('id') != null) {
      localStorage.removeItem('id');
    }
    localStorage.setItem('id', JSON.stringify(id));
    this.showUseRegister(id);
  }

  status(id: number) {
    this.adminService.changeStatusAdmin(id).subscribe(response => {
      if (response.codigo == 200) {
        this.messageService.showSucces(response.mensaje);
        this.getAdmininstrador();
      }
    }, (error: ResponseError) => {
      console.error(error);

    });
  }

  detail(id: number) {
    if (localStorage.getItem('id') != null) {
      localStorage.removeItem('id');
    }
    localStorage.setItem('id', JSON.stringify(id));
    this.detailAdmi();
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    if (tipo != null) {
      this.longitud = tipo.longitud;
    } else {
      this.longitud = 13;
    }
    this.request.numDocumento = '';
    if (tipo.id == 3 || tipo.id == 2) {
      this.valid = 'alphanum'
    } else {
      this.valid = 'num'
    }
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.admins, 'Usuarios_Administradores');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.admins, 'Usuarios_Administradores', '.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.admins, 'Usuarios_Administradores', '.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Usuarios_Administradores', this.admins);
        }
      },
    ];
  }

}

