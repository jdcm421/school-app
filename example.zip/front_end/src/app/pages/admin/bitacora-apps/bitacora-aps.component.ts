import { Component, OnInit } from '@angular/core';
import { RequestPage } from '@interfaces/request.interface';
import { BitacorasService } from '@services/admin/adminBitacoras.service';
import { MenuItem } from 'primeng/api';
import { TipoDispositivo, TipoOperaciones, puntosVenta } from '../../../core/interfaces/response.interface';

import { ExportService } from '@helpers/export.service';
import { AdminBitacora } from '@interfaces/admin/response/adminBitacorasResponse';
import { ResponseError } from '@interfaces/error-response.interface';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';

@Component({
  selector: 'app-bitacora-aps',
  templateUrl: './bitacora-aps.component.html',
  styleUrls: ['./bitacora-aps.component.scss']
})
export class BitacoraApsComponent implements OnInit {
  date: Date;
  tipoDispositivo:TipoDispositivo[];
  tipoOperacion:TipoOperaciones[];
  selectTipo:TipoDispositivo;
  selectOpera:TipoOperaciones;
  customers: AdminBitacora[];
  punto: puntosVenta[];
  selectPuntos:puntosVenta;
  fecha:string;
  request:RequestPage;
  first = 0;
  rows = 10;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'fecha', header: 'Fecha' },
    { field: 'puntoVenta', header: 'Punta Venta' },
    { field: 'tiempoOperacion', header: 'Tiempo Operación' },
    { field: 'intentos', header: 'Intentos de operación' },
    { field: 'tipoOperacion', header: 'Tipo de operación' },
    { field: 'dispositivo', header: 'Tipo Dispositivo' },
    { field: 'resultado', header: 'Resultado Actividad' },
    { field: 'detalle', header: 'Detalle Actividad' }
  ];
  exportColumns: any[];
  constructor(
    private _exportService: ExportService,
    public messageService: MessageService,
    public adminService: BitacorasService,
    private perfilesService : PerfilesService) { }

  ngOnInit(): void {
    this.request = {};
    this.tipoDispositivo = [];
    this.tipoOperacion = [];
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.puntosVentas();
    this.medioDispositivo();
    this.tipoOperaciones();
    this.listado();
    this.listItemsDownload();
  }

  listado(){
    this.adminService.bitacoras(this.request).subscribe(response => {
      this.customers = response.bitacoras;
      this.fecha = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  search(){
      this.adminService.bitacoras(this.request).subscribe(response => {
        this.customers = response.bitacoras;
        this.fecha = response.fechaActualizacion;
      }, (error:ResponseError) =>{
        console.error(error);
      });
  }

  puntosVentas(){
    this.adminService.puntos().subscribe(r => {
      this.punto = r.puntos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  milisegundosAMinutosYSegundos(milisegundos:number):string {
    const minutos = ((((milisegundos / 1000) / 1000)/ 60)/60);
	  const segundos = (((milisegundos / 1000)/ 1000)/60);
    return '0'+Number(minutos.toFixed(0)) +':'+Number(segundos.toFixed(0));
  }

  tipoOperaciones(){
    this.perfilesService.getTipoOperacion().subscribe(response =>{
      this.tipoOperacion = response;
    })
  }

  medioDispositivo(){
    this.perfilesService.getTipoDispositivo().subscribe(response => {
      this.tipoDispositivo = response;
    });
  }


  limpiar(){
    this.request = {};
    this.selectOpera = {};
    this.listado();
  }

  updated(){
    window.location.reload();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.customers,'Bitacoras_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.customers,'Bitacoras_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.customers,'Bitacoras_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Bitacoras_', this.customers);
        }
      },
    ];
  }
}
