import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CentroRecargasMovimientosComponent } from './centro-recargas-movimientos.component';

describe('CentroRecargasMovimientosComponent', () => {
  let component: CentroRecargasMovimientosComponent;
  let fixture: ComponentFixture<CentroRecargasMovimientosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CentroRecargasMovimientosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CentroRecargasMovimientosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
