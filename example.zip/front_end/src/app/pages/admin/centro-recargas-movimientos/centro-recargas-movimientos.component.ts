import { Component } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { AdminMovimientoCentro } from '@interfaces/admin/response/adminMovimientoCentro';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { AdminMovimientoCentroService } from '@services/admin/admin-movimiento-centro.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-centro-recargas-movimientos',
  templateUrl: './centro-recargas-movimientos.component.html',
  styleUrls: ['./centro-recargas-movimientos.component.scss']
})
export class CentroRecargasMovimientosComponent {
  data:AdminMovimientoCentro[];
  fecha:string;
  request:RequestPage;
  rows:number;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'centro', header: 'Nombre Centro de Recarga'  },
    { field: 'documento', header: 'Numero de Documento' },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'pasajero', header: 'Pasajero'},
    { field: 'id', header: 'IdTransaccion'  },
    { field: 'monto', header: 'Monto Recarga' },
    { field: 'montoComsion', header: '% de Comision' }
  ];
  exportColumns: any[];

  constructor(private movimientoService : AdminMovimientoCentroService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit(): void {
    this.data = [];
    this.request = {};
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  getMovimientos(){
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.fecha = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  search(){
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = [];
      this.data = response.movimientos;
      this.fecha = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  filterKey(text:string){
    this.request = {};
    console.log(this.request);
    this.request.nombreEmpresa = text;
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.fecha = response.fechaActualizacion;
    });

  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    this.getMovimientos();
    window.location.reload();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Centro_Recargas_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Centro_Recargas_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Centro_Recargas_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Centro_Recargas_', this.data);
        }
      },
    ];
  }
}
