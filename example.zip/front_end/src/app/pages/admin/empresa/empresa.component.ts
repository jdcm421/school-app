import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { AdminEmpresaTransportista } from '@interfaces/admin/response/adminEmpresaTransporteResponse';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { AdminEmpresaTransporteService } from '@services/admin/adminEmpresaTransporte.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-empresa',
  templateUrl: './empresa.component.html',
  styleUrls: ['./empresa.component.scss']
})
export class EmpresaComponent implements OnInit {
  customers: AdminEmpresaTransportista[];
  request:RequestPage;
  fecha:string;
  first = 0;
  rows = 10;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'numDocumento', header: 'N° Documento' },
    { field: 'empresaTransporte', header: 'Empresa Transporte' },
    { field: 'placa', header: 'Placa Vehiculo' },
    { field: 'ruta', header: 'Ruta' },
    { field: 'unidad', header: 'Tipo Unidad' },
    { field: 'asientos', header: 'Número de Asientos' }
  ];
  exportColumns: any[];
  constructor(private _exportService: ExportService,
    public messageService: MessageService,
    public empresaService: AdminEmpresaTransporteService) { }

  ngOnInit() {
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.request = {};
    this.customers= [];
    this.empresas();
    this.listItemsDownload();
  }

  empresas(){
    this.empresaService.getTransportista(this.request).subscribe(response => {
      this.customers = response.transportista;
      this.fecha = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.empresaService.getTransportista(this.request).subscribe(response => {
      this.customers = response.transportista;
      this.fecha = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.empresas();
  }

  updated(){
    window.location.reload();
  }

  status(id:number){
    this.empresaService.changeStatus(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.empresas();
      }
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.customers,'Empresa_Transporte_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.customers,'Empresa_Transporte_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.customers,'Empresa_Transporte_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Empresa_Transporte_', this.customers);
        }
      },
    ];
  }
}
