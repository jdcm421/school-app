import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { AdminMovimiento } from '@interfaces/admin/response/adminMovimientoResponse';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU, TipoOperaciones } from '@interfaces/response.interface';
import { DetaillMovimientoComponent } from '@modals/admin/detaill-movimiento/detaill-movimiento.component';
import { MovimientoService } from '@services/admin/adminMovimiento.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-movimientos',
  templateUrl: './movimientos.component.html',
  styleUrls: ['./movimientos.component.scss'],
  providers: [DialogService]
})
export class MovimientosComponent implements OnInit {
  data: AdminMovimiento[];
  rows = 10;
  date: Date;
  admin: number;
  private ref: DynamicDialogRef;
  request: RequestPage;
  itemsDownload: MenuItem[];
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  longitud: number;
  cols: any[];
  exportColumns: any[];
  nameTable: string;
  tipoOperacion: TipoOperaciones[];
  selectedOperacion: TipoOperaciones;

  constructor(private movimientoService: MovimientoService,
    private _documentTypeService: DocumentTypeService,
    private perfilesService: PerfilesService,
    public dialogService: DialogService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit(): void {
    this.nameTable = 'table-excel';
    this.request = {};
    this.admin = 0;
    this.selectedTypeDocument = {};
    this.selectedOperacion = {};
    this.listTuypeDocuments();
    this.tipoOperaciones();
    this.getMovimientos();

    this.cols = [
      { field: 'id', header: 'ID' },
      { field: 'fecha', header: 'Fecha' },
      { field: 'hora', header: 'Hora' },
      { field: 'tipoDoc', header: 'Tipo Documento' },
      { field: 'documento', header: 'Número Documento' },
      { field: 'nombre', header: 'Nombre' },
      { field: 'apellidos', header: 'Apellidos' },
      { field: 'tipoOperacion', header: 'Tipo Operacion' },
      { field: 'placa', header: 'Placa' },
      { field: 'ruta', header: 'Ruta' },
      { field: 'monto', header: 'Monto' }
    ]
    this.exportColumns = this.cols.map((col) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  public showUseRegister(tipo: string) {
    this.ref = this.dialogService.open(DetaillMovimientoComponent, {
      header: tipo == 'V' ? 'Detalle Movimiento Consumo' : 'Detalle Movimiento Recarga',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe((response: ResponseATU) => {
      if (localStorage.getItem('id') != null) {
        localStorage.removeItem('id');
      }
    });
  }


  getMovimientos() {
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }


  search() {
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  limpiar() {
    this.request = {};
    this.selectedTypeDocument = {};
    this.selectedOperacion = {};
    this.getMovimientos();
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    this.longitud = tipo.longitud;
  }


  edit(id: number, tipo: string) {
    if (localStorage.getItem('id') != null) {
      localStorage.removeItem('id');
    }
    localStorage.setItem('id', JSON.stringify(id));
    this.showUseRegister(tipo);
  }

  tipoOperaciones() {
    this.perfilesService.getTipoOperacion().subscribe(response => {
      this.tipoOperacion = response;
    })
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Movimientos_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data, 'Movimientos_', '.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data, 'Movimientos_', '.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Movimientos_', this.data);
        }
      },
    ];
  }

}
