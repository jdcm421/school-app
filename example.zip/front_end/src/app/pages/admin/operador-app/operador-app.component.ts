import { Component } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { AdminMovimientoOperadores } from '@interfaces/admin/response/adminMovimientoOperador';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { AdminMovimientoOperadorService } from '@services/admin/admin-movimiento-operador.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-operador-app',
  templateUrl: './operador-app.component.html',
  styleUrls: ['./operador-app.component.scss']
})
export class OperadorAppComponent {
  data: AdminMovimientoOperadores[];
  rows = 10;
  textFilter:any;
  date:string;
  rol:string = localStorage.getItem('rol');
  request:RequestPage;
  itemsDownload: MenuItem[];

  cols: any[] = [
    { field: 'id', header: 'IdTransaccion'  },
    { field: 'origen', header: 'Origen'  },
    { field: 'pasajero', header: 'Pasajero'},
    { field: 'numDocumento', header: 'Numero de Documento' },
    { field: 'empresa', header: 'Empresa Transporte'},
    { field: 'placa', header: 'Placa' },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'monto', header: 'Monto' },
    { field: 'tipoOperaciones', header: 'Tipo operación' }
  ];
  exportColumns: any[];
  constructor(
    private _exportService: ExportService,
    private movimientoService : AdminMovimientoOperadorService,
    public messageService: MessageService
  ) { }

  ngOnInit(): void {
    this.request = {};
    this.data = [];
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
    this.getMovimientos();
  }

  getMovimientos(){
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.date = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.date = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  filterKey(text:string){
    this.data = [];
    this.request.nombreEmpresa = text;
    this.movimientoService.movimientosAdmin(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.date = response.fechaActualizacion;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    window.location.reload();
  }


  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Operador_Apps_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.xlsx');
         }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Operador_Apps_', this.data);
        }
      }
    ];
  }
}
