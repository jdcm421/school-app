import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { requestDetail, requestFidei } from '@interfaces/request.interface';
import { Movimiento, TipoOperaciones } from '@interfaces/response.interface';
import { MovimientoService } from '@services/admin/adminMovimiento.service';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';
import { MenuItem } from 'primeng/api/menuitem';

@Component({
  selector: 'app-report-detail-admin',
  templateUrl: './report-detail-admin.component.html',
  styleUrls: ['./report-detail-admin.component.scss']
})
export class ReportDetailAdminComponent implements OnInit {

  request:requestDetail;
  requestFidei:requestFidei;
  data:Movimiento[];
  tipoOperacion:TipoOperaciones[];
  recargaAll:Movimiento[];
  itemsDownload: MenuItem[];
  montoRecarga:number;
  montosRecargas:number;
  montosValidacion:number;
  resultMontos:number;
  montoFidei:number;
  docFidei:string;
  montoDiscount:number;
  totalRecargas:number;
  totalcentro:number;
  totalpasajero:number;
  totaltransporte:number;
  totaltransportcomi:number;
  totalFideicomiso:number;
  cols: any[] = [
    { header: 'Id Transaccion', field: 'id' },
    { header: 'Tipo Operación', field: 'tipoOperacion' },
    { header: 'Documento Pasajero', field: 'numDocumento' },
    { header: 'Fecha', field: 'fecha' },
    { header: 'Hora', field: 'hora' },
    { header: 'Agente Operacion', field: 'agente' },
    { header: 'Empresa Transporte', field: 'empresa' },
    { header: 'Recarga (S/.)', field: 'recargas' },
    { header: 'Validaciones (S/.)', field: 'transporte' },
    { header: 'Comision Centro Recarga (3,5%)', field: 'comisionRecarga' },
    { header: 'Comision App Pasajero (3,5%)', field: 'comisionOperador' },
    { header: 'Comision Transportista (93%)', field: 'comisionTransporte' },
    { header: 'Dinero Fideicomiso', field: 'fideicomiso' }
  ];
  dataExportExcel:any[];
  exportColumns: any[];
  constructor(private _exportService: ExportService,
    private movimientoService : MovimientoService,
    public messageService: MessageService,
    private perfilesService : PerfilesService) { }

  ngOnInit() {
    this.request = {};
    this.dataExportExcel = [];
    this.data = [];
    this.recargaAll = [];
    this.montoDiscount = 0;
    this.montoRecarga = 0;
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.totalRecargas =0;
    this.totaltransporte=0;
    this.totalcentro=0;
    this.totalpasajero=0;
    this.totaltransportcomi=0;
    this.totalFideicomiso=0;
    this.listItemsDownload();
    this.reporte();
    this.tipoOperaciones();
  }

  tipoOperaciones(){
    this.perfilesService.getTipoOperacion().subscribe(response =>{
      this.tipoOperacion = response;
    })
  }

  reporte(){
    this.movimientoService.movimientosReporte(this.request).subscribe(response => {
      this.data = response.movimientos;
      this.data.forEach((item,i)=>{
        const items ={
          'tipoOperacion':item.tipoOperaciones.abrev,
          'id':item.id,
          'numDocumento':item.pasajero.numDocumento,
          'fecha':item.fecha,
          'hora':item.hora,
          'agente':item.centroRecarga != null ? item.centroRecarga.centroRecarga.nombreCentroRecarga : item.operador != null ? item.operador.usuario.nombreCompleto : '--',
          'empresa':item.transporte != null ? item.transporte.empresa.empresaTransporte : '--',
          'recargas':item.tipoOperaciones.abrev == 'R' ? item.monto.toFixed(2) : 0,
          'transporte':item.tipoOperaciones.abrev == 'V' ? '-'+ item.monto.toFixed(2) : 0,
          'comisionRecarga':item.comisionCentro.toFixed(2),
          'comisionOperador':item.comisionPasajero.toFixed(2),
          'comisionTransporte':item.comisionTransporte.toFixed(2),
          'fideicomiso':item.fideicomiso.toFixed(2),
          'recargasReal':item.tipoOperaciones.abrev == 'R' ? item.monto : 0,
          'transporteReal':item.tipoOperaciones.abrev == 'V' ? '-'+ item.monto : 0,
          'comisionRecargaReal':item.comisionCentro,
          'comisionOperadorReal':item.comisionPasajero,
          'comisionTransporteReal':item.comisionTransporte,
          'fideicomisoReal':item.fideicomiso
        }
        this.dataExportExcel.push(items);
      });
      this.totalRecargas = this.data.reduce((acc,obj,) => acc + (obj.tipoOperaciones.id==2 ? obj.monto : 0),0);
      this.totaltransporte= this.data.reduce((acc,obj,) => acc + (obj.tipoOperaciones.id==1 ? obj.monto : 0),0);
      this.totalcentro= this.data.reduce((acc,obj,) => acc + (obj.comisionCentro),0);
      this.totalpasajero= this.data.reduce((acc,obj,) => acc + (obj.comisionPasajero),0);
      this.totaltransportcomi= this.data.reduce((acc,obj,) => acc + (obj.comisionTransporte),0);
      this.totalFideicomiso= this.data.reduce((acc,obj,) => acc + (obj.fideicomiso),0);
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    if(this.request.fechaInicio  != null && this.request.fechaFin != null && this.request.numDocumento != null && this.request.tipo != null){
      this.movimientoService.movimientosReporte(this.request).subscribe(response => {
        this.data = response.movimientos;
      }, (error:ResponseError) =>{
        console.error(error);
      });
    }else if (this.request.numDocumento != null && this.request.tipo != null){
      this.movimientoService.movimientosReporte(this.request).subscribe(response => {
        this.data = response.movimientos;
      }, (error:ResponseError) =>{
        console.error(error);
      });
    }else if(this.request.numDocumento != null){
      this.data = this.data.filter(d => d.pasajero.numDocumento == this.request.numDocumento);
    }else if (this.request.tipo != null){
      this.data = this.data.filter(d => d.tipoOperaciones.abrev == this.request.tipo);
    }else if (this.request.fechaInicio  != null && this.request.fechaFin == null){
      this.messageService.showWarn("Ingrese fecha de fin");
    }else if(this.request.fechaInicio  != null && this.request.fechaFin != null){
      this.movimientoService.movimientosReporte(this.request).subscribe(response => {
        this.data = response.movimientos;
      }, (error:ResponseError) =>{
        console.error(error);
      });
    }
    this.totalRecargas =0;
    this.totaltransporte=0;
    this.totalcentro=0;
    this.totalpasajero=0;
    this.totaltransportcomi=0;
    this.totalFideicomiso=0;
    this.dataExportExcel = [];
    this.data.forEach((item,i)=>{
      const items ={
        'tipoOperacion':item.tipoOperaciones.abrev,
        'id':item.id,
        'numDocumento':item.pasajero.numDocumento,
        'fecha':item.fecha,
        'hora':item.hora,
        'agente':item.centroRecarga != null ? item.centroRecarga.centroRecarga.nombreCentroRecarga : item.operador != null ? item.operador.usuario.nombreCompleto : '--',
        'empresa':item.transporte != null ? item.transporte.empresa.empresaTransporte : '--',
        'recargas':item.tipoOperaciones.abrev == 'R' ? item.monto.toFixed(2) : 0,
        'transporte':item.tipoOperaciones.abrev == 'V' ? '-'+ item.monto.toFixed(2) : 0,
        'comisionRecarga':item.comisionCentro.toFixed(2),
        'comisionOperador':item.comisionPasajero.toFixed(2),
        'comisionTransporte':item.comisionTransporte.toFixed(2),
        'fideicomiso':item.fideicomiso.toFixed(2),
        'recargasReal':item.tipoOperaciones.abrev == 'R' ? item.monto : 0,
        'transporteReal':item.tipoOperaciones.abrev == 'V' ? '-'+ item.monto : 0,
        'comisionRecargaReal':item.comisionCentro,
        'comisionOperadorReal':item.comisionPasajero,
        'comisionTransporteReal':item.comisionTransporte,
        'fideicomisoReal':item.fideicomiso
      }
      this.dataExportExcel.push(items);
    });
    console.log(this.data);
    this.totalRecargas = this.data.reduce((acc,obj,) => acc + (obj.tipoOperaciones.id==2 ? obj.monto : 0),0);
    this.totaltransporte= this.data.reduce((acc,obj,) => acc + (obj.tipoOperaciones.id==1 ? obj.monto : 0),0);
    this.totalcentro= this.data.reduce((acc,obj,) => acc + (obj.comisionCentro),0);
    this.totalpasajero= this.data.reduce((acc,obj,) => acc + (obj.comisionPasajero),0);
    this.totaltransportcomi= this.data.reduce((acc,obj,) => acc + (obj.comisionTransporte),0);
    this.totalFideicomiso= this.data.reduce((acc,obj,) => acc + (obj.fideicomiso),0);
  }

 /*  fideicomiso(item:Movimiento):number{

    this.montoDiscount = 0;
    this.montoDiscount = item.comisionCentro+item.comisionPasajero+item.comisionTransporte;
    console.log("Inicio");
    this.montoRecarga = 0;
    if(item.tipoOperaciones.abrev == 'R'){
      this.montoRecarga = item.monto;
    }else{
      this.montoRecarga = 0;
    }
    console.log("pasajero actual");
    console.log(item.pasajero.numDocumento);
    console.log("Monto de la recarga Actual");
    console.log(this.montoRecarga);
    console.log("Comision actual");
    console.log(this.montoDiscount);
    console.log("pasajero anterior");
    console.log(this.docFidei);
    console.log("Resultado anterior");
    console.log(this.resultMontos);
    this.montoFidei = 0;
    if(item.pasajero.numDocumento != this.docFidei){
    this.resultMontos = 0;
    this.montosRecargas =0;
    this.montosValidacion = 0;
    this.docFidei = null;
    this.docFidei = item.pasajero.numDocumento;
    this.data.filter(m => m.pasajero.numDocumento == item.pasajero.numDocumento && m.fecha == item.fecha && m.tipoOperaciones.abrev == 'R').forEach((r,i)=>{
      this.montosRecargas += r.monto;
    });
    console.log("Monto de Recargas");
    console.log(this.montosRecargas);
    this.data.filter(m => m.pasajero.numDocumento == item.pasajero.numDocumento && m.fecha == item.fecha).forEach((v,i)=>{
      this.montosValidacion += (v.comisionCentro+v.comisionPasajero+v.comisionTransporte)
    });
    console.log("Total comisiones");
    console.log(this.montosValidacion);
    console.log("Resultado")
    this.resultMontos = Number((this.montosRecargas - Number((this.montosValidacion).toFixed(2))).toFixed(2));
    console.log(this.resultMontos);
    this.montoFidei = Number((this.resultMontos+=this.montoDiscount).toFixed(2));
    console.log(this.montoFidei);
    console.log("FIN DE LA PRIMERA");
    }else{
      this.resultMontos+=this.montoDiscount;
      console.log(this.resultMontos);
      this.montoFidei= this.resultMontos-=this.montoRecarga;
      console.log("resultado de resta si monto recarga es mayor a cero");
      console.log(this.montoFidei);
      console.log("FIN DE LAS SIGUIENTES");
    }
    console.log(this.montoFidei);
    return this.montoFidei;
  }
 */

  limpiar(){
    this.request = {};
    this.reporte();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.dataExportExcel,'Reporte_Detallado_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Reporte_Detallado_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Reporte_Detallado_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Reporte_Detallado_', this.dataExportExcel);
        }
      },
    ];
  }
}
