import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { requestPago } from '@interfaces/request.interface';
import { DetalleIndicadore, ReporteIndicadore } from '@interfaces/response.interface';
import { MovimientoService } from '@services/admin/adminMovimiento.service';
import { MessageService } from '@services/message.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-fideicomiso-admin',
  templateUrl: './report-fideicomiso-admin.component.html',
  styleUrls: ['./report-fideicomiso-admin.component.scss']
})
export class ReportFideicomisoAdminComponent implements OnInit {
  request:requestPago;
  data:ReporteIndicadore[];
  detalle:DetalleIndicadore;
  tipo:any[];
  montoTotal:number;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'IdInstruccion', header: 'id Instruccion' },
    { field: 'fecha', header: 'fecha' },
    { field: 'hora', header: 'hora' },
    { field: 'Empresa', header: 'empresa' },
    { field: 'tipoOperacion', header: 'Tipo de operación' },
    { field: 'numDocumento', header: 'Número de Documento' },
    { field: 'montoTotal', header: 'Monto Total' },
    { field: 'montoComision', header: 'Monto Comision' },
  ];
  exportColumns: any[];
  dataExportExcel:any[];
  constructor(private _exportService: ExportService,
    private movimientoService : MovimientoService,
    public messageService: MessageService,
    private _location: Location) { }

  ngOnInit() {
    this.request = {};
    this.data = [];
    this.dataExportExcel = [];
    this.montoTotal = 0;
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.reporte();
  }

  reporte(){
    this.montoTotal = 0;
    this.movimientoService.movimientosReportePago(this.request).subscribe(response => {
      this.data = response.reporteIndicadores;
      this.data.forEach((item,i)=>{
        item.detalleIndicadores.forEach((det,d)=>{
          this.montoTotal+=Number(det.montoTotal.toFixed(2));
        })
      });
    }, (error:ResponseError) =>{
      console.error(error);
      if(error.codigo == 403){
        this._location.back();
      }

    });
  }

  search(){
    this.montoTotal = 0;
    this.movimientoService.movimientosReportePago(this.request).subscribe(response => {
      this.data = response.reporteIndicadores;
      this.data.forEach((item,i)=>{
        item.detalleIndicadores.forEach((det,d)=>{
          this.montoTotal+=Number(det.montoTotal.toFixed(2));
        })
      });
    }, (error:ResponseError) =>{
      console.error(error);
      if(error.codigo == 403){
        this._location.back();
      }

    });
  }

  limpiar(){
    this.request = {};
    this.reporte();
  }

  exportDocument(item:ReporteIndicadore,doc:string){
    this.dataExportExcel = [];

    item.detalleIndicadores.forEach((item,i)=>{
      const items ={
        'IdInstruccion':item.idTransaccion,
        'fecha':item.fechaTransaccion,
        'hora':item.horaTransaccion,
        'Empresa':item.empresa,
        'tipoOperacion':item.tipoOperacion,
        'numDocumento':item.numDocumento,
        'montoTotal': item.montoPago.toFixed(2),
        'montoTotalReal':item.montoPago,
        'montoComision':item.montoTotal.toFixed(2),
        'montoComisionReal':item.montoTotal
      }
      this.dataExportExcel.push(items);
    })
    if(doc == 'pdf'){
      this._exportService
            .exportPdf(this.exportColumns,this.dataExportExcel ,'Reporte_Instruccion_Pago_');
    }else if(doc == 'excel'){
      this._exportService
            .exportExcel(this.exportColumns,this.dataExportExcel ,'Reporte_Instruccion_Pago_','.xlsx');
    }else if(doc == 'csv'){
      this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Reporte_Instruccion_Pago_','.csv');
    }else{
      this._exportService
            .exportText('Reporte_Instruccion_Pago_', this.dataExportExcel);
    }
  }

}
