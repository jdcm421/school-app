import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { Sucursal } from '@interfaces/response.interface';
import { Distrito } from '@interfaces/ubigeo.interface';
import { AdminSucursalesService } from '@services/admin/adminSucursales.service';
import { MessageService } from '@services/message.service';
import { UbigeoService } from '@services/ubigeo.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-sucursales',
  templateUrl: './sucursales.component.html',
  styleUrls: ['./sucursales.component.scss']
})
export class SucursalesComponent implements OnInit {

  data:Sucursal[];
  suc:number=+localStorage.getItem('suc');
  id:number=+localStorage.getItem('id');
  distrito:Distrito[];
  selectedCountry:Distrito;
  request:RequestPage;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { header: 'Tipo Documento', field: 'tipoDocumento' },
    { header: 'Numero Documento', field: 'numDocumento' },
    { header: 'Nombre Empresa', field: 'nombreEmpresa' },
    { header: 'Dirección', field: 'direccion' },
    { header: 'Ubigeo', field: 'ubigeo' }
  ];
  exportColumns: any[];
  blockChars: RegExp = /^[^<>*!]+$/;
  int:string="int";

  constructor(
    public messageService: MessageService,
    public sucursalService: AdminSucursalesService,
    private _exportService: ExportService,
    private ubigeo:UbigeoService) { }

  ngOnInit() {
    this.request = {};
    this.sucursal();
    this.data = [];
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
    this.distritos();
  }

  sucursal(){
    this.sucursalService.getSucursales(this.request).subscribe(response =>{
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  status(id:number){
    this.sucursalService.changeStatus(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.sucursal();
      }
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.selectedCountry={};
    this.request = {};
    this.data = [];
    this.sucursal();
  }

  private distritos() {
    this.ubigeo.getDistritoAll().subscribe((response) => {this.distrito = response})
  }

  search(){
    this.sucursalService.getSucursales(this.request).subscribe(response =>{
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  filterEmpresa(text:string){
    this.data = [];
    this.request = {};
    this.request.nombreCentroCarga = text;
    this.sucursalService.getSucursales(this.request).subscribe(response =>{
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  filterDireccion(text:string){
    this.data = [];
    this.request = {};
    this.request.direccion = text;
    this.sucursalService.getSucursales(this.request).subscribe(response =>{
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });

  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Sucursales_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Sucursales_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Sucursales_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Sucursales_', this.data);
        }
      },
    ];
  }

}
