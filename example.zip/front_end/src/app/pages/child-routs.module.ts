import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { appRout } from '../helpers/constants/index';
import { AdminCentroSucursalesComponent } from './admin/admin-centro-sucursales/admin-centro-sucursales.component';
import { AdminOperadorComponent } from './admin/admin-operador/admin-operador.component';
import { UsersComponent } from './admin/admin-passenger/users.component';
import { AdminRecargaComponent } from './admin/admin-recarga/admin-recarga.component';
import { AdminTransporteComponent } from './admin/admin-transporte/admin-transporte.component';
import { AdministradorComponent } from './admin/administrador/administrador.component';
import { BitacoraApsComponent } from './admin/bitacora-apps/bitacora-aps.component';
import { CentroRecargasMovimientosComponent } from './admin/centro-recargas-movimientos/centro-recargas-movimientos.component';
import { EmpresaComponent } from './admin/empresa/empresa.component';
import { MovimientosComponent } from './admin/movimientos/movimientos.component';
import { OperadorAppComponent } from './admin/operador-app/operador-app.component';
import { ReportDetailAdminComponent } from './admin/report-detail-admin/report-detail-admin.component';
import { ReportFideicomisoAdminComponent } from './admin/report-fideicomiso-admin/report-fideicomiso-admin.component';
import { SucursalesComponent } from './admin/sucursales/sucursales.component';
import { CentroRecargaEmpresasComponent } from './passenger/centro-recarga-empresas/centro-recarga-empresas.component';
import { DerechoArcoComponent } from './passenger/derecho-arco/derecho-arco.component';
import { DudasConsultasComponent } from './passenger/dudas-consultas/dudas-consultas.component';
import { MovimientoPassengerComponent } from './passenger/movimiento-passenger/movimiento-passenger.component';
import { PassengerSucursalesComponent } from './passenger/passenger-sucursales/passenger-sucursales.component';
import { TransportCompanyComponent } from './passenger/transport-company/transport-company.component';
import { ReportDetailCentroComponent } from './user/centro-recarga/report-detail-centro/report-detail-centro.component';
import { ReportFideicomisoCentroComponent } from './user/centro-recarga/report-fideicomiso-centro/report-fideicomiso-centro.component';
import { UserCentroSucursalesComponent } from './user/centro-recarga/user-centro-sucursales/user-centro-sucursales.component';
import { ReportDetailOperatorComponent } from './user/operador/report-detail-operator/report-detail-operator.component';
import { ReportFideicomisoOperatorComponent } from './user/operador/report-fideicomiso-operator/report-fideicomiso-operator.component';
import { ControlTarifarioComponent } from './user/transportista/control-tarifario/control-tarifario.component';
import { GeneradorQrComponent } from './user/transportista/generador-qr/generador-qr.component';
import { HistorialTarifarioComponent } from './user/transportista/historial-tarifario/historial-tarifario.component';
import { MovimientosEmpresaComponent } from './user/transportista/movimientos-empresa/movimientos-empresa.component';
import { QuejasReclamosComponent } from './user/transportista/quejas-reclamos/quejas-reclamos.component';
import { ReportDetailTransportComponent } from './user/transportista/report-detail-transport/report-detail-transport.component';
import { ReportFideicomisoTransportComponent } from './user/transportista/report-fideicomiso-transport/report-fideicomiso-transport.component';

const childRouts: Routes = [
  //ADMINISTRADOR
  { path: 'Web-ATU', component: AdministradorComponent, data: { title: 'Usuarios Administradores' } },
  { path: appRout.admin.path, component: AdministradorComponent, data: { title: 'Usuarios Administradores' } },
  { path: appRout.transportista.path, component: AdminTransporteComponent, data: { title: 'Usuarios Transporte' } },
  { path: appRout.recargador.path, component: AdminRecargaComponent, data: { title: 'Usuarios Centro de Recarga' } },
  { path: appRout.operadorapp.path, component: AdminOperadorComponent, data: { title: 'Usuarios Operador Apps' } },
  { path: appRout.user.path, component: UsersComponent, data: { title: 'Usuarios Pasajero' } },
  { path: appRout.pasajero.path, component: UsersComponent, data: { title: 'Pasajero' } },
  { path: appRout.movimientos.path, component: MovimientosComponent, data: { title: 'Movimientos' } },
  { path: appRout.transporte.path, component: EmpresaComponent, data: { title: 'Empresa de Transporte Vehiculos' } },
  { path: appRout.sucursalesByCentro.path, component: AdminCentroSucursalesComponent, data: { title: 'Sucursales por Centro' } },
  { path: appRout.sucursales.path, component: SucursalesComponent, data: { title: 'Sucursales' } },
  { path: appRout.bitacora.path, component: BitacoraApsComponent, data: { title: 'Bitácora de APS' } },
  { path: appRout.recargas.path, component: CentroRecargasMovimientosComponent, data: { title: 'Centros de Recargas' } },
  { path: appRout.operador.path, component: OperadorAppComponent, data: { title: 'Operador APP' } },
  { path: appRout.reporteFideicomiso.path, component: ReportFideicomisoAdminComponent, data: { title: 'Reporte Instruccion de Pago' } },
  { path: appRout.reporteDetallado.path, component: ReportDetailAdminComponent, data: { title: 'Detalle para Instrucciones de Pago' } },


  //PASAJERO
  { path: appRout.sucursalePassenger.path, component: PassengerSucursalesComponent, data: { title: 'Sucursales' } },
  { path: appRout.movimientosPassenger.path, component: MovimientoPassengerComponent, data: { title: 'Movimientos Pasajero' } },
  { path: appRout.empresaTransporte.path, component: TransportCompanyComponent, data: { title: 'Empresa de Transporte' } },
  { path: appRout.centroRecargaPassenger.path, component: CentroRecargaEmpresasComponent, data: { title: 'Centro Recargas' } },
  { path: appRout.gestion.path, component: DerechoArcoComponent, data: { title: 'Gestion Derechos Arcos' } },
  { path: appRout.duda.path, component: DudasConsultasComponent, data: { title: 'Dudas y consultas' } },

  //USUARIO OPERADOR
  { path: appRout.reporteFideicomisoOperador.path, component: ReportFideicomisoOperatorComponent, data: { title: 'Reporte Fideicomiso' } },
  { path: appRout.reporteDetalladoOperador.path, component: ReportDetailOperatorComponent, data: { title: 'Reporte Detallado' } },

  //USUARIO TRANSPORTISTA
  { path: appRout.control.path, component: ControlTarifarioComponent, data: { title: 'Control Tarifario' } },
  { path: appRout.historial.path, component: HistorialTarifarioComponent, data: { title: 'Historial Tarifario' } },
  { path: appRout.qr.path, component: GeneradorQrComponent, data: { title: `Generador Qr's` } },
  { path: appRout.reporteFideicomisoTransporte.path, component: ReportFideicomisoTransportComponent, data: { title: 'Reporte Fideicomiso' } },
  { path: appRout.movimientosEmpresaTransporte.path, component: MovimientosEmpresaComponent, data: { title: 'Movimientos Transporte' } },
  { path: appRout.reclamos.path, component: QuejasReclamosComponent, data: { title: 'Contactanos' } },
  { path: appRout.reporteDetalladoTransporte.path, component: ReportDetailTransportComponent, data: { title: 'Reporte Detallado' } },

  //USUARIO CENTRO DE RECARGA
  { path: appRout.sucursalesUserCentro.path, component: UserCentroSucursalesComponent, data: { title: 'Sucursales' } },
  { path: appRout.reporteFideicomisoCentroRecarga.path, component: ReportFideicomisoCentroComponent, data: { title: 'Reporte Fideicomiso' } },
  { path: appRout.reporteDetalladoCentroRecarga.path, component: ReportDetailCentroComponent, data: { title: 'Reporte Detallado' } },

]

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(childRouts)
  ],
  exports: [RouterModule]
})
export class ChildRoutsModule {

}
