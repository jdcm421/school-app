/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { AdminCentroSucursalesRegComponent } from './admin-centro-sucursales-reg.component';

describe('AdminCentroSucursalesRegComponent', () => {
  let component: AdminCentroSucursalesRegComponent;
  let fixture: ComponentFixture<AdminCentroSucursalesRegComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminCentroSucursalesRegComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCentroSucursalesRegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
