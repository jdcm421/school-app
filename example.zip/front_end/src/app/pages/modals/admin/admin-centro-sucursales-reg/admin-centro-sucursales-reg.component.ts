import { Component, OnInit } from '@angular/core';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { RequestSucursal } from '@interfaces/request.interface';
import { CentroResponse, Sucursal } from '@interfaces/response.interface';
import { Departamento, Distrito, Provincia } from '@interfaces/ubigeo.interface';
import { CentroService } from '@services/admin/adminCentro.service';
import { SucursalesService } from '@services/admin/adminSucursales.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { UbigeoService } from '@services/ubigeo.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-admin-centro-sucursales-reg',
  templateUrl: './admin-centro-sucursales-reg.component.html',
  styleUrls: ['./admin-centro-sucursales-reg.component.scss']
})
export class AdminCentroSucursalesRegComponent implements OnInit {

  constructor(private centroServicio : CentroService,
    public sucursalService: SucursalesService,
    private _documentTypeService: DocumentTypeService,
    public messageService: MessageService,
    private ubigeoService: UbigeoService,
    public ref: DynamicDialogRef) { }

    distritos: Distrito[];
    provincias: Provincia[];
    departamentos: Departamento[];
    centro:CentroResponse;
    sucursal:Sucursal;
    request:RequestSucursal;
    suc:number=+localStorage.getItem('suc');
    id:number=+localStorage.getItem('id');
    selectedProvincia: Provincia;
    selectedDistrito: Distrito;
    selectedDepartamento: Departamento;
    documents: TipoDocumento[];
    selectedTypeDocument: TipoDocumento;

  ngOnInit() {
    this.listDepartamentos();
    this.listTuypeDocuments();
    this.sucursal = {};
    this.sucursal.centroRecarga = {};
    this.request = {};
    if(this.suc != 0 && this.id != 0){
      this.sucursalOne();
    }else if (this.suc != 0){
      this.centroOne();
    }
  }

  private listDepartamentos() {
    this.ubigeoService
      .getListDepartamentos().subscribe((response) => this.departamentos = response);
  }

  public listProvincias(departamento: Departamento) {
    this.ubigeoService
      .getProvinciaByIdDepartamento(departamento.id).subscribe((response) => this.provincias = response);
  }

  public listDistritos(provincia: Provincia) {
    this.ubigeoService
      .getDistritoByIdProvincia(provincia.id).subscribe((response) => this.distritos = response);
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response.filter(t => t.tipoDocumento == 'RUC'));
  }

  centroOne(){
    this.centroServicio.centroOne(this.suc).subscribe(response => {
      console.log(response);
      this.centro = response.centro;
      this.request.centroRecarga=this.centro.id;
      this.sucursal.centroRecarga= this.centro;
    });
  }

  sucursalOne(){
    this.sucursalService.sucursalOne(this.id).subscribe(response =>{
      console.log(response);
      this.sucursal = response.sucursal;
      this.request.centroRecarga = this.sucursal.centroRecarga.id;
      this.request.direccion = this.sucursal.direccion;
      this.listProvincias(this.sucursal.distrito.provincia.departamento);
      this.listDistritos(this.sucursal.distrito.provincia);
      this.selectedDepartamento =this.sucursal.distrito.provincia.departamento;
      this.selectedProvincia = this.sucursal.distrito.provincia;
      this.selectedDistrito = this.sucursal.distrito;
    });
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }

  save(){
    if(this.request.direccion == null || this.selectedDistrito == null){
      this.messageService.showWarn("Ingrese datos obligatorios");
    }
    this.request.distritoId = this.selectedDistrito.id;
    console.log(this.request);
    if(this.id == 0){
      this.sucursalService.sucursalRegistro(this.request).subscribe(response => {
        console.log(response);
        this.ref.close(response);
        localStorage.removeItem('id');
      });
    }else{
      this.sucursalService.sucursalActualizar(this.id,this.request).subscribe(response => {
        console.log(response);
        this.ref.close(response);
        localStorage.removeItem('id');
      });
    }
  }

}
