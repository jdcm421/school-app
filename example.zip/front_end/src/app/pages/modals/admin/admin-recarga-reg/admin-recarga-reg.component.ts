import { Component, OnInit } from '@angular/core';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerPage } from '@interfaces/passenger.interface';
import { RequestAdmin, RequestUserUpdated } from '@interfaces/request.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { Departamento, Distrito, Provincia } from '@interfaces/ubigeo.interface';
import { AdminService } from '@services/admin/admin.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { UbigeoService } from '@services/ubigeo.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-admin-recarga-reg',
  templateUrl: './admin-recarga-reg.component.html',
  styleUrls: ['./admin-recarga-reg.component.scss']
})
export class AdminRecargaRegComponent implements OnInit {
  distritos: Distrito[];
  provincias: Provincia[];
  departamentos: Departamento[];
  passenger:PassengerPage;
  request:RequestAdmin;
  requestUpdated:RequestUserUpdated;
  id:number=+localStorage.getItem('id');
  selectedProvincia: Provincia;
  selectedDistrito: Distrito;
  selectedDepartamento: Departamento;
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  tipoDocDisabled:boolean;
  documentoDisabled:boolean;
  perfiles:Perfil[];
  tipoUsuarios:TipoUsuario[]=[];
  selectedPerfil:Perfil;
  selectedTipoUsuario:TipoUsuario;
  countexception:number;
  countNumdocumento:number;
  requestValid:boolean;
  longitud:number;
  nombreDisableb:boolean;
  correo:boolean;
  valid:string;
  validPhone:string;

  constructor(private ubigeoService: UbigeoService,
    public messageService: MessageService,
    private _documentTypeService: DocumentTypeService,
    private passengerService:AdminService,
    public ref: DynamicDialogRef) { }

  ngOnInit() {
    this.listDepartamentos();
    this.listTuypeDocuments();
    this.request = {};
    this.validPhone = 'int';
    this.request.celularValid = false;
    this.request.distritoIdValid = false;
    this.request.correoValid = false;
    this.request.direccionValid = false;
    this.request.numDocumentoValid = false;
    this.request.nombreEmpresaValid = false;
    this.request.tipoDocIdValid = false;
    this.requestUpdated = {};
    if(this.id != 0){
      this.passengers(this.id);
      this.tipoDocDisabled=true;
      this.documentoDisabled=true;
      this.nombreDisableb=true;
      this.correo = true;
    }else{
      this.tipoDocDisabled=false;
      this.documentoDisabled=false;
      this.nombreDisableb=false;
      this.correo = false;
      this.passenger = {};
      this.passenger.usuario = {};
    }
  }

  private listDepartamentos() {
    this.ubigeoService
      .getListDepartamentos().subscribe((response) => this.departamentos = response);
  }

  public listProvincias(departamento: Departamento) {
    this.ubigeoService
      .getProvinciaByIdDepartamento(departamento.id).subscribe((response) => this.provincias = response);
      if(this.selectedProvincia != null && this.selectedDistrito != null){
        this.selectedProvincia = null;
        this.selectedDistrito = null;
      }
      this.request.distritoId == null
      this.request.distritoIdInputValid = '';
  }

  public listDistritos(provincia: Provincia) {
    this.ubigeoService
      .getDistritoByIdProvincia(provincia.id).subscribe((response) => this.distritos = response);
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response.filter(t => t.tipoDocumento == 'RUC'));
  }

  passengers(id:number){
    this.passengerService.consultAdmin(id).subscribe(response => {
      if(response.codigo == 200){
        this.passenger = response.admin;
        this.request.nombreEmpresa = this.passenger.usuario.nombreEmpresa;
        this.request.tipoDocId = this.passenger.tipoDocumento.id;
        this.request.numDocumento = this.passenger.numDocumento;
        this.request.distritoId = this.selectedDistrito != null ? this.selectedDistrito.id : this.passenger.usuario.distrito.id;
        this.request.correo = this.passenger.usuario.correo;
        this.request.celular = this.passenger.usuario.celular;
        this.request.direccion = this.passenger.usuario.direccion;
        this.selectedTypeDocument = this.passenger.tipoDocumento;
        if(this.passenger.usuario.distrito != null){
          this.listProvincias(this.passenger.usuario.distrito.provincia.departamento);
          this.listDistritos(this.passenger.usuario.distrito.provincia);
          this.longitud = this.passenger.tipoDocumento.longitud;
          this.selectedDepartamento =this.passenger.usuario.distrito.provincia.departamento;
          this.selectedProvincia = this.passenger.usuario.distrito.provincia;
          this.selectedDistrito = this.passenger.usuario.distrito;
        }
      }
    }, (error:ResponseError) =>{
      console.error(error);

    })
  }

  updated(){
    this.request.distritoId = this.selectedDistrito != null ? this.selectedDistrito.id : null;
    this.request.rolId = 2;
    console.log(this.request);
    if(this.validator(this.request)){
      this.messageService.showWarn("Ingrese todos los datos Obligatorios");
    }else{
      if(this.id != 0){
        this.requestUpdated.distritoId = this.selectedDistrito != null ? this.selectedDistrito.id : this.request.distritoId;
        this.requestUpdated.celular = this.request.celular != null ? this.request.celular :this.passenger.usuario.celular;
        this.requestUpdated.direccion = this.request.direccion != null ? this.request.direccion : this.passenger.usuario.direccion;
        this.passengerService.editCentroRecarga(this.id,this.requestUpdated).subscribe(response => {
          if(response.codigo == 200){
            this.ref.close(response);
            localStorage.removeItem('id');
          }
        }, (error:ResponseError) =>{
          console.error(error);

        });
      }else{
        console.log(this.request);
        this.request.tipoDocId = this.selectedTypeDocument.id;
        this.request.distritoId = this.selectedDistrito.id;
        this.passengerService.regCentroRecarga(this.request).subscribe(response => {
          if(response.codigo == 201){
            this.ref.close(response);
            localStorage.removeItem('id');
          }
        }, (error:ResponseError) =>{
          console.error(error);

        });
      }
    }
  }

  public validaTipoDocumento(tipo:TipoDocumento){
    console.log(tipo);
    this.longitud = tipo.longitud;
    this.valid = 'int';
    this.request.tipoDocIdInputValid = '';
  }

  public validator(request:RequestAdmin): Boolean {
    console.log(request);
    this.countexception = 0;
    if(request.direccion == null || request.direccion.length < 1){
      this.request.direccionValid = true;
      this.request.direccionInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.direccionValid = false;
      this.request.direccionInputValid = '';
    }
    if(request.celular == null || request.celular.length < 1){
      this.request.celularValid = true;
      this.request.celularInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.celularValid = false;
      this.request.celularInputValid = '';
    }
    if(request.nombreEmpresa == null || request.nombreEmpresa.length < 1){
      this.request.nombreEmpresaValid = true;
      this.request.nombreEmpresaInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.nombreEmpresaValid = false;
      this.request.nombreEmpresaInputValid = '';
    }
    if(request.correo == null || request.correo.length < 1){
      this.request.correoValid = true;
      this.request.correoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.correoValid = false;
      this.request.correoInputValid = '';
    }
    if(this.selectedTypeDocument == null){
      this.request.tipoDocIdValid = true;
      this.request.tipoDocIdInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.tipoDocIdValid = false;
      this.request.tipoDocIdInputValid = '';
    }
    if(this.selectedDistrito == null || this.request.distritoId == null){
      this.request.distritoIdValid = true;
      this.request.distritoIdInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.distritoIdValid = false;
      this.request.distritoIdInputValid = '';
    }
    if(request.numDocumento == null || request.numDocumento.length <= 1){
      this.request.numDocumentoValid = true;
      this.request.numDocumentoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    }else{
      this.request.numDocumentoValid = false;
      this.request.numDocumentoInputValid = '';
    }
    console.log(this.countexception);
    if(this.countexception != 0){
      this.requestValid=true;
    }else{
      this.requestValid = false;
    }
    console.log(this.requestValid);
    return this.requestValid;
  }

  public numDocumento(doc:string){
    this.countNumdocumento = doc.length;
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }
}
