import { Component, OnInit } from '@angular/core';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerPage } from '@interfaces/passenger.interface';
import { RequestAdmin, RequestAdminUpdated } from '@interfaces/request.interface';
import { TipoUsuario } from '@interfaces/roles.interface';
import { AdminService } from '@services/admin/admin.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { Modulo } from '../../../../core/interfaces/passenger.interface';
import { ModuleService } from '../../../../core/services/admin/adminModule.service';

@Component({
  selector: 'app-admin-register',
  templateUrl: './admin-register.component.html',
  styleUrls: ['./admin-register.component.scss']
})
export class AdminRegisterComponent implements OnInit {

  admin: PassengerPage;
  request: RequestAdmin;
  requestUpdated: RequestAdminUpdated;
  modules: Modulo[];
  tipoUsuarios: TipoUsuario[];
  documents: TipoDocumento[];
  tipoDisabled: boolean;
  docDisabled: boolean;
  selectedTypeDocument: TipoDocumento;
  id: number = +localStorage.getItem('id');
  user: PassengerPage;
  longitud: number;
  countexception: number;
  countNumdocumento: number;
  requestValid: boolean;
  result: boolean;
  model: string;
  valid: string;
  validPhone: string;

  constructor(
    public messageService: MessageService,
    private _documentTypeService: DocumentTypeService,
    public adminService: AdminService,
    public moduleService: ModuleService,
    private perfilService: PerfilesService,
    public ref: DynamicDialogRef
  ) {

  }

  ngOnInit() {
    this.request = {};
    this.validPhone = 'int';
    this.request.apellidoValid = false;
    this.request.celularValid = false;
    this.request.correoValid = false;
    this.request.direccionValid = false;
    this.request.nombreValid = false;
    this.request.numDocumentoValid = false;
    this.request.modulosValid = false;
    this.request.tipoDocIdValid = false;
    this.request.tipoUsuarioValid = false;
    this.requestUpdated = {};
    this.admin = {};
    this.admin.usuario = {};
    this.admin.admin = {};
    this.admin.admin.role = {};
    this.admin.admin.modulos = [];
    this.tipoDisabled = false;
    this.docDisabled = false;
    this.listmodules();
    this.admins()
    this.listTuypeDocuments();
    this.tipoUsuariosList();
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  private listmodules(){
    this.moduleService.modulos().subscribe((respose) => this.modules = respose.modulos);
  }

  admins() {
    if (this.id != 0) {
      this.tipoDisabled = true;
      this.docDisabled = true;
      this.adminService.consultAdmin(this.id).subscribe(response => {
        if (response.codigo == 200) {
          this.admin = response.admin;
          this.request.nombre = this.admin.usuario.nombre;
          this.request.apellido = this.admin.usuario.apellidos;
          this.request.numDocumento = this.admin.numDocumento;
          this.request.correo = this.admin.usuario.correo;
          this.request.celular = this.admin.usuario.celular;
          this.request.direccion = this.admin.usuario.direccion;
          this.selectedTypeDocument = this.admin.tipoDocumento;
          this.request.tipoUsuario = this.admin.usuario.perfil !== null ? this.admin.usuario.perfil.tipoUsuario : null;
          this.longitud = this.admin.tipoDocumento.longitud;
          if (this.admin.admin.modulos.length > 0) {
            this.request.modulos = this.admin.admin.modulos;
          }else{
            this.request.modulos = [];
          }
        }
        console.log(this.request);
      }, (error: ResponseError) => {
        console.error(error);
      });
    }
  }

  save() {
    this.request.tipoUsuario = this.request.tipoUsuario.nombre == 'Sin beneficio' ? this.request.tipoUsuario : null;
    if (this.validator(this.request)) {
      this.messageService.showWarn("Ingrese todos los datos Obligatorios");
    } else {
      if (this.id != 0) {
        this.requestUpdated.nombre = this.request.nombre;
        this.requestUpdated.apellido = this.request.apellido;
        this.requestUpdated.celular = this.request.celular;
        this.requestUpdated.modulos = this.request.modulos;
        this.adminService.editAdmin(this.id, this.requestUpdated).subscribe(response => {
          if (response.codigo == 200) {
            this.ref.close(response);
            localStorage.removeItem('id');
            this.request = {};
          }
        }, (error: ResponseError) => {
          console.error(error);
        });
      } else {
        this.request.tipoDocId = this.selectedTypeDocument.id;
        this.adminService.regAdmin(this.request).subscribe(response => {
          if (response.codigo == 201) {
            this.ref.close(response);
            this.request = {};
          }
        }, (error: ResponseError) => {
          console.error(error);
        });
      }
    }
  }

  public validaTipoDocumento(tipo: TipoDocumento) {
    this.longitud = tipo.longitud;
    this.admin.numDocumento = '';
    this.countNumdocumento = 0;
    this.request.tipoDocIdInputValid = '';
    if (tipo.id == 3 || tipo.id == 2) {
      this.valid = 'alphanum'
    } else {
      this.valid = 'int'
    }
  }

  private tipoUsuariosList() {
    this.perfilService.getTipoUsuario().subscribe(result => {
      this.tipoUsuarios = result;
    })
  }

  public validator(request: RequestAdmin): Boolean {
    console.log(request);
    this.countexception = 0;
    const emailRegex = /^\w+(\.-?\w+)*@\w+(\.-?\w+)*(\.\w{2,3})+$/;
    if (request.apellido == null || request.apellido.length < 1) {
      this.request.apellidoValid = true;
      this.request.apellidoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.apellidoValid = false
      this.request.apellidoInputValid = '';
    }
    if (request.nombre == null || request.nombre.length < 1) {
      this.request.nombreValid = true;
      this.request.nombreInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.nombreValid = false;
      this.request.nombreInputValid = '';
    }
    if (request.celular == null || request.celular.length < 1) {
      this.request.celularValid = true;
      this.request.celularInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.celularValid = false;
      this.request.celularInputValid = '';
    }
    if (request.correo == null || request.correo.length < 1) {
      this.request.correoValid = true;
      this.request.correoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.correoValid = false;
      this.request.correoInputValid = '';
    }
    if (this.selectedTypeDocument == null) {
      this.request.tipoDocIdValid = true;
      this.request.tipoDocIdInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.tipoDocIdValid = false;
      this.request.tipoDocIdInputValid = '';
    }
    if (request.numDocumento == null || request.numDocumento.length <= 1) {
      this.request.numDocumentoValid = true;
      this.request.numDocumentoInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.numDocumentoValid = false;
      this.request.numDocumentoInputValid = '';
    }

    if (request.tipoUsuario == null) {
      this.request.tipoUsuarioValid = true;
      this.request.tipoUsuarioInputValid = 'ng-invalid ng-dirty';
      this.countexception += 1;
    } else {
      this.request.tipoUsuarioValid = false;
      this.request.tipoUsuarioInputValid = '';
    }

    if (request.modulos == null || request.modulos.length == 0) {
      this.request.modulosValid = true;
      this.countexception += 1;
    } else {
      this.request.modulosValid = false;
    }
    if (this.countexception !== 0) {
      this.requestValid = true;
    } else {
      this.requestValid = false;
    }
    return this.requestValid;
  }

  public numDocumento(doc: string) {
    this.countNumdocumento = doc.length;
  }

  public modulosSelecction() {
    this.request.modulosValid = false;
  }


  cerrar() {
    this.ref.close();
    localStorage.removeItem('id');
  }
}
