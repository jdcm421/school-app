import { Component, OnInit } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { Modulo } from '@interfaces/passenger.interface';
import { AdminService } from '@services/admin/admin.service';
import { MessageService } from '@services/message.service';

@Component({
  selector: 'app-detail-modules',
  templateUrl: './detail-modules.component.html',
  styleUrls: ['./detail-modules.component.scss']
})
export class DetailModulesComponent implements OnInit {

  admins:Modulo[];
  id:number=+localStorage.getItem('id');
  constructor(public adminService: AdminService,
    public messageService: MessageService) { }

  ngOnInit() {
    this.userAdmin();
  }

  userAdmin(){
    this.adminService.consultAdmin(this.id).subscribe(response => {
      if(response.codigo == 200){
        this.admins = response.admin.admin.modulos.length >0  ? response.admin.admin.modulos : [];
      }
    },(error:ResponseError) =>{
      console.error(error);

    });
  }

}
