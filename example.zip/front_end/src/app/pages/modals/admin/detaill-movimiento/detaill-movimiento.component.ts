import { Component, OnInit } from '@angular/core';
import { AdminMovimientoDetalle } from '@interfaces/admin/response/adminMovimientoResponse';
import { ResponseError } from '@interfaces/error-response.interface';
import { MovimientoService } from '@services/admin/adminMovimiento.service';
import { MessageService } from '@services/message.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
declare var google: any;
@Component({
  selector: 'app-detaill-movimiento',
  templateUrl: './detaill-movimiento.component.html',
  styleUrls: ['./detaill-movimiento.component.scss']
})

export class DetaillMovimientoComponent implements OnInit {

  detail:AdminMovimientoDetalle;
  detalle:string;
  options: any;
  overlays: any[];
  id:number=+localStorage.getItem('id');
  constructor(private movimientoService : MovimientoService,
    public ref: DynamicDialogRef,
    public messageService: MessageService) { }
  ngOnInit() {
    this.deatails();
  }

  deatails(){
    this.movimientoService.movimiento(this.id).subscribe(response => {
      if(response.codigo == 200){
        console.log(response);
        this.detail = response.detalle;
        this.detalle = this.detail.abrev;
        /*this.options = {
          center: { lat: Number(this.detail.latitud), lng: Number(this.detail.longitud) },
          zoom: 12,
        };
        this.overlays = [
          new google.maps.Marker({
              position: { lat: Number(this.detail.latitud), lng: Number(this.detail.longitud) },
              title: 'Sucursal',
          }),
        ];*/
        localStorage.removeItem('id');
      }
    }, (error:ResponseError) =>{
      console.error(error);

    })
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }

}
