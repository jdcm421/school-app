import { Component, OnInit } from '@angular/core';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerPage } from '@interfaces/passenger.interface';
import { RequestPassengerUpdated } from '@interfaces/request.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { Departamento, Distrito, Provincia } from '@interfaces/ubigeo.interface';
import { AuthService } from '@services/auth.service';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { PassengerService } from '@services/passenger.service';
import { PerfilesService } from '@services/perfiles.service';
import { UbigeoService } from '@services/ubigeo.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {
  token:string = localStorage.getItem("token") !== null ? localStorage.getItem("token") : '';
  distritos: Distrito[];
  provincias: Provincia[];
  departamentos: Departamento[];
  request:RequestPassengerUpdated;
  passenger:PassengerPage;
  id:number=+localStorage.getItem('id');
  selectedProvincia: Provincia;
  selectedDistrito: Distrito;
  selectedDepartamento: Departamento;
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  perfiles:Perfil[];
  tipoUsuarios:TipoUsuario[];
  selectedPerfil:Perfil;
  selectedTipoUsuario:TipoUsuario;
  longitud:number;
  tipo:boolean=true;
  documento:boolean=true;
  nombre:boolean;
  apellido:boolean;
  correo:boolean;
  phone:boolean;
  profile:boolean;
  tipoUser:boolean;
  depart:boolean;
  provin:boolean;
  distrit:boolean;
  validPhone:string;

  constructor(
    private ubigeoService: UbigeoService,
    public messageService: MessageService,
    private _documentTypeService: DocumentTypeService,
    private passengerService:PassengerService,
    private perfilService: PerfilesService,
    private authService: AuthService,
    public ref: DynamicDialogRef
  ) {

  }
  ngOnInit(): void {
    this.request = {};
    this.passenger = {};
    this.validPhone = 'int';
    this.passenger.usuario = {};
    this.selectedTipoUsuario = {};
    this.selectedDepartamento = {};
    this.selectedProvincia = {};
    this.selectedDistrito = {};
    this.tipoUsuarios = [];
    this.listDepartamentos();
    this.listTuypeDocuments();
    this.listaPerfiles();
    this.passengers();
  }

  private listDepartamentos() {
    this.ubigeoService
      .getListDepartamentos().subscribe((response) => this.departamentos = response);
  }

  public listProvincias(departamento: Departamento) {
    this.ubigeoService
      .getProvinciaByIdDepartamento(departamento.id).subscribe((response) => this.provincias = response);
  }

  public listDistritos(provincia: Provincia) {
    this.ubigeoService
      .getDistritoByIdProvincia(provincia.id).subscribe((response) => this.distritos = response);
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  private listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result =>{
      this.perfiles = result;
    })
  }

  public listTipoUsuario(perfil: Perfil){
    this.selectedTipoUsuario = perfil.tipoUsuario;
    this.tipoUsuarios.push(this.selectedTipoUsuario);
  }

  passengers(){
      this.passengerService.passenger(this.id).subscribe(response => {
        if(response.codigo == 200){
          console.log(response);
          this.passenger = response.usuario;
          if(this.passenger.usuario.distrito != null){
            this.listProvincias(this.passenger.usuario.distrito.provincia.departamento);
            this.listDistritos(this.passenger.usuario.distrito.provincia);
            this.selectedDepartamento = this.passenger.usuario.distrito.provincia.departamento;
            this.selectedProvincia = this.passenger.usuario.distrito.provincia;
            this.selectedDistrito= this.passenger.usuario.distrito;
          }
          if(this.passenger.usuario.perfil != null){
            this.listTipoUsuario(this.passenger.usuario.perfil);
            this.selectedTipoUsuario = this.passenger.usuario.perfil.tipoUsuario;
          }

          console.log(this.passenger);
        }
      }, (error:ResponseError) =>{
        console.error(error);

      });
  }

  updated(){
    console.log(this.passenger);
    if(this.passenger.usuario.celular == null || this.passenger.usuario.perfil == null){
      this.messageService.showWarn("Ingrese Datos obligatorios")
    }else{
      this.request.direccion=this.passenger.usuario.direccion;
      this.request.celular=this.passenger.usuario.celular != null ? this.passenger.usuario.celular : null;
      this.request.distritoId=this.selectedDistrito != null ? this.selectedDistrito.id : this.passenger.usuario.distrito != null ? this.passenger.usuario.distrito.id :0;
      this.request.perfil = this.passenger.usuario.perfil.id != null ? this.passenger.usuario.perfil.id : 0;
      this.request.tipoUsuario = this.selectedTipoUsuario.nombre != null ? this.selectedTipoUsuario.nombre : null;
      this.passengerService.editPassenger(this.passenger.id,this.request).subscribe(response => {
      if(response.codigo == 200){
        this.ref.close(response);
        localStorage.removeItem('id');
      }
    }, (error:ResponseError) =>{
      console.error(error);

    });
    }

  }

  public validaTipoDocumento(tipo:TipoDocumento){
    console.log(tipo);
    this.longitud = tipo.longitud;
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }
}
