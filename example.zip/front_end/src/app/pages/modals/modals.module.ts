import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { QRCodeModule } from 'angularx-qrcode';
import { KeyFilterModule } from 'primeng/keyfilter';
import { PrimengModule } from 'src/app/shared/primeng.module';
import { AdminCentroSucursalesRegComponent } from './admin/admin-centro-sucursales-reg/admin-centro-sucursales-reg.component';
import { AdminOperadorRegComponent } from './admin/admin-operador-reg/admin-operador-reg.component';
import { AdminRecargaRegComponent } from './admin/admin-recarga-reg/admin-recarga-reg.component';
import { AdminRegisterComponent } from './admin/admin-register/admin-register.component';
import { AdminTransportRegComponent } from './admin/admin-transport-reg/admin-transport-reg.component';
import { DetailModulesComponent } from './admin/detail-modules/detail-modules.component';
import { DetaillMovimientoComponent } from './admin/detaill-movimiento/detaill-movimiento.component';
import { UserRegisterComponent } from './admin/user-register/user-register.component';
import { PassengerDetailMovimientoComponent } from './passenger/passenger-detail-movimiento/passenger-detail-movimiento.component';
import { ProfileUsersComponent } from './passenger/profile-users/profile-users.component';
import { QrDetailComponent } from './user/qr-detail/qr-detail.component';
import { TarifaRegisterComponent } from './user/tarifa-register/tarifa-register.component';

@NgModule({
  declarations: [
    UserRegisterComponent,
    TarifaRegisterComponent,
    DetaillMovimientoComponent,
    QrDetailComponent,
    ProfileUsersComponent,
    AdminCentroSucursalesRegComponent,
    AdminOperadorRegComponent,
    AdminRecargaRegComponent,
    AdminRegisterComponent,
    AdminTransportRegComponent,
    DetailModulesComponent,
    PassengerDetailMovimientoComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserModule,
    PrimengModule,
    QRCodeModule,
    KeyFilterModule,
  ],
  providers: [
  ]
})
export class ModalsModule { }
