import { Component, OnInit } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { DetailMovimientoPassenger } from '@interfaces/passenger/response/passengerMovimiento';
import { MessageService } from '@services/message.service';
import { PassengerMovimientoService } from '@services/passenger/passenger-movimiento.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
@Component({
  selector: 'app-passenger-detail-movimiento',
  templateUrl: './passenger-detail-movimiento.component.html',
  styleUrls: ['./passenger-detail-movimiento.component.scss']
})
export class PassengerDetailMovimientoComponent implements OnInit {

  detail:DetailMovimientoPassenger;
  detalle:string;
  options: any;
  overlays: any[];
  id:number=+localStorage.getItem('id');
  constructor(private movimientoService : PassengerMovimientoService,
    public ref: DynamicDialogRef,
    public messageService: MessageService) { }
  ngOnInit() {
    this.deatails();
  }

  deatails(){
    this.movimientoService.obtener(this.id).subscribe(response => {
      if(response.codigo == 200){
        this.detail = response.movimiento;
        this.detalle = this.detail.abrev;
        localStorage.removeItem('id');
      }
    }, (error:ResponseError) =>{
      console.error(error);

    })
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }
}
