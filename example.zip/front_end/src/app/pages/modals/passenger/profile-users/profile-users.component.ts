import { Component, OnInit } from '@angular/core';
import { TipoDocumento } from '@interfaces/documenType.interface';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerRequestProfile } from '@interfaces/passenger/request/passenger-request-profile';
import { Profile } from '@interfaces/passenger/response/passengerProfile';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { Departamento, Distrito, Provincia } from '@interfaces/ubigeo.interface';
import { DocumentTypeService } from '@services/document-type.service';
import { MessageService } from '@services/message.service';
import { PassengerProfileService } from '@services/passenger/passenger-profile.service';
import { PerfilesService } from '@services/perfiles.service';
import { UbigeoService } from '@services/ubigeo.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-profile-users',
  templateUrl: './profile-users.component.html',
  styleUrls: ['./profile-users.component.scss']
})
export class ProfileUsersComponent implements OnInit {
  distritos: Distrito[];
  provincias: Provincia[];
  departamentos: Departamento[];
  request:PassengerRequestProfile;
  passenger:Profile;
  selectedProvincia: Provincia;
  selectedDistrito: Distrito;
  selectedDepartamento: Departamento;
  documents: TipoDocumento[];
  selectedTypeDocument: TipoDocumento;
  perfiles:Perfil[];
  tipoUsuarios:TipoUsuario[];
  selectedPerfil:Perfil;
  selectedTipoUsuario:TipoUsuario;
  longitud:number;
  tipo:boolean=true;
  documento:boolean=true;
  nombre:boolean;
  apellido:boolean;
  correo:boolean;
  phone:boolean;
  profile:boolean;
  tipoUser:boolean;
  depart:boolean;
  provin:boolean;
  distrit:boolean;
  validPhone:string;

  constructor(
    private ubigeoService: UbigeoService,
    public messageService: MessageService,
    private _documentTypeService: DocumentTypeService,
    private passengerService:PassengerProfileService,
    private perfilService: PerfilesService,
    public ref: DynamicDialogRef
  ) {

  }
  ngOnInit(): void {
    this.request = {};
    this.passenger = {};
    this.validPhone = '';
    this.passenger.tipoDocumento = {};
    this.selectedTipoUsuario = {};
    this.selectedDepartamento = {};
    this.selectedProvincia = {};
    this.selectedDistrito = {};
    this.tipoUsuarios = [];
    this.listDepartamentos();
    this.listTuypeDocuments();
    this.listaPerfiles();
    this.passengers();
  }

  private listDepartamentos() {
    this.ubigeoService
      .getListDepartamentos().subscribe((response) => this.departamentos = response);
  }

  public listProvincias(departamento: Departamento) {
    this.ubigeoService
      .getProvinciaByIdDepartamento(departamento.id).subscribe((response) => this.provincias = response);
  }

  public listDistritos(provincia: Provincia) {
    this.ubigeoService
      .getDistritoByIdProvincia(provincia.id).subscribe((response) => this.distritos = response);
  }

  private listTuypeDocuments() {
    this._documentTypeService
      .getListTypeDocument().subscribe((response) => this.documents = response);
  }

  private listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result =>{
      this.perfiles = result;
    })
  }

  public listTipoUsuario(perfil: Perfil){
    this.selectedTipoUsuario = perfil.tipoUsuario;
    this.tipoUsuarios.push(this.selectedTipoUsuario);
  }

  passengers(){
      this.passengerService.getProfile().subscribe(response => {
        if(response.codigo == 200){
          this.passenger = response.profile;
          if(this.passenger.distrito != null){
            this.listProvincias(this.passenger.distrito.provincia.departamento);
            this.listDistritos(this.passenger.distrito.provincia);
            this.selectedDepartamento = this.passenger.distrito.provincia.departamento;
            this.selectedProvincia = this.passenger.distrito.provincia;
            this.selectedDistrito= this.passenger.distrito;
          }
          if(this.passenger.perfil != null){
            this.listTipoUsuario(this.passenger.perfil);
            this.selectedTipoUsuario = this.passenger.perfil.tipoUsuario;
          }
        }
      }, (error:ResponseError) =>{
        console.error(error);

      });
  }

  updated(){
    this.request.nombre=this.passenger.nombre;
    this.request.apellido=this.passenger.apellido;
    this.request.correo=this.passenger.correo;
    this.request.direccion=this.passenger.direccion;
    this.request.distritoId=this.selectedDistrito != null ?  this.selectedDistrito.id  : this.passenger.distrito.id;
    this.request.celular=this.passenger.celular;
    this.passengerService.updatedProfile(this.request).subscribe(response => {
      if(response.codigo == 200){
        this.ref.close(response);
        localStorage.removeItem('id');
      }
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  public validaTipoDocumento(tipo:TipoDocumento){
    this.longitud = tipo.longitud;
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }

}
