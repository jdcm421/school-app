import { Component, OnInit } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import { ResponseError } from '@interfaces/error-response.interface';
import { TransportistaQr } from '@interfaces/user/response/transportistaQrResponse';
import { MessageService } from '@services/message.service';
import { UserTransporteQrService } from '@services/user/transporte/user-transporte-qr.service';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-qr-detail',
  templateUrl: './qr-detail.component.html',
  styleUrls: ['./qr-detail.component.scss']
})
export class QrDetailComponent implements OnInit {
  id:number=+localStorage.getItem('id');
  data:TransportistaQr;
  url:string;
  nombre:string = "";
  qrCodeDownloadLink: SafeUrl = "";

  constructor(public messageService: MessageService,
    public transporteQr: UserTransporteQrService,
    public dialogService: DialogService,
    public ref: DynamicDialogRef) { }

  ngOnInit(): void {
    this.empresa();
  }

  empresa(){
    this.transporteQr.getQrsOnly(this.id).subscribe(response => {
      console.log(response);
      this.data = response.transporteQr;
      this.url = 'RUC: '+this.data.ruc+'\n'
      +'EMPRESA: '+this.data.empresaTransporte+'\n'
      +'RUTA: '+this.data.ruta+'\n'
      +'PLACA: '+this.data.placa+'\n'
      +'AÑO MODELO: '+new Date().getFullYear()+'\n'
      +'CARROCERIA: '+this.data.unidad+'\n'
      +'NUMERO ASIENTOS: '+this.data.numeroAsientos+'\n';
      this.nombre = 'QRCODE_'+this.data.empresaTransporte+'.png';
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }

  onChangeURL(url: SafeUrl) {
    this.qrCodeDownloadLink = url;
  }

}
