import { Component, OnInit } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { TransportistaTarifarioRequest } from '@interfaces/user/request/transportistaTarifarioRequest';
import { TransportistaTarifarioRuta } from '@interfaces/user/response/transportistaTarifarioResponse';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';
import { UserTransporteTarifaService } from '@services/user/transporte/user-transporte-tarifa.service';
import { DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-tarifa-register',
  templateUrl: './tarifa-register.component.html',
  styleUrls: ['./tarifa-register.component.scss']
})
export class TarifaRegisterComponent implements OnInit {

  perfiles:Perfil[];
  id:number=+localStorage.getItem('id');
  tipoUsuarios:TipoUsuario[]=[];
  selectedPerfil:Perfil;
  selectedTipoUsuario:TipoUsuario;
  request:TransportistaTarifarioRequest;
  selectedEmpresa:TransportistaTarifarioRuta;
  customers: TransportistaTarifarioRuta[];
  ruta:boolean;
  perfil:boolean;
  tipo:boolean;

  constructor(public messageService: MessageService,
    private perfilService: PerfilesService,
    public tarifarioService: UserTransporteTarifaService,
    public ref: DynamicDialogRef) { }

  ngOnInit() {
    if(this.id != 0){
      this.request = {};
      this.ruta = true;
      this.perfil = true;
      this.tipo = true;
      this.tarifas();
      this.listTipoUsuario(0);
      this.request.precio = 0.0;
    }else{
      this.request = {};
      this.ruta = false;
      this.perfil = false;
      this.tipo = true;
      this.request.precio = 0.0;
    }
    this.empresas();
    this.listaTipoUsuario();
    this.listaPerfiles();
  }

  tarifas(){
    this.tarifarioService.getTarifa(this.id).subscribe(response =>{
      this.selectedEmpresa = this.customers.find(e => e.ruc === response.tarifa.ruc);
      this.selectedPerfil = this.perfiles.find(p => p.perfiles === response.tarifa.perfil);
      this.selectedTipoUsuario = this.selectedPerfil.tipoUsuario;
      this.request.ruc=this.selectedEmpresa.ruc;
      this.request.codigoRuta = this.selectedEmpresa.ruta;
      this.request.tipoTarifa = this.selectedTipoUsuario.nombre;
      this.request.perfilId = this.selectedPerfil.id;
      this.request.precio = response.tarifa.monto;
    }, (error:ResponseError) =>{
      console.error(error);
    })
  }

  private listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result =>{
      this.perfiles = result;
    });
  }

  private listaTipoUsuario(){
    this.perfilService.getTipoUsuario().subscribe(result =>{
      this.tipoUsuarios = result;
    });
  }

  public listTipoUsuario(id:number){
    this.selectedTipoUsuario = this.tipoUsuarios.find(t => t.id == id);
  }

  empresas(){
    this.tarifarioService.getRutas().subscribe(response => {
      this.customers = response.rutas;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  guardar(){
    console.log(this.request);
    if(this.id == 0){
      this.request.perfilId = this.selectedPerfil.id;
      this.request.tipoTarifa = this.selectedTipoUsuario.nombre;
      this.request.ruc = this.selectedEmpresa.ruc;
      this.request.codigoRuta = this.selectedEmpresa.ruta;
      this.tarifarioService.registrar(this.request).subscribe(response => {
        this.ref.close(response);
        localStorage.removeItem('id');
      }, (error:ResponseError) =>{
        console.error(error);

      });
    }else{
      this.tarifarioService.actualizar(this.id,this.request).subscribe(response => {
        this.ref.close(response);
        localStorage.removeItem('id');
      }, (error:ResponseError) =>{
        console.error(error);

      });
    }
  }

  cerrar(){
    this.ref.close();
    localStorage.removeItem('id');
  }

}
