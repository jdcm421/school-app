import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { KeyFilterModule } from 'primeng/keyfilter';
import { TableModule } from 'primeng/table';
import { ComponentsModule } from '../components/components.module';
import { SideBarModule } from '../components/sidebar/sidebar.module';
import { SharedModule } from '../shared/shared.module';
import { AdminCentroSucursalesComponent } from './admin/admin-centro-sucursales/admin-centro-sucursales.component';
import { AdminOperadorComponent } from './admin/admin-operador/admin-operador.component';
import { UsersComponent } from './admin/admin-passenger/users.component';
import { AdminRecargaComponent } from './admin/admin-recarga/admin-recarga.component';
import { AdminTransporteComponent } from './admin/admin-transporte/admin-transporte.component';
import { AdministradorComponent } from './admin/administrador/administrador.component';
import { BitacoraApsComponent } from './admin/bitacora-apps/bitacora-aps.component';
import { CentroRecargasMovimientosComponent } from './admin/centro-recargas-movimientos/centro-recargas-movimientos.component';
import { EmpresaComponent } from './admin/empresa/empresa.component';
import { MovimientosComponent } from './admin/movimientos/movimientos.component';
import { OperadorAppComponent } from './admin/operador-app/operador-app.component';
import { ReportDetailAdminComponent } from './admin/report-detail-admin/report-detail-admin.component';
import { ReportFideicomisoAdminComponent } from './admin/report-fideicomiso-admin/report-fideicomiso-admin.component';
import { SucursalesComponent } from './admin/sucursales/sucursales.component';
import { HomeComponent } from "./home/home.component";
import { ModalsModule } from './modals/modals.module';
import { PagesComponent } from './pages.component';
import { CentroRecargaEmpresasComponent } from './passenger/centro-recarga-empresas/centro-recarga-empresas.component';
import { DerechoArcoComponent } from './passenger/derecho-arco/derecho-arco.component';
import { DudasConsultasComponent } from './passenger/dudas-consultas/dudas-consultas.component';
import { MovimientoPassengerComponent } from './passenger/movimiento-passenger/movimiento-passenger.component';
import { PassengerSucursalesComponent } from './passenger/passenger-sucursales/passenger-sucursales.component';
import { TransportCompanyComponent } from './passenger/transport-company/transport-company.component';
import { ReportDetailCentroComponent } from './user/centro-recarga/report-detail-centro/report-detail-centro.component';
import { ReportFideicomisoCentroComponent } from './user/centro-recarga/report-fideicomiso-centro/report-fideicomiso-centro.component';
import { UserCentroSucursalesComponent } from './user/centro-recarga/user-centro-sucursales/user-centro-sucursales.component';
import { ReportDetailOperatorComponent } from './user/operador/report-detail-operator/report-detail-operator.component';
import { ReportFideicomisoOperatorComponent } from './user/operador/report-fideicomiso-operator/report-fideicomiso-operator.component';
import { ControlTarifarioComponent } from './user/transportista/control-tarifario/control-tarifario.component';
import { GeneradorQrComponent } from './user/transportista/generador-qr/generador-qr.component';
import { HistorialTarifarioComponent } from './user/transportista/historial-tarifario/historial-tarifario.component';
import { MovimientosEmpresaComponent } from './user/transportista/movimientos-empresa/movimientos-empresa.component';
import { QuejasReclamosComponent } from './user/transportista/quejas-reclamos/quejas-reclamos.component';
import { ReportDetailTransportComponent } from './user/transportista/report-detail-transport/report-detail-transport.component';
import { ReportFideicomisoTransportComponent } from './user/transportista/report-fideicomiso-transport/report-fideicomiso-transport.component';

@NgModule({
  declarations: [
    HomeComponent,
    AdministradorComponent,
    AdminTransporteComponent,
    AdminRecargaComponent,
    AdminOperadorComponent,
    TransportCompanyComponent,
    PagesComponent,
    MovimientosComponent,
    UsersComponent,
    BitacoraApsComponent,
    EmpresaComponent,
    OperadorAppComponent,
    ControlTarifarioComponent,
    GeneradorQrComponent,
    QuejasReclamosComponent,
    DudasConsultasComponent,
    MovimientoPassengerComponent,
    MovimientosEmpresaComponent,
    HistorialTarifarioComponent,
    DerechoArcoComponent,
    ReportFideicomisoTransportComponent,
    ReportFideicomisoOperatorComponent,
    ReportFideicomisoAdminComponent,
    ReportFideicomisoCentroComponent,
    ReportDetailTransportComponent,
    ReportDetailOperatorComponent,
    ReportDetailAdminComponent,
    ReportDetailCentroComponent,
    AdminCentroSucursalesComponent,
    SucursalesComponent,
    PassengerSucursalesComponent,
    UserCentroSucursalesComponent,
    CentroRecargaEmpresasComponent,
    CentroRecargasMovimientosComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    ComponentsModule,
    SideBarModule,
    ModalsModule,
    SharedModule,
    KeyFilterModule,
    TableModule
  ]
})
export class PagesModule { }
