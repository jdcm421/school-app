import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CentroRecargaEmpresasComponent } from './centro-recarga-empresas.component';

describe('CentroRecargaEmpresasComponent', () => {
  let component: CentroRecargaEmpresasComponent;
  let fixture: ComponentFixture<CentroRecargaEmpresasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CentroRecargaEmpresasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CentroRecargaEmpresasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
