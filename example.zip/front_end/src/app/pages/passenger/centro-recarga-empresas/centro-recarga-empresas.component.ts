import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { Centro } from '@interfaces/passenger/response/passengerCentro';
import { RequestPage } from '@interfaces/request.interface';
import { MessageService } from '@services/message.service';
import { PassengerCentroService } from '@services/passenger/passenger-centro.service';

@Component({
  selector: 'app-centro-recarga-empresas',
  templateUrl: './centro-recarga-empresas.component.html',
  styleUrls: ['./centro-recarga-empresas.component.scss']
})
export class CentroRecargaEmpresasComponent implements OnInit {

  customers: Centro[];
  request:RequestPage;
  rows = 10;
  constructor(
    public messageService: MessageService,
    public centroService: PassengerCentroService,
    private router: Router) { }

  ngOnInit(): void {
    this.request = {};
    this.centros();
  }

  centros(){
    this.centroService.getCentro(this.request).subscribe(response => {
      this.customers = response.centros;
    }, (error:ResponseError) =>{
      console.error(error);

    });
    this.customers = [];
  }

  filterEmpresa(text:string){
    this.request = {};
    this.request.nombreCentroCarga = text;
    this.centroService.getCentro(this.request).subscribe(response => {
      this.customers = response.centros;
    });

  }

  filterDireccion(text:string){
    this.request = {};
    this.request.direccion = text;
    this.centroService.getCentro(this.request).subscribe(response => {
      this.customers = response.centros;
    });
  }

  limpiar(){
    this.request = {};
    this.centros();
  }

  sucursales(id:number,name:string){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
      localStorage.removeItem('center');
    }
    localStorage.setItem('id',JSON.stringify(id));
    localStorage.setItem('center',JSON.stringify(name));
    this.router.navigate(['/usuario/centro-recargas/sucursales']);
  }
}
