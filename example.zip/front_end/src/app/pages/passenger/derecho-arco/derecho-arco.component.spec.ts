/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { DerechoArcoComponent } from './derecho-arco.component';

describe('DerechoArcoComponent', () => {
  let component: DerechoArcoComponent;
  let fixture: ComponentFixture<DerechoArcoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DerechoArcoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DerechoArcoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
