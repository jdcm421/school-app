import { Component, OnInit } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { Role } from '@interfaces/passenger.interface';
import { PassengerRequestReclamos } from '@interfaces/passenger/request/passengerRequestReclamos';
import { Admin } from '@interfaces/passenger/response/passengerReclamos';
import { MessageService } from '@services/message.service';
import { PassengerDudasConsultasService } from '@services/passenger/passenger-dudas-consultas.service';
import { PassengerProfileService } from '@services/passenger/passenger-profile.service';


@Component({
  selector: 'app-dudas-consultas',
  templateUrl: './dudas-consultas.component.html',
  styleUrls: ['./dudas-consultas.component.scss']
})


export class DudasConsultasComponent implements OnInit {
  reclamo: PassengerRequestReclamos;
  customers: Role[];
  enterprise: Admin[];
  enterpriseItem: Admin;
  constructor(
    public messageService: MessageService,
    public profile: PassengerProfileService,
    public dudasConsulta: PassengerDudasConsultasService) { }

  ngOnInit(): void {
    this.enterprise = [];
    this.reclamo = {};
    this.empresas();
    this.passengers();
  }

  passengers() {
    this.profile.getProfile().subscribe(response => {
      if (response.codigo == 200) {
        this.reclamo.correo = response.profile.correo;
        this.reclamo.celular = response.profile.celular;
      }
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  onUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      console.log(reader.result);
      this.reclamo.adjuntar = reader.result.toString();
    };
  }

  guarda() {
    console.log(this.reclamo);
    this.reclamo.empresaId = this.enterpriseItem.id;
    this.reclamo.nombreEmpresa = this.enterpriseItem.nombreEmpresa;
    this.dudasConsulta.registro(this.reclamo).subscribe(response => {
      console.log(response);
      if (response.codigo == 201) {
        this.messageService.showSucces(response.mensaje);
        this.reclamo = {};
      } else {
        this.messageService.showError(response.mensaje);
      }

    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  empresas() {
    this.dudasConsulta.getEmpresas().subscribe(response => {
      this.customers = response.roles;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  rolesByEmpres(id: number) {
    this.dudasConsulta.obtenerEmpresas(id).subscribe(response => {
      this.enterprise = response.admins;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

}
