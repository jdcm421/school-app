import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { Movimiento } from '@interfaces/passenger/response/passengerMovimiento';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU } from '@interfaces/response.interface';
import { PassengerDetailMovimientoComponent } from '@modals/passenger/passenger-detail-movimiento/passenger-detail-movimiento.component';
import { MessageService } from '@services/message.service';
import { PassengerMovimientoService } from '@services/passenger/passenger-movimiento.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-movimiento-passenger',
  templateUrl: './movimiento-passenger.component.html',
  styleUrls: ['./movimiento-passenger.component.scss'],
  providers: [DialogService]
})
export class MovimientoPassengerComponent implements OnInit {
  data: Movimiento[];
  rows = 10;
  date: Date= new Date();
  request:RequestPage;
  itemsDownload: MenuItem[];
  dataExportExcel:any[];
  saldo:string;
  private ref: DynamicDialogRef;
  cols: any[] = [
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'tipoOperaciones', header: 'Tipo Operacion' },
    { field: 'monto', header: 'Monto' }
  ];
  exportColumns: any[];
  constructor(private movimientoService : PassengerMovimientoService,
    public dialogService: DialogService,
    public messageService: MessageService,
    private _exportService: ExportService,
    private _location: Location) { }

  ngOnInit(): void {
    this.request = {};
    this.dataExportExcel = [];
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  public showUseRegister(tipo:string) {
    this.ref = this.dialogService.open(PassengerDetailMovimientoComponent, {
      header: tipo == 'V' ? 'Detalle Movimiento Consumo' : 'Detalle Movimiento Recarga',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponseATU) => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.getMovimientos();
        localStorage.removeItem('id');
      }
  });
  }

  getMovimientos(){
    this.movimientoService.getMovimientos().subscribe(response => {
      this.data = response.movimientos;
      this.dataExportExcel = response.movimientos;
      console.log(this.dataExportExcel);
      this.saldo = response.saldo != null ? response.saldo.toFixed(2) : '0.00';
    }, (error:ResponseError) =>{
      console.error(error);
      if(error.codigo == 403){
        this._location.back();
      }

    });
  }

  edit(id:number,tipo:string){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister(tipo);
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Movimientos_pasajero_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Movimientos_pasajero_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.dataExportExcel,'Movimientos_pasajero_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Movimientos_pasajero_', this.dataExportExcel);
        }
      },
    ];
  }

}
