import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResponseError } from '@interfaces/error-response.interface';
import { Sucursal } from '@interfaces/passenger/response/passengerSucursales';
import { RequestPage } from '@interfaces/request.interface';
import { PassengerSucursalesService } from '@services/passenger/passenger-sucursales.service';

@Component({
  selector: 'app-passenger-sucursales',
  templateUrl: './passenger-sucursales.component.html',
  styleUrls: ['./passenger-sucursales.component.scss']
})
export class PassengerSucursalesComponent implements OnInit {

  data:Sucursal[];
  request:RequestPage;
  id:number=+localStorage.getItem('id');
  constructor(private sucursalesService:PassengerSucursalesService,
    private router: Router) { }

  ngOnInit() {
    this.request = {};
    this.sucursal();
  }

  sucursal(){
    this.sucursalesService.getSucursales(this.request,this.id).subscribe(response =>{
      this.data = response.sucursales;
    });
  }

  backCentro(){
    localStorage.removeItem('id');
    localStorage.removeItem('center');
    this.router.navigateByUrl("/usuario/centro-recargas");
  }

  search(){
    this.sucursalesService.getSucursales(this.request,this.id).subscribe(response => {
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  filterEmpresa(text:string){
    this.request = {};
    this.request.nombreCentroCarga = text;
    this.sucursalesService.getSucursales(this.request,this.id).subscribe(response => {
      this.data = response.sucursales;
    });

  }

  filterDireccion(text:string){
    this.request = {};
    this.request.direccion = text;
    this.sucursalesService.getSucursales(this.request,this.id).subscribe(response => {
      this.data = response.sucursales;
    });
  }

  limpiar(){
    this.request = {};
    this.sucursal();
  }

}
