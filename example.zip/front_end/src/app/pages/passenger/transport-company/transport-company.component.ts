import { Component, OnInit } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { PassengerTransporte } from '@interfaces/passenger/response/passengerTransporte';
import { RequestPage } from '@interfaces/request.interface';
import { MessageService } from '@services/message.service';
import { PassengerTransporteService } from '@services/passenger/passenger-transporte.service';

@Component({
  selector: 'app-transport-company',
  templateUrl: './transport-company.component.html',
  styleUrls: ['./transport-company.component.scss']
})
export class TransportCompanyComponent implements OnInit{
  customers: PassengerTransporte[];
  request:RequestPage;
  rows = 10;

  constructor(
    public messageService: MessageService,
    public transporteService: PassengerTransporteService) { }

  ngOnInit(): void {
    this.request = {};
    this.empresas();
  }

  empresas(){
    this.transporteService.getlistado(this.request).subscribe(response => {
      this.customers = response.transportes;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  searchText(text:string){
    this.request = {};
    this.request.nombreEmpresa = text;
    this.transporteService.getlistado(this.request).subscribe(response => {
      this.customers = response.transportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  searchRuc(text:string){
    this.request = {};
    this.request.numDocumento = text;
    this.transporteService.getlistado(this.request).subscribe(response => {
      this.customers = response.transportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.empresas();
  }
}
