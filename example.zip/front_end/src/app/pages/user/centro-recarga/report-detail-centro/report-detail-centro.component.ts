import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { CentroMovimiento } from '@interfaces/user/response/centroResponseMovimiento';
import { MessageService } from '@services/message.service';
import { UserCentroMovimientoService } from '@services/user/centros/user-centro-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-detail-centro',
  templateUrl: './report-detail-centro.component.html',
  styleUrls: ['./report-detail-centro.component.scss']
})
export class ReportDetailCentroComponent implements OnInit {

  data:CentroMovimiento[];
  request:RequestPage;
  rows:number;
  itemsDownload: MenuItem[];
  valid:string;
  cols: any[] = [
    { field: 'idCentro', header: 'IdCentro'  },
    { field: 'nombreCentro', header: 'Nombre Centro de Recarga' },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'id', header: 'IdTransaccion'  },
    { field: 'monto', header: 'Monto' },
    { field: 'comision', header: '% de Comision' }
  ];
  exportColumns: any[];
  constructor(private movimientoService : UserCentroMovimientoService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.request = {};
    this.valid = "int"
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  getMovimientos(){
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    window.location.reload();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Reporte_Detallado_Centro_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Detallado_Centro_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Detallado_Centro_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Reporte_Detallado_Centro_', this.data);
        }
      },
    ];
  }

}
