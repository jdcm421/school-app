import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { CentroReporte } from '@interfaces/user/response/centroResponseMovimiento';
import { MessageService } from '@services/message.service';
import { UserCentroMovimientoService } from '@services/user/centros/user-centro-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-fideicomiso-centro',
  templateUrl: './report-fideicomiso-centro.component.html',
  styleUrls: ['./report-fideicomiso-centro.component.scss']
})
export class ReportFideicomisoCentroComponent implements OnInit {

  data:CentroReporte[];
  fecha:string;
  request:RequestPage;
  rows:number;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'id', header: 'Id Instruccion'  },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'monto', header: 'monto Recarga'  },
    { field: 'comision', header: 'monto Total' }
  ];
  exportColumns: any[];
  constructor(private movimientoService : UserCentroMovimientoService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.request = {};
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.data = [];
    this.listItemsDownload();
  }

  getMovimientos(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = response.reportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = response.reportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    window.location.reload();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Reporte_Fideicomiso_Centro_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Fideicomiso_Centro_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Fideicomiso_Centro_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Reporte_Fideicomiso_Centro_', this.data);
        }
      },
    ];
  }
}
