import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { CentroSucursale } from '@interfaces/user/response/centroResponseSucursales';
import { MessageService } from '@services/message.service';
import { UserCentrosSucursalesService } from '@services/user/centros/user-centros-sucursales.service';
import { MenuItem } from 'primeng/api';
@Component({
  selector: 'app-user-centro-sucursales',
  templateUrl: './user-centro-sucursales.component.html',
  styleUrls: ['./user-centro-sucursales.component.scss']
})
export class UserCentroSucursalesComponent implements OnInit {

  data:CentroSucursale[];
  request:RequestPage;
  itemsDownload: MenuItem[];
  exportColumns: any[];
  cols: any[] = [
    { field: 'tipoDocumento', header: 'TipoDocumento'  },
    { field: 'numDocumento', header: 'NumeroDocumento'},
    { field: 'nombreCentro', header: 'NombreEmpresa'},
    { field: 'direccion', header: 'Direccion' },
    { field: 'ubigeo', header: 'Ubigeo' }
  ];
  constructor(private centro : UserCentrosSucursalesService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.request = {};
    this.lista();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  lista(){
    this.centro.getSucursales(this.request).subscribe(response => {
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.centro.getSucursales(this.request).subscribe(response => {
      this.data = response.sucursales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.lista();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Reporte_Detallado_Centro_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Detallado_Centro_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Detallado_Centro_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Reporte_Detallado_Centro_', this.data);
        }
      },
    ];
  }

}
