import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { Movimiento } from '@interfaces/user/response/operadorResponseMovimientos';
import { MessageService } from '@services/message.service';
import { UserOperadorMovimientoService } from '@services/user/operador/user-operador-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-detail-operator',
  templateUrl: './report-detail-operator.component.html',
  styleUrls: ['./report-detail-operator.component.scss']
})
export class ReportDetailOperatorComponent implements OnInit {

  data: Movimiento[];
  rows = 10;
  textFilter:any;
  date:string;
  rol:string = localStorage.getItem('rol');
  request:RequestPage;
  itemsDownload: MenuItem[];
  valid:string;

  cols: any[] = [
    { field: 'id', header: 'IdTransaccion'  },
    { field: 'origen', header: 'Origen'},
    { field: 'empresa', header: 'Empresa Transporte'},
    { field: 'placa', header: 'Placa' },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'monto', header: 'Monto' }
  ];
  exportColumns: any[];
  constructor(
    private _exportService: ExportService,
    private movimientoService : UserOperadorMovimientoService,
    public messageService: MessageService
  ) { }

  ngOnInit(): void {
    this.valid="int";
    this.request = {};
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
    this.getMovimientos();
  }

  getMovimientos(){
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = [];
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  searchText(text:string){
    this.request = {};
    this.request.nombreEmpresa = text;
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  updated(){
    window.location.reload();
  }


  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Operador_Apps_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.xlsx');
         }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Operador_Apps_', this.data);
        }
      }
    ];
  }

}
