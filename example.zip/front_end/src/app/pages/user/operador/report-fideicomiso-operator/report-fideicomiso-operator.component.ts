import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { Reporte } from '@interfaces/user/response/operadorResponseMovimientos';
import { MessageService } from '@services/message.service';
import { UserOperadorMovimientoService } from '@services/user/operador/user-operador-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-fideicomiso-operator',
  templateUrl: './report-fideicomiso-operator.component.html',
  styleUrls: ['./report-fideicomiso-operator.component.scss']
})
export class ReportFideicomisoOperatorComponent implements OnInit {

  data: Reporte[];
  rows = 10;
  textFilter:any;
  date:string;
  rol:string = localStorage.getItem('rol');
  request:RequestPage;
  itemsDownload: MenuItem[];

  cols: any[] = [
    { field: 'id', header: 'IdInstruccion'  },
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'tipo', header: 'Tipo Operación' },
    { field: 'monto', header: 'Monto' },
    { field: 'comision', header: 'Comision' }
  ];
  exportColumns: any[];
  constructor(
    private _exportService: ExportService,
    private movimientoService : UserOperadorMovimientoService,
    public messageService: MessageService
  ) { }

  ngOnInit(): void {
    this.request = {};
    this.data = [];
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
    this.getMovimientos();
  }

  getMovimientos(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = response.reportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = [];
      this.data = response.reportes;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    window.location.reload();
  }


  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Operador_Apps_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.xlsx');
         }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Operador_Apps_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Operador_Apps_', this.data);
        }
      }
    ];
  }

}
