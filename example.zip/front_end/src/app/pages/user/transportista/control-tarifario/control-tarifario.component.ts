import { Component } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { ResponseATU } from '@interfaces/response.interface';
import { Perfil, TipoUsuario } from '@interfaces/roles.interface';
import { TransportistaTarifarioRuta, TransportistaTarifarioTarifa } from '@interfaces/user/response/transportistaTarifarioResponse';
import { TarifaRegisterComponent } from '@modals/user/tarifa-register/tarifa-register.component';
import { MessageService } from '@services/message.service';
import { PerfilesService } from '@services/perfiles.service';
import { UserTransporteTarifaService } from '@services/user/transporte/user-transporte-tarifa.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-control-tarifario',
  templateUrl: './control-tarifario.component.html',
  styleUrls: ['./control-tarifario.component.scss'],
  providers: [DialogService]
})
export class ControlTarifarioComponent {
  perfiles:Perfil[];
  tipoUsuarios:TipoUsuario[];
  selectedPerfil:Perfil;
  selectedTipoUsuario:TipoUsuario;
  data: TransportistaTarifarioTarifa[];
  request:RequestPage;
  customers: TransportistaTarifarioRuta[];
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'codigoRuta', header: 'Ruta' },
    { field: 'tipoTarifa', header: 'TipoTarifa' },
    { field: 'perfiles', header: 'perfil' },
    { field: 'precio', header: 'precio' }
  ];
  exportColumns: any[];
  private ref: DynamicDialogRef;
  constructor(
    private _exportService: ExportService,
    private dialogService: DialogService,
    private messageService: MessageService,
    private tarifarioService: UserTransporteTarifaService,
    private perfilService: PerfilesService
  ) { }

  ngOnInit(): void {
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.request = {};
    this.data = [];
    this.listItemsDownload();
    this.getTarifarios();
    this.empresas();
    this.listaPerfiles();
    this.listTipoUsuario();
  }

  public showUseRegister(id:number) {
    if(id==0){
      localStorage.removeItem('id');
    }
    this.ref = this.dialogService.open(TarifaRegisterComponent, {
      header: id == 0 ? 'Nuevo Tarifa': 'Editar Tarifa',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: ResponseATU) => {
      if(response.codigo == 201 || response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.getTarifarios();
        localStorage.removeItem('id');
      }
  });
  }

  getTarifarios(){
    this.tarifarioService.tarifas(this.request).subscribe(response => {
      this.data = response.tarifas;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  search(){
    this.tarifarioService.tarifas(this.request).subscribe(response => {
      this.data = response.tarifas;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  limpiar(){
    this.request = {};
    this.getTarifarios();
  }

  edit(id:number){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister(id);
  }

  status(id:number){
    this.tarifarioService.tarifasChangeStatus(id).subscribe(response => {
      if(response.codigo == 200){
        this.messageService.showSucces(response.mensaje);
        this.getTarifarios();
      }
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }

  private listaPerfiles() {
    this.perfilService.getPerfiles().subscribe(result =>{
      this.perfiles = result;
    })
  }

  public listTipoUsuario(){
    this.perfilService.getTipoUsuario().subscribe(response =>{
      this.tipoUsuarios = response;
    })
  }

  empresas(){
    this.tarifarioService.getRutas().subscribe(response => {
      this.customers = response.rutas;
    }, (error:ResponseError) =>{
      console.error(error);

    });
  }


  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Tarifa_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Tarifa_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Tarifa_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Tarifa_', this.data);
        }
      },
    ];
  }
}
