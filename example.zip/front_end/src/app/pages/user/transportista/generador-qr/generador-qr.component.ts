import { Component } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaQr } from '@interfaces/user/response/transportistaQrResponse';
import { QrDetailComponent } from '@modals/user/qr-detail/qr-detail.component';
import { MessageService } from '@services/message.service';
import { UserTransporteQrService } from '@services/user/transporte/user-transporte-qr.service';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-generador-qr',
  templateUrl: './generador-qr.component.html',
  styleUrls: ['./generador-qr.component.scss'],
  providers: [DialogService]
})
export class GeneradorQrComponent {
  data: TransportistaQr[];
  request:RequestPage;
  fecha:string;
  first = 0;
  rows = 10;
  itemsDownload: MenuItem[];
  private ref: DynamicDialogRef;
  cols: any[] = [
    { field: 'qr de Transporte', header: 'qrUrl' },
    { field: 'placa', header: 'placa' },
    { field: 'ruta', header: 'ruta' },
    { field: 'Tipo de unidad', header: 'tipoUnidad' },
  ];
  exportColumns: any[];

  constructor(private _exportService: ExportService,
    public messageService: MessageService,
    public transporteQrService: UserTransporteQrService,
    public dialogService: DialogService,) { }

  ngOnInit(): void {
    this.request = {};
    this.empresas();
  }

  public showUseRegister() {
    this.ref = this.dialogService.open(QrDetailComponent, {
      header: 'Codigo QR',
      width: '50%',
      contentStyle: { "overflow": "auto" },
      baseZIndex: 10000,
      maximizable: false
    });

    this.ref.onClose.subscribe(( response: any) => {
  });
}

  empresas(){
    this.transporteQrService.getQrs(this.request).subscribe(response => {
      this.data = response.transportista;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.transporteQrService.getQrs(this.request).subscribe(response => {
      this.data = response.transportista;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.empresas();
  }

  edit(id:number){
    if(localStorage.getItem('id') != null){
      localStorage.removeItem('id');
    }
    localStorage.setItem('id',JSON.stringify(id));
    this.showUseRegister();
  }

  updated(){
    window.location.reload();
  }
}

