import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaHistorialTarifario } from '@interfaces/user/response/transportistaHistorialTarifarioResponse';
import { MessageService } from '@services/message.service';
import { UserTransporteHistorialService } from '@services/user/transporte/user-transporte-historial.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-historial-tarifario',
  templateUrl: './historial-tarifario.component.html',
  styleUrls: ['./historial-tarifario.component.scss']
})
export class HistorialTarifarioComponent implements OnInit {
  data: TransportistaHistorialTarifario[];
  request:RequestPage;
  itemsDownload: MenuItem[];
  cols: any[] = [
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'monto' },
    { field: 'codigoRuta', header: 'Ruta' },
    { field: 'perfiles', header: 'Perfil' },
    { field: 'tipoTarifa', header: 'Tipo Tarifa' },
    { field: 'precio', header: 'Precio' },
    { field: 'detalle', header: 'Detalle' }
  ];
  exportColumns: any[];
  constructor(
    private _exportService: ExportService,
    public messageService: MessageService,
    public historialService: UserTransporteHistorialService
  ) { }

  ngOnInit(): void {
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.data = [];
    this.listItemsDownload();
    this.request = {};
    this.historial();
  }

  historial(){
    this.historialService.getHistorial(this.request).subscribe(response => {
      this.data = response.historiales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.historialService.getHistorial(this.request).subscribe(response => {
      this.data = response.historiales;
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.historial();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Historial_tarifario_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Historial_tarifario_','.xlsx');
         }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Historial_tarifario_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Historial_tarifario_', this.data);
        }
      }
    ];
  }
}
