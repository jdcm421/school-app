import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaMovimientos } from '@interfaces/user/response/transportistaMovimientosResponse';
import { MessageService } from '@services/message.service';
import { UserTransporteMovimientoService } from '@services/user/transporte/user-transporte-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-movimientos-empresa',
  templateUrl: './movimientos-empresa.component.html',
  styleUrls: ['./movimientos-empresa.component.scss']
})
export class MovimientosEmpresaComponent implements OnInit {

  data: TransportistaMovimientos[];
  request:RequestPage;
  itemsDownload: MenuItem[];
  cols: any[];
  exportColumns: any[];
  constructor(private movimientoService : UserTransporteMovimientoService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.cols = [
      { field: 'fecha', header: 'Fecha'  },
      { field: 'hora', header: 'Hora'  },
      { field: 'tipoOperacion', header: 'Tipo Operacion'},
      { field: 'placa', header: 'Placa Vechiculo' },
      { field: 'ruta', header: 'Ruta' },
      { field: 'monto', header: 'Monto' }
    ]
    this.request = {};
    this.data = [];
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.listItemsDownload();
  }

  getMovimientos(){
      this.movimientoService.getMovimientos(this.request).subscribe(response => {
        this.data = response.movimientos;
      }, (error:ResponseError) =>{
        console.error(error);
      });
  }

  search(){
    this.movimientoService.getMovimientos(this.request).subscribe(response => {
      this.data = response.movimientos;
    }, (error:ResponseError) =>{
      console.error(error);
    });
    }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data,'Movimientos_empresa_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Movimientos_empresa_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Movimientos_empresa_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Movimientos_empresa_', this.data);
        }
      },
    ];
  }

}
