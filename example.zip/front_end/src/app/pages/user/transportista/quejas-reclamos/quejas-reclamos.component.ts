import { Component } from '@angular/core';
import { ResponseError } from '@interfaces/error-response.interface';
import { UploadEvent } from '@interfaces/passenger/request/UploadEvent';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaReclamoRequest } from '@interfaces/user/request/transportistaReclamoRequest';
import { TransportistaQr } from '@interfaces/user/response/transportistaQrResponse';
import { MessageService } from '@services/message.service';
import { UserTransporteQrService } from '@services/user/transporte/user-transporte-qr.service';
import { UserTransporteReclamoService } from '@services/user/transporte/user-transporte-reclamo.service';

@Component({
  selector: 'app-quejas-reclamos',
  templateUrl: './quejas-reclamos.component.html',
  styleUrls: ['./quejas-reclamos.component.scss']
})
export class QuejasReclamosComponent {
  motivoQueja: any[] = [
    { label: "Reclamos" },
    { label: "Observación" },
    { label: "Otro" }
  ];
  selectedMotivo: any;

  reclamo: TransportistaReclamoRequest;
  customers: TransportistaQr[];
  request: RequestPage;
  constructor(
    private messageService: MessageService,
    private reclamoService: UserTransporteReclamoService,
    private empresaRutas: UserTransporteQrService) { }

  ngOnInit(): void {
    this.request = {};
    this.reclamo = {};
    this.empresas();
  }

  guarda() {
    console.log(this.reclamo);
    this.reclamoService.dudas(this.reclamo).subscribe(response => {
      if (response.codigo == 201) {
        this.messageService.showSucces(response.mensaje);
        setTimeout("location.reload()", 3000);
        this.reclamo = {};
      } else {
        this.messageService.showError(response.mensaje);
      }

    }, (error: ResponseError) => {
      console.error(error);

    });
  }

  empresas() {
    this.empresaRutas.getQrs(this.request).subscribe(response => {
      this.customers = response.transportista;
    }, (error: ResponseError) => {
      console.error(error);
    });
  }

  onUpload(event : UploadEvent) {
    const file = event.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      console.log(reader.result);
      this.reclamo.adjuntar = reader.result.toString();
    };
  }
}
