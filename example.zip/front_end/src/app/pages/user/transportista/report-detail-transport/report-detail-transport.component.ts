import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-detail-transport',
  templateUrl: './report-detail-transport.component.html',
  styleUrls: ['./report-detail-transport.component.scss']
})
export class ReportDetailTransportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
