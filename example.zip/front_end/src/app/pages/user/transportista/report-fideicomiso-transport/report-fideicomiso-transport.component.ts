import { Component, OnInit } from '@angular/core';
import { ExportService } from '@helpers/export.service';
import { ResponseError } from '@interfaces/error-response.interface';
import { RequestPage } from '@interfaces/request.interface';
import { TransportistaReporte } from '@interfaces/user/response/transportistaMovimientosResponse';
import { MessageService } from '@services/message.service';
import { UserTransporteMovimientoService } from '@services/user/transporte/user-transporte-movimiento.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-report-fideicomiso-transport',
  templateUrl: './report-fideicomiso-transport.component.html',
  styleUrls: ['./report-fideicomiso-transport.component.scss']
})
export class ReportFideicomisoTransportComponent implements OnInit {

  data: TransportistaReporte[];
  date: Date;
  fecha:string;
  request:RequestPage;
  itemsDownload: MenuItem[];
  longitud:number;
  cols: any[] = [
    { field: 'fecha', header: 'Fecha' },
    { field: 'hora', header: 'Hora' },
    { field: 'id', header: 'Id Transaccion'  },
    { field: 'monto', header: 'Monto'  },
    { field: 'comision', header: 'Comision' }
  ];
  exportColumns: any[];
  constructor(private movimientoService : UserTransporteMovimientoService,
    public messageService: MessageService,
    private _exportService: ExportService) { }

  ngOnInit() {
    this.request = {};
    this.getMovimientos();
    this.exportColumns = this.cols.map(( col ) => ({ header: col.header, dataKey: col.field }));
    this.data = [];
    this.listItemsDownload();
  }

  getMovimientos(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = response.reportes;
      this.fecha = new Date().toDateString();
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  search(){
    this.movimientoService.getReporte(this.request).subscribe(response => {
      this.data = response.reportes;
      this.fecha = new Date().toDateString();
    }, (error:ResponseError) =>{
      console.error(error);
    });
  }

  limpiar(){
    this.request = {};
    this.getMovimientos();
  }

  updated(){
    window.location.reload();
  }

  private listItemsDownload() {
    this.itemsDownload = [
      {
        label: 'Pdf',
        icon: 'pi pi-file-pdf',
        command: () => {
          this._exportService
            .exportPdf(this.exportColumns, this.data, 'Reporte_Fideicomiso_Transporte_');
        }
      },
      {
        label: 'Excel',
        icon: 'pi pi-file-excel',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Fideicomiso_Transporte_','.xlsx');
        }
      },
      {
        label: 'CSV',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportExcel(this.exportColumns, this.data,'Reporte_Fideicomiso_Transporte_','.csv');
        }
      },
      {
        label: 'TXT',
        icon: 'pi pi-file',
        command: () => {
          this._exportService
            .exportText('Reporte_Fideicomiso_Transporte_', this.data);
        }
      },
    ];
  }
}
