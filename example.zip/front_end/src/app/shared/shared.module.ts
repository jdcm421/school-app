import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimengModule } from './primeng.module';
import { KeyFilterModule } from 'primeng/keyfilter';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    PrimengModule,
    KeyFilterModule
  ],
  exports: [
    PrimengModule
  ]
})
export class SharedModule { }
