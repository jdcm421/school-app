export const environment = {
  production: true,
  version: '1.0.33',
  url: 'https://api-atu.pappstest.com/core-backoffice',
  googleRecaptchaSiteKey: '66LdIHOEkAAAAADecaYF0TJ2upZ8sSOUeahCfeM_O',
};
