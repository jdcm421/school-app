export const environment = {
  production: false,
  version: '1.0.33',
 url: 'http://localhost:8080/core-backoffice',
  //url: 'https://api-tuqr.atu.gob.pe/core-backoffice',
  urlAtu: 'https://desarrollo.atu.gob.pe/ConsultaQR/api/ConsultaVehiculo/CON_GET_RUC_0001',
  tokenAtu: '67a35a58ff793d0493a283d771af3c4f2efde78e4255aafeb3d47c7948a0b64c63c179f4c1e8cf99efddfb65ed4a06ae5e08667303174a133fde7422eab8cc55c4d7afe16f53b7c2e7a201dfdd63d1d154150e86577bfd9514358cfa499f570f55fcfe27a103ba5efa0b9993b3cf4ecc28869e6254e8228d3d178922f633505fd9d40e978e49b7f3d7dd63d314b45c0ec339177bb06059d4568447267f296e932c6738b8a1fc42913bf440b811635da2f48292bf33b3f3fb117597541c338668d109e6ce3f5ac4c414e55ad74b439ba7b353b7da173bf7b1cd63024e6d5c7a2c',
  googleRecaptchaSiteKey: '6LdIHOEkAAAAADecaYF0TJ2upZ8sSOUeahCfeM_O',
};
